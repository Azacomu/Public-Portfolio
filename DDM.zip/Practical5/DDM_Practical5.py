# File created on: 2017-06-22 13:12:15.980843
#
# IMPORTANT:
# ----------
# - Before making a new Practical always make sure you have the latest version of the addon!
# - Delete the old versions of the files in your user folder for practicals you want to update (make a copy of your work!).
# - For the assignment description and to download the addon, see the course website at: http://www.cs.uu.nl/docs/vakken/ddm/
# - Mail any bugs and inconsistencies you see to: uuinfoddm@gmail.com

# Practical by Martin Boers (5676401) and Florian van Strien (5632757).

import ddm
import bpy
from numpy import array as Vector
from numpy import matrix as Matrix

#################################
# Place additional imports here #
#################################
import numpy as np
import math
import copy
from numpy import linalg
from numpy import identity as Identity
from mathutils import Vector as Vec

#Globals used to be able to calculate things
#These have to be reset when a new mesh is loaded, which normally happens automatically
#Without these globals, the practical would either be impossible or really slow
global faces 	#Needed to use faces in global_step for the RHS
global p_B		#Needed for calculation of RHS
global g		#Needed for calculation of RHS
global lhs		#Needed to solve systems in the global step, calculated in precompute, then put in lhs.
global W		#Weights have to be calculated once on the original mesh and not anymore then that.
global source_vertices #Need to use those for calculating the ARAP iteration. (local step).
global one_rings #Need those for every local step as well.
global d_0I		#Has to be calculated once, constant after that.
global d_0B		#Has to be calculated once, constant after that.
global d_0N		#Has to be calculated once, constant after that.
global boundary #Calcuated in precompute, then the same
global mesh_edges #Calculated in precompute too

# Return a list of the vertices of the current object
def get_vertices(context):
	return [vt.co for vt in context.active_object.data.vertices]
	
# Returns a list of triangles of vertex indices (you need to perform simple triangulation) 
def get_faces(context):	
	current_obj = context.active_object
	faces = []
	#Get the needed data from all the faces and add them to the lists.
	for face in current_obj.data.polygons:
		thisFaceVerts = face.vertices[:]
		# Triangulate this face and add it to the triangles list (as indexes)
		for startpos in range(1, len(thisFaceVerts) - 1):
			faces.append(
				(current_obj.data.vertices[thisFaceVerts[0]].index,
				current_obj.data.vertices[thisFaceVerts[startpos]].index,
				current_obj.data.vertices[thisFaceVerts[startpos + 1]].index))
	return faces

# Returns the 1-ring (a list of vertex indices) for a vertex index
# O(N) in the amount of faces, so pretty slow
def neighbor_indices(vertex_index, vertices, faces):
	neighbors = []
	# Check which faces contain the vertex_index and add other vertices
	# of these faces
	for face in faces:
		if vertex_index in face:
			for vt in face:
				if vt != vertex_index and not vt in neighbors:
					neighbors.append(vt)
	return neighbors

# Calculate either the source or the target matrix
# These functions are the same anyway with different parameters passed in
def source_or_target_matrix(p_index, vertices, neighbor_indices):
	point = vertices[p_index]
	# For each neighbor, calculate pi - p(1,2,3) for each coord
	matArray = [[piCo - pCo for piCo, pCo in zip(point, vertices[i])] for i in neighbor_indices]
	return Matrix(matArray)

# Calculates the source (non-sparse) matrix P
def source_matrix(p_index, vertices, neighbor_indices):
	return source_or_target_matrix(p_index, vertices, neighbor_indices)
	
# Calculates the target (non-sparse) matrix Q
def target_matrix(p_index, vertices, neighbor_indices):
	return source_or_target_matrix(p_index, vertices, neighbor_indices)
	
# Returns a triple of three dense matrices that are the Singular Value Decomposition (SVD)
def SVD(P, Q):
	S = P.transpose() * Q
	# Do SVD
	U, sigmaArray, V = linalg.svd(S)
	#...which returns an array for the sigma, so make that a matrix
	return (U, Matrix(np.diag(sigmaArray)), V)

# Returns the dense matrix R
def rigid_transformation_matrix(U, Sigma, V):
	# V is already transposed
	R = U * V
	# If the determinant is negative 
	if linalg.det(R) == -1:
		# Start with the diagonal of the Identity
		sigma2Arr = [1, 1, 1]
		# Minimum value from the sigma and the position where we found that
		minSigma = math.inf
		minSigmaI = 0
		# Find the minimum value from the sigma
		for i in range(3):
			if Sigma[i, i] < minSigma:
				minSigma = Sigma[i, i]
				minSigmaI = i
		sigma2Arr[minSigmaI] = -1
		R = U * Matrix(np.diag(sigma2Arr)) * V
	
	return R

# Returns a list of rigid transformation matrices R, one for each vertex (make sure the indices match)
# the list_of_1_rings is a list of lists of neighbor_indices
def local_step(source_vertices, target_vertices, list_of_1_rings):
	transformMatrices = []
	# For each vertex, find out the new rigid transformation matrix
	for v in range(len(source_vertices)):
		# SVD on P.transpose() * Q, get the matrices from that
		U, Sigma, V = SVD(source_matrix(v, source_vertices, list_of_1_rings[v]),
                    target_matrix(v, target_vertices, list_of_1_rings[v]))
		# And build the rigid transformation matrix
		transformMatrices.append(rigid_transformation_matrix(U, Sigma, V))
	return transformMatrices

# Returns the triplets of sparse d_0 matrix
def d_0(vertices, faces):
	values = []
	edges = get_edges(vertices, faces)
	boundary = get_boundary()
	#Loop through all edges and get the triplets for in the matrix.
	for i in range(len(edges)):
		begin, end = edges[i]
		# 1 at the start, -1 at the end
		values.append((i, begin, 1))
		values.append((i, end, -1))
	print(values)
	return values
	
# Return the sparse diagonal weight matrix W
def weights(vertices, faces):
	foundWeights = []
	# Get the edges (takes a little time, but we only do the calculating weights once anyway)
	edges = get_edges(vertices, faces)
	for edge in edges:
		flap = get_flaps(edge, faces)
		#First calculate the angles of the corners of the flaps (either one or two) opposite to the edge.
		cot = []
		for face in flap:
			#First get the corner (check the 3 vertices from the face, the one not in the center edge is the corner to calculate the angle of).
			corner = None
			for v in face:
				if v not in edge:
					corner = vertices[v]
					break
					
			#Then get the vertices from the corner to the vertices of the center edge.
			v1 = vertices[edge[0]] - corner
			v2 = vertices[edge[1]] - corner
			
			#Calculate the dotproduct between the 2 vertices to get the cosinus of the angle.
			#Then convert this to an actual angle (acos returns radiants!).
			angle = math.acos(v1.dot(v2) / (v1.length * v2.length))
			
			#Calculate the cotangens of this angle.
			cot.append(1 / math.tan(angle))
			
		#Then calculate the weight with both cotangens.
		foundWeights.append(sum(cot) / 2)
	
	#Finally create a diagonal sparse matrix with the weights.
	values = [(i, i, foundWeights[i]) for i in range(len(foundWeights))]
		
	return ddm.Sparse_Matrix(values, len(foundWeights), len(foundWeights))

# Returns the right hand side of least-squares system
def RHS(vertices, faces):
	global p_B 	#Need this var to calculate part of the RHS
	global g	#Need this var to calculate part of the RHS
	global W
	global d_0I
	global d_0B
	global d_0N
	
	# We have most variables as they are global (for speed etc.)
	# Now calculate the full right hand side in two parts	
	rhs_p1 = Vector(d_0N.transposed() * W * d_0B * p_B)	
	rhs_p2 = Vector(d_0I.transposed() * W * g)
	
	rhs = rhs_p1 + rhs_p2
	
	return rhs

# Returns a list of vertices coordinates (make sure the indices match)
def global_step(vertices, rigid_matrices):
	global faces 	#Use the global saved faces to make the practical possible.
	global p_B		#Use this var to save data to for RHS to use.
	global g		#Use this var to save data to for RHS to use.
	global lhs		#Use to solve the linear systems for every axis (x,y,z).
	global source_vertices #Need source vertices to calculate g.
	global boundary			#Use boundary to check which vertices are in the boundary and should not be edited (in the return part).
	global mesh_edges		#Used to get the edges, needed to calculate g.
	
	# Give an error if the length of the rigid matrices isn't correct
	if not(len(rigid_matrices) == len(vertices)):
		print("Not the right amount of rigid matrices?")
		return
		
	#First calculate g with the given vertices and rigid_matrices (has to be in the order of the edges, need to make sure the matrices are in this order as well!)
		
	# Calculate the G with x, y and z
	g_total = [Matrix(source_vertices[edge[0]] - source_vertices[edge[1]])
            * (rigid_matrices[edge[0]] + rigid_matrices[edge[1]]) / 2 for edge in mesh_edges]
			
	

	# Then split it
	gx = [this_g[0, 0] for this_g in g_total]
	gy = [this_g[0, 1] for this_g in g_total]
	gz = [this_g[0, 2] for this_g in g_total]
	
	#RHS has to be constructed 3 times, every time with different p_B and g, since we have to do those per axis.
	
	# Get the boundary vertices
	p_Bx = []
	p_By = []
	p_Bz = []
	for i in boundary:
		vert = vertices[i]
		p_Bx.append(vert[0])
		p_By.append(vert[1])
		p_Bz.append(vert[2])
	
	# X:
	p_B = p_Bx
	g = gx
	rhs_x = RHS(vertices, faces)
	xcoords = lhs.solve(list(rhs_x))

	# Y:
	p_B = p_By
	g = gy
	rhs_y = RHS(vertices, faces)
	ycoords = lhs.solve(list(rhs_y))
	
	# Z:
	p_B = p_Bz
	g = gz
	rhs_z = RHS(vertices, faces)
	zcoords = lhs.solve(list(rhs_z))
	
	# Get the points
	p_I = [Vec(v) for v in zip(xcoords, ycoords, zcoords)]
	result = []
	p_index = 0
	# Get the new vertex positions
	for i in range(len(vertices)):
		if i in boundary:
			result.append(vertices[i])
		else:
			result.append(p_I[p_index])
			p_index += 1		

	return result
	
# Returns the left hand side of least-squares system
def precompute(vertices, faces):
	# We're going to fill some globals
	global W			#Constant weights matrix
	global d_0I			#Constant d_0
	global d_0B			#Constant d_0
	global d_0N			#Constant d_0
	global boundary		#Constant boundary indices
	global mesh_edges	#Constant edge indices
	
	#Creates the left hand side of the system, also saves a few pieces of the data used here, to easily use them later for calculating the RHS.
	#Since d_0 is constant anyway we can save this data and use it later on. This is the case with the boundary as well.
	
	# Mesh edges
	mesh_edges = get_edges(vertices, faces)
		
	#Get the handles boundary from the handles
	boundary = get_boundary()
	if len(boundary) == 0:
		print("No handles specified by the rules in the practical document! Please call the handles handle_1, handle_1_dest, etc.")
		return
	
	# Construct d_0 and split it into d_0|I and d_0|B
	D0 = d_0(vertices, faces)
	Bvalues, Ivalues = slice_triplets(D0, boundary)
	# Also calculate the negated d_0I to save for later use.
	Nvalues = [(val[0], val[1], -val[2]) for val in Ivalues]
	
	#Need the amount of edges to make the sparse matrices.
	nrEdges = len(mesh_edges)
	
	# The d_0's and W for later use
	d_0B = ddm.Sparse_Matrix(Bvalues, nrEdges, len(boundary))
	d_0I = ddm.Sparse_Matrix(Ivalues, nrEdges, len(vertices) - len(boundary))
	d_0N = ddm.Sparse_Matrix(Nvalues, nrEdges, len(vertices) - len(boundary))
	W = weights(vertices, faces)

	# Construct LHS with the elements above and Cholesky it
	lhs = d_0I.transposed() * W * d_0I
	lhs.Cholesky()

	#Finally return the lhs
	return lhs

# Initial guess, returns a list of identity matrices for each vertex
def initial_guess(vertices):
	return [Identity(3) for _ in vertices]
	
def ARAP_iteration(vertices, faces, max_movement):
	global source_vertices  #Needed for the local step, but not passed through signature.
	global one_rings		#Needed for local step, not passed through signature (and expansive to compute again).
	
	#Local step.
	transforms = local_step(source_vertices, vertices, one_rings)
	
	#Global step
	result = global_step(vertices, transforms)

	# Returns the new target vertices as a list (make sure the indices match)
	return result
	
def DDM_Practical5(context):
	global lhs				#Used to initialize the lhs from precompute to the global lhs.
	global source_vertices	#Used to save the original mesh vertices which we need for the local steps.
	global one_rings		#Used to save the one_rings which are constant and needed for the loacl steps.
	global faces			#Used to save the faces indices, which are constant and needed in multiple functions.
	
	max_movement = 0.001
	max_iterations = 100

	vertices = get_vertices(context)
	faces = get_faces(context)
	
	# Neighbor_indices is terribly slow because we need to do it individually,
	# so we'll simply not use it, instead using a way faster way.
	one_rings = [[] for vertex in vertices]
	for face in faces:
		for vt in face:
			for vt2 in face:
				if vt != vt2 and not vt2 in one_rings[vt]:
					one_rings[vt].append(vt2)

	#Need to save the source vertices for later on
	source_vertices = copy.deepcopy(vertices)
	
	#Precompute some matrices and the lhs.
	lhs = precompute(vertices, faces)
	
	# get handles
	#Change the boundary vertices to the new positions according to the get_handles function.
	handles = get_handles(context.active_object)
	for verts, m in handles:
		for v in verts:
			#Multiply the handle vertices by the given transforms from get_handles to move these to their new position.
			org = vertices[v]
			#Since this is also a translation matrix, add a 4th variable to the vector.
			temp = Matrix(m) * Matrix([[org[0]], [org[1]], [org[2]], [1]])
			#Use Vec instead of Vector, since the mathutils vector has a .length function which we need every ARAP iteration (and also for the cotan weights).
			vertices[v] = Vec((temp[0,0], temp[1,0], temp[2,0]))
			
	# Initial guess:
	vertices = global_step(vertices, initial_guess(vertices))
	
	# ARAP until tolerance
	for i in range(max_iterations):
		# Loop a maximum amount of max_iterations, or until max|p'i(k) - p'i(k-1)| <= tolerance.
		newVertices = ARAP_iteration(vertices, faces, max_movement)
		
		# Check the maximum distance of the new vertices compared to the previous ones:
		boundary = get_boundary()
		maxDist = 0
		for j in range(len(vertices)):
			if j in boundary:
				continue
			#Get the length between the old and the new vertex, used to test against the tolerance.
			length = (Vec(newVertices[j] - vertices[j])).length
			if length > maxDist:
				maxDist = length

		#Set the vertices from this iteration as the vertices for the next iteration.
		vertices = newVertices
		
		if maxDist <= max_movement:
			#Smaller than tolerance, done!
			break
	
	#Show transformed mesh:
	# This was not in the practical description but it seemed the most logical
	show_mesh(faces, vertices)

#########################################################################
# You may place extra variables and functions here to keep your code tidy
#########################################################################

# Show mesh (from the last practicum)
# This is not in the practical but seemed logical
def show_mesh(faces, vertices):
	#First creates a new mesh and object
	newMesh = bpy.data.meshes.new("mesh")
	ob = bpy.data.objects.new("showObject", newMesh)

	#Then add it to the scene and select it as active.
	scnobj = bpy.context.scene.objects
	scnobj.link(ob)
	scnobj.active = ob
	ob.select = True

	#Finally we pass this data to the mesh and update the mesh.
	newMesh.from_pydata(vertices, [], faces)
	newMesh.update()

	return newMesh

#Function to get the edges from given vertices and faces.
def get_edges(vertices, faces):
	# A list with edges to return
	edges = []
	# checkedges (O(1)) to quickly check if we've already seen an edge
	checkEdges = set()
	for face in faces:
		for edge in [(face[0], face[1]), (face[1], face[2]), (face[0], face[2])]:
			stdEdge = (edge[1], edge[0]) if edge[0] > edge[1] else edge
			if stdEdge not in checkEdges:
				# Add this edge
				edges.append(stdEdge)
				checkEdges.add(stdEdge)
	return edges
	
#Function to get the flaps from a given edge. (Expensive but only used once when making the W matrix)
def get_flaps(edge, faces):
	#Loop through all faces to get the faces from this edge.
	#(this means check if both vertices are in the face)
	flaps = []
	for face in faces:
		if edge[0] in face and edge[1] in face:
			flaps.append(face)
			
	return flaps

#Returns all the boundary vertices indices from the handles in the active object.	
def get_boundary():
	#Get all the vertices from the handles from the active object.
	boundary = []
	handles = get_handles(bpy.context.active_object)
	for verts, m in handles:
		boundary += verts
	return boundary
	
# Find the vertices within the bounding box by transforming them into the bounding box's local space and then checking on axis aligned bounds.
def get_handle_vertices(vertices, bounding_box_transform, mesh_transform):

	result = []

	# Fibd the transform into the bounding box's local space
	bounding_box_transform_inv = bounding_box_transform.copy()
	bounding_box_transform_inv.invert()
	
	# For each vertex, transform it to world space then to the bounding box local space and check if it is within the canonical cube x,y,z = [-1, 1]
	for i in range(len(vertices)):
		vprime = vertices[i].co.copy()
		vprime.resize_4d()
		vprime = bounding_box_transform_inv * mesh_transform * vprime
		
		x = vprime[0]
		y = vprime[1]
		z = vprime[2]
		
		if (-1 <= x) and (x <= 1) and (-1 <= y) and (y <= 1) and (-1 <= z) and (z <= 1):
			result.append(i)

	return result

# Returns the local transform of the object
def get_transform_of_object(name):
	return bpy.data.objects[name].matrix_basis
	
# Finds the relative transform from matrix M to T
def get_relative_transform(M, T):
	
	Minv = M.copy()
	Minv.invert()
		
	return T * Minv
	
# Returns a list of handles and their transforms
def get_handles(source):
	
	result = []
	
	mesh_transform = get_transform_of_object(source.name)
	
	# Only search up to (and not including) this number of handles
	max_handles = 10
	
	# For all numbered handles
	for i in range(max_handles):
	
		# Construct the handles representative name
		handle_name = 'handle_' + str(i)
		
		# If such a handle exists
		if bpy.data.objects.get(handle_name) is not None:
			
			# Find the extends of the aligned bounding box
			bounding_box_transform = get_transform_of_object(handle_name)
			
			# Interpret the transform as a bounding box for selecting the handles
			handle_vertices = get_handle_vertices(source.data.vertices, bounding_box_transform, mesh_transform)
			
			# If a destination box exists
			handle_dest_name = handle_name + '_dest'
			if bpy.data.objects.get(handle_dest_name) is not None:
				
				bounding_box_dest_transform = get_transform_of_object(handle_dest_name)
				
				result.append( (handle_vertices, get_relative_transform(bounding_box_transform, bounding_box_dest_transform) ) ) 
				
			else:
			
				# It is a rigid handle
				#Fixed bug where m.identity() does not exist to this which does work.
				#m = Matrix([])
				#m.identity()
				m = Identity(4)
				result.append( (handle_vertices, m) )
			
	return result
	
# Slices a list of triplets and returns two lists of triplets based on a list of fixed columns
# For example if you have a set of triplets T from a matrix with 8 columns, and the fixed columns are [2, 4, 7]
# then all triplets that appear in column [1, 3, 5, 6] are put into "right_triplets" and all triplets that appear in column [2, 4, 7] are put into the set "left_triplets"
def slice_triplets(triplets, fixed_colums):

	left_triplets = []
	right_triplets = []

	# First find the complement of the fixed column set, by finding the maximum column number that appear in the triplets
	max_column = 0
	
	for triplet in triplets:
		if (triplet[1] > max_column):
			max_column = triplet[1]
	
	# and constructing the other columns from those
	other_columns = [x for x in range(0, max_column + 1) if x not in fixed_colums]
	
	# Now split the triplets
	for triplet in triplets:
	
		if (triplet[1] in fixed_colums):
			new_column_index = fixed_colums.index(triplet[1])
			left_triplets.append( (triplet[0], new_column_index, triplet[2]) )
		else:
			new_column_index = other_columns.index(triplet[1])
			right_triplets.append( (triplet[0], new_column_index, triplet[2]) )
			
	return (left_triplets, right_triplets)
