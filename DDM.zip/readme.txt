These are all small projects made for the course 3D modelling,
they only run with a special plugin called "ddmaddon" and are here
mostly to show that I can program with python. The code style is not
perfect as well, since we were not allowed to change the function signatures,
so the only way to get variables to other functions without signatures is
by using globals (and some things are calculated way more often then needed).