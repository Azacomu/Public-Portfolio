# File created on: 2017-05-16 11:31:56.385839
#
# IMPORTANT:
# ----------
# - Before making a new Practical always make sure you have the latest version of the addon!
# - For the assignment description and to download the addon, see the course website at: http://www.cs.uu.nl/docs/vakken/ddm/
# - Mail any bugs and inconsistencies you see to: uuinfoddm@gmail.com

import ddm
import bpy
from numpy.linalg import inv
from numpy.polynomial.polynomial import polyvander3d
from mathutils import Vector
from numpy import empty as new_Matrix
from numpy import matrix as Matrix
import numpy
from math import sqrt
import math

# You can perform the marching cubes algorithm by first constructing an instance of the marching cubes class:
#
# mc = My_Marching_Cubes()
# 
# and then calling the calculate function for this class:
# 
# mc.calculate(origin_x, origin_y, origin_z, x_size, y_size, z_size, cube_size)
# 
# Where:
# - (origin_x, origin_y, origin_z) is the bottom left coordinate of the area meshed by marching cubes
# - (x_size, y_size, z_size) is the number of cubes in each direction
# - cube_size is the length of the edge of a single cube
#
class My_Marching_Cubes(ddm.Marching_Cubes):
	# You may place extra members and functions here 
	
	#Initialize the variables as None (Will be set in DDM_Practical2 as they stay the same for all points)
	epsilon = None
	radius = None
	grid = None
	normalMap = None
	
	# This function returns the result of estimated function f(q) which is essentially the entire estimation plus the calculation of its result, note that the estimated polynomial is different for every q = (x, y, z)
	# The sample function checks the grid to get nearby points, then gets the constraint points, and passes only these points to all other functions. Finally, it calculates the value we need with the calculation
	# from the excercise.
	# Many of the other parameters to functions are not used. We wondered whether we should have the MatrixC function calculate the points as it has so many parameters, but this didn't seem logical at all.
	
	# We did notice that we got a lot of debris around the models. We tried a lot of things to fix this, to no avail.
	# We wondered finally if this even was our own mistake at all...
	
	def sample(self, x, y, z):
		#Check whether init went well
		if (self.epsilon == 0):
			print("ERROR: Epsilon initialized to 0!")
		
		points = self.grid.query((x, y, z), radius)
		if len(points) == 0:
			return float("inf")
		normals = list(map(lambda p: self.normalMap[p], points))
		points = list(map(lambda p: Vector(p), points))
		
		constraints = constraint_points(points, normals, self.epsilon, self.radius)
		
		#Get the matrix C for this point to use in the calculation to get the actual value of f(q)
		#We pass all points, MatrixC figures out which one to use
		matC = MatrixC(Vector((x, y, z)), constraints, normals, self.epsilon, self.radius)
		
		w = weights(Vector((x,y,z)), constraints)
		
		#Get a diagonal matrix of w
		matW = numpy.diag(w)
		
		# Vector d is the result from constraint_values, now only need to solve linear system to get the final points
		vecD = Vector(constraint_values(constraints, normals,
		                         self.epsilon, self.radius))
		
		matCT = matC.transpose()

		try:
			#Get the inverted left hand side
			ilhs = inv(matCT @ matW @ matC)
		except:
			# Apparently, the determinant is 0, just return 0
			# This is faster than first calculating the determinant
			# This is a safety check only and should not really happen with a correct epsilon!
			print("exception - matrix cannot be inverted")
			return math.inf
		
		rhs = matCT @ matW @ vecD
		
		a = rhs @ ilhs

		return a @ indeterminate(Vector((x, y, z)), indeterminateDegree)
		
# This function is called when the DDM Practical 2 operator is selected in Blender.
# It gets all needed data, and creates a grid.
# The distance of the maximum dimension is used for the cube size.
# Radius and number of cubes can be changed here, too.
# Then it passes all data to calculate, which calculates everything,
# and finally shows the mesh.
def DDM_Practical2(context):
	
	#Print line to see new run:
	print("\n\n##################\n\nINFO:\n\nNew run started!\n\n##################\n\n")
	# Get the data from the mesh
	points = get_vertices(context)
	normals = get_normals(context)
	
	tuples = []
	for point in points:
		tuples.append( (point[0], point[1], point[2]) )
	
	grid = ddm.Grid(tuples)
		
	#Make an instance of the marching cubes class and initialize it.
	mc = My_Marching_Cubes()
	mc.epsilon = CalculateEpsilon(points)
	mc.grid = grid
	
	#Create the dictionary with the points and the normals combined for easy access.
	mc.normalMap = {}
	for i in range(len(points)):
		mc.normalMap[(points[i].x, points[i].y, points[i].z)] = normals[i]
	
	minPoint = Vector([math.inf, math.inf, math.inf])
	maxPoint = Vector([-math.inf, -math.inf, -math.inf])
	
	#Go through all points to find the minimum and the maximum of the bounding box containing the whole point cloud.
	for point in points:
		for i in range(3):
			if point[i] < minPoint[i]:
				minPoint[i] = point[i]
			if point[i] > maxPoint[i]:
				maxPoint[i] = point[i]

	#Distance per dimension
	dimensionDist = [maxPoint[i] - minPoint[i] for i in range(3)]
	
	#Calculate radius as 1/10th of the bounding box containing all points.
	global radius
	radius = 0.1 * distance(minPoint, maxPoint)
	mc.radius = radius
	
	#Call the calculate function from the origin of the minimum point of the bounding box with the distance going to the
	#maximum point of the bounding box, subdevided in cubes, amount equal to numberOfCubesMaxDimension variable.
	numberOfCubesMaxDimension = 20
	print(minPoint)
	cubeSize = max(dimensionDist) / numberOfCubesMaxDimension
	show_mesh(mc.calculate(-minPoint[0], -minPoint[1], -minPoint[2], math.ceil((dimensionDist[0]) / cubeSize),
		math.ceil(dimensionDist[1] / cubeSize),
		math.ceil(dimensionDist[2] / cubeSize), cubeSize))


#########################################################################
# You may place extra variables and functions here to keep your code tidy
#########################################################################

# The degree that is used for the indeterminate function
indeterminateDegree = 1

radius = None

#Function to calculate the value of epsilon that we will use to make the mesh
def CalculateEpsilon(points):
	#We want to get the shortest distance between points that there is, then use
	#that minus a little bit as the epsilon.
	
	shortestDist = float("inf")
	for point in points:
		for point2 in points:
			if (point == point2): continue
			dist = distance(point, point2)
			if (dist < shortestDist):
				shortestDist = dist

	return shortestDist - 0.0001 #epsilon	
	
# Returns the points of the first object
def get_vertices(context):
	result = []

	for vertex in context.active_object.data.vertices:
		result.append( vertex.co )
	
	return result

# Returns the normals of the first object
def get_normals(context):
	
	if ('surface_normals' not in context.active_object):
		print("\n\n##################\n\nWARNING:\n\nThis object does not contain any imported surface normals! Please use one of the example point clouds provided with the assignment.\n\n##################\n\n")
		return []
		
	result = []
	
	for normal in context.active_object['surface_normals']:
		result.append( Vector( [normal[0], normal[1], normal[2] ] ) )
	
	return result

# The vector containing the values for 'c_m'
def constraint_points(points, normals, epsilon, radius):
	#Do we have to check the new epsilon values to still be within range?
	#According to the practical paper we do not, since it says that we simply get 3 times as many points.
	#So, just calculate all constraints from the given nearby points, which are the points themselves,
	#and the points offset in the direction of the normal times epsilon and -epsilon.
	result = []
	for i in range(len(points)):
		result.append(points[i])
		result.append(points[i] + epsilon * normals[i])
		result.append(points[i] - epsilon * normals[i])
	
	return result

# The vector 'd'
def constraint_values(points, normals, epsilon, radius):
	#Get the 0, epsilon and -epsilon values corresponding to the constraint_points.
	#Since we make the constraint point list in the order of 0, epsilon and -epsilon,
	#we create this list in the same order times the amount of original points that we had.
	return [0, epsilon, -epsilon] * (len(points) // 3)

# The vector (NOT matrix) 'W'
def weights(q, constraints):
	#Get the weights for every constraint and return them as a vector.
	#We do this by calling the Wendland function for every constraints that we
	#already calculated and pass to the function.
	return list(map(lambda center: Wendland(distance(q, center)), constraints))

# The vector that contains the numerical values of each term of the polynomial, this is NOT vector 'a'
def indeterminate(q, degree):
	return polyvander3d(q[0], q[1], q[2], [degree, degree, degree] )[0]
	
# Returns 'C'
def MatrixC(q, points, normals, epsilon, radius):
	#Get the indeterminate of q to get the length of the matrix rows.
	i = indeterminate(q, indeterminateDegree)

	#Make a C matrix and set the values of the rows to the indeterminates of the constraints in c.
	#The constraints of c are passed as the points to this function,
	#so make the matrix of the size of the constraints (the points) and the indeterminate,
	#then fill in the rows of the matrix with the indeterminates of the points.
	C = new_Matrix([len(points), len(i)])
	for ind in range(len(points)):
		C[ind, :] = indeterminate(points[ind], indeterminateDegree)
	
	return C
	
# Returns the Wendland weight for a given distance
def Wendland(distance):
	global radius # Uses the global radius (since the radius does not change)
	
	#First we calculate the (1 - r / h), with r the variable distance and h the radius calculated as
	#1/10th of the diagonal of the largest axis aligned bounding box.
	oneMinR = 1 - distance / radius

	#Then we calculate the complete Wendland function, (1 - r / h)^4 * (4r/h + 1)
	#This is why we needed the precalculated oneMinR to easily get the power of 4 from it.
	result = oneMinR**4 * (4 * distance / radius + 1)
	return result

# Returns the distance between vector 'a' and 'b'	
def distance(a, b):
	return (b - a).length

# Show mesh (from the last practicum)
def show_mesh(triangles):
	#First creates a new mesh and object
	newMesh = bpy.data.meshes.new("mesh")
	ob = bpy.data.objects.new("showObject", newMesh)
	
	#Then adds it to the scene and selects it as active.
	scnobj = bpy.context.scene.objects
	scnobj.link(ob)
	scnobj.active = ob
	ob.select = True

	vertexes = []
	faces = []
	faceID = {}
	maxFaceID = 0

	#Then we calculate all faceID's for the vertices in the triangle list and add them to seperate arrays.
	#We also give them their own faceID to connect the triangles with eachother (to create a connected mesh instead of seperate triangles)
	for tr in triangles:
		for v in tr:
			if not (v in faceID):
				faceID[v] = maxFaceID
				vertexes.append(v)
				maxFaceID += 1

	for (v1, v2, v3) in triangles:
		faces.append((faceID[v1], faceID[v2], faceID[v3]))

	#Finally we pass this data to the mesh and update the mesh.
	newMesh.from_pydata(vertexes, [], faces)
	newMesh.update()

	return newMesh
