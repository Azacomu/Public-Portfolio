# File created on: 2017-06-09 15:09:49.847605
#
# IMPORTANT:
# ----------
# - Before making a new Practical always make sure you have the latest version of the addon!
# - Delete the old versions of the files in your user folder for practicals you want to update (make a copy of your work!).
# - For the assignment description and to download the addon, see the course website at: http://www.cs.uu.nl/docs/vakken/ddm/
# - Mail any bugs and inconsistencies you see to: uuinfoddm@gmail.com

import ddm
import bpy
from mathutils import Vector
from numpy import matrix as Matrix
import numpy
import math
import bmesh

# Place additional imports here


class Mesh():

	# Construct a new mesh according to some data
	def __init__(self, vertices, faces):

		# The vertices are stored as a list of vectors
		self.vertices = vertices

		# The faces are stored as a list of triplets of vertex indices
		self.faces = faces

		# The uv-coordinates are stored as a list of vectors, with their indices
		# corresponding to the indices of the vertices (there is exactly one
		# uv-coordinate per vertex)
		self.uv_coordinates = []
		for vertex in vertices:
			self.uv_coordinates.append(Vector((vertex[0], vertex[2])))

		self.build_edge_list()

	# This function builds an edge list from the faces of the current mesh and stores it internally.
	# Make sure that each edge is unique. Remember that order does NOT matter, e.g. (1, 0) is the same edge as (0, 1).
	# The indices of the edges should correspond to the locations of the weights in your weight calculation.
	# All subsequent calls that do something with edges should return their
	# indices. Getting the actual edge can then be done by calling
	# get_edge(index).
	def build_edge_list(self):
		self.edges = []
		self.flaps = []
		
		# Dictionary that gives the flap that belongs to an edge
		edgeToFlap = {}
		
		for face in self.faces:
			for edge in [(face[0], face[1]), (face[1], face[2]), (face[0], face[2])]:
				stdEdge = (edge[1], edge[0]) if edge[0] > edge[1] else edge
				hasBeenSet = False
				if stdEdge in edgeToFlap:
					edgeToFlap[stdEdge].append(face)
				else:
					thisFlap = [face]
					edgeToFlap[stdEdge] = thisFlap
					self.edges.append(stdEdge)
					self.flaps.append(thisFlap)

	# ACCESSORS

	def get_vertices(self):
		return self.vertices

	def get_vertex(self, index):
		return self.vertices[index]

	def get_edges(self):
		return self.edges

	def get_edge(self, index):
		return self.edges[index]

	def get_faces(self):
		return self.faces

	def get_face(self, index):
		return self.faces[index]

	def get_uv_coordinates(self):
		return self.uv_coordinates

	def get_uv_coordinate(self, index):
		return self.uv_coordinates[index]
		
	# Returns the list of vertex coordinates belonging to a face.
	def get_face_vertices(self, face):
		return [self.get_vertex(face[0]), self.get_vertex(face[1]), self.get_vertex(face[2])]

	# Looks up the edges belonging to this face in the edge list and returns
	# their INDICES (not value). Make sure that each edge is unique (recall
	# that (1, 0) == (0, 1)). These should match the order of your weights.
	def get_face_edges(self, face):
		faceEdgeValues = [(face[0], face[1]), (face[1], face[2]), (face[0], face[2])]
		for i in range(len(faceEdgeValues)):
			edge = faceEdgeValues[i]
			faceEdgeValues[i] = (edge[1], edge[0]) if edge[0] > edge[1] else edge

		faceEdgeIDs = []
		for i in range(len(self.edges)):
			for faceEdge in faceEdgeValues:
				if faceEdge == self.edges[i]:
					faceEdgeIDs.append(i)
		return faceEdgeIDs

	# Returns the vertex coordinates of the vertices of the given edge (a pair
	# of vertex indices e.g. (0,1) )
	def get_edge_vertices(self, edge):
		return [self.get_vertex(edge[0]), self.get_vertex(edge[1])]

	# Returns the flap of the given edge belonging to edge_index, that is two
	# faces connected to the edge 1 for a boundary edge, 2 for internal edges
	def get_flaps(self, edge_index):
		return self.flaps[edge_index]
		flap = []
		for face in self.faces:
			faceEdges = [(face[0], face[1]), (face[0], face[2]), (face[1], face[2])]
			for (v1, v2) in faceEdges:
				if min(v1, v2) == edge[0] and max(v1, v2) == edge[1]:
					flap.append(face)
		return flap

	# Returns the length of the given edge with edge_index
	def get_edge_length(self, edge_index):
		#Get both vertices of the edge and calculate the length of the vertex between them.
		edge = self.edges[edge_index]
		v1 = self.get_vertex(edge[0])
		v2 = self.get_vertex(edge[1])
		return (v1 - v2).length

	# Returns whether the edge has two adjacent faces
	def is_boundary_edge(self, edge_index):
		#Check if 1 flap: 1 flap means that it is a boundary edge.
		return len(self.get_flaps(edge_index)) == 1

	# Returns the boundary of the mesh by returning the indices of the edges
	# (from the internal edge list) that lie around the boundary.
	def boundary_edges(self):
		#First check for every edge whether it is a boundary edge.
		boundary = [] #Boundary contains indices of edges.
		for i in range(len(self.edges)):
			if self.is_boundary_edge(i):
				boundary.append(i)
			
		#Safecheck: return empty if there were no boundaries.
		if len(boundary) == 0:
			return []
			
		#Sort the edges such that they are in order after another.
		result = [] #Result contains indices of the sorted edges.
		result.append(boundary[0])
		edge = self.edges[boundary[0]]
		vertIndex = edge[0]
		for i in range(len(boundary) - 1):
			#For every edge, find the next edge (One of the vertices the same, the other is the next to check on).
			for j in range(len(boundary)):
				newEdge = self.edges[boundary[j]]
				if (newEdge == edge):
					#Skip the edge itself.
					continue
				elif (newEdge[0] == vertIndex):
					vertIndex = newEdge[1]
					result.append(boundary[j])
					edge = newEdge
					break
				elif (newEdge[1] == vertIndex):
					vertIndex = newEdge[0]
					result.append(boundary[j])
					edge = newEdge
					break
					
		return result

	# Place any other accessors you need here

	
# This function is called when the DDM operator is selected in Blender.
def DDM_Practical4(context):
	#First get the active mesh
	M = get_mesh()

	#Since we can choose whatever radius we want ourselves, we chose a base value of 4.
	radius = 4
	
	# show_mesh on a copy of the active mesh with uniform UV coordinates, call this mesh "Uniform"
	show_mesh(Convex_Boundary_Method(M, uniform_weights(M, -1), radius), "Uniform")

	# show_mesh on a copy of the active mesh with cot UV coordinates, call this mesh "Cot"
	show_mesh(Convex_Boundary_Method(M, cotan_weights(M, -1), radius), "Cot")

	# show_mesh on a copy of the active mesh with boundary free UV coordinates, call this mesh "LSCM"
	show_mesh(LSCM(M), "LSCM")

# You may place extra functions here

# Slices a list of triplets and returns two lists of triplets based on a
# list of fixed columns
def slice_triplets(triplets, fixed_colums):
	left_index = 0
	right_index = 0

	left_triplets = []
	right_triplets = []

	for triplet in triplets:

		if (triplets[1] in fixed_colums):
			left_triplets.append((triplet[0], left_index, triplet[2]))
			left_index += 1
		else:
			right_triplets.append((triplet[0], right_index, triplet[2]))
			right_index += 1

	return (left_triplets, right_triplets)

# Returns the weights for each edge of mesh M.
# It therefore consists of a list of real numbers such that the index
# matches the index of the edge list in M.
def cotan_weights(M, r):
	#Get a weight for every edge, corresponding to the average of the cotangens of both opposide corners 
	#of the inner edge, or a dummy value for boundary edges.
	weights = []
	edges = M.get_edges()
	for i in range(len(edges)):
		edge = edges[i]
		flap = M.get_flaps(i)
		if len(flap) == 2:
			#First calculate the angles of the both corners opposite to the edge.
			cot = []
			for x in range(2):
				#First get the corner (check the 3 vertices from the face, the one not in the center edge is the corner to calculate the angle of).
				face = flap[x]
				corner = None
				for v in face:
					if v not in edge:
						corner = M.vertices[v]
						break
						
				#Then get the vertices from the corner to the vertices of the center edge.
				v1 = M.vertices[edge[0]] - corner
				v2 = M.vertices[edge[1]] - corner
				
				#Calculate the dotproduct between the 2 vertices to get the cosinus of the angle.
				#Then convert this to an actual angle (acos returns radiants!).
				angle = math.acos(v1.dot(v2) / (v1.length * v2.length))
				
				#Calculate the cotangens of this angle.
				cot.append(1/math.tan(angle))
				
			#Finally calculate the weight with both cotangens.
			weights.append((cot[0] + cot[1]) / 2)
			
		else:
			#Nonsense weight, value should not matter at all (Boundary edge).		
			weights.append(math.inf) 
	return weights

# Same as above but for uniform weights
def uniform_weights(M, r):
	#Since the uniform weight for every edge is always 1, 
	#just return a list of 1's with the same length as the amount of edges.
	weights = [1 for _ in M.get_edges()]
	return weights

# Given a set of weights, return M with the uv-coordinates set according
# to the passed weights
def Convex_Boundary_Method(M, weights, radius):
	#First create the boundary as u,v list
	boundary = M.boundary_edges()
	
	#Get the total length of the boundary and set the start of psi to 0.
	totalLength = sum([M.get_edge_length(boundary[i]) for i in range(len(boundary))])
	currentPsi = 0
	
	# Check which vertices are on the boundary.
	vertices = M.get_vertices()
	isBoundary = [False for _ in vertices]
	
	for edgeID in boundary:
		edge = M.get_edge(edgeID)
		isBoundary[edge[0]] = True
		isBoundary[edge[1]] = True
	
	# We now know which vertices are on the boundary
	# Make a list checking if something is on the boundary or not
	# and what the id on the correct list would be
	vertexToCorrectMatrix = [] # Contains (isBoundary, correctID)
	
	# Max ID of vertices on boundary and inner lists
	maxBoundaryID = 0
	maxInnerID = 0

	#Now sort edges on whether they are on the boundary or are inner vertices of the mesh.
	for i in range(len(isBoundary)):
		if isBoundary[i]:
			vertexToCorrectMatrix.append((True, maxBoundaryID))
			maxBoundaryID += 1
		else:
			vertexToCorrectMatrix.append((False, maxInnerID))
			maxInnerID += 1
	
	# Define and init known U/V coords
	Ub = [0 for _ in range(maxBoundaryID)]
	Vb = [0 for _ in range(maxBoundaryID)]
	
	# Set the UV coords on the boundary
	# And create the Ub and Vb lists
	
	# Start with the first vertex index, or the second one (whichever is not in the second boundary vertex)
	vertIndex = M.edges[boundary[0]][0]
	if M.edges[boundary[1]][0] == vertIndex or M.edges[boundary[1]][1] == vertIndex:
		vertIndex = M.edges[boundary[0]][1]
		
	#Add the values of every boundary edge to the Ub and Vb vectors needed for the RHS.
	for edge in boundary:
		thisEdge = M.edges[edge]
		uv = radius * Vector([math.cos(currentPsi), math.sin(currentPsi)])
		M.uv_coordinates[vertIndex] = uv
		
		#Negate the vals because we want to negate the RHS.
		Ub[vertexToCorrectMatrix[vertIndex][1]] = -uv.x
		Vb[vertexToCorrectMatrix[vertIndex][1]] = -uv.y
		
		#Add to the psi.
		currentPsi += (2 * math.pi * M.get_edge_length(edge)) / totalLength
		
		#Go to the next vertex index.
		if thisEdge[0] == vertIndex:
			vertIndex = thisEdge[1]
		else:
			vertIndex = thisEdge[0]
	
	#Create the d0 value lists.
	edges = M.get_edges()
	IValues = []
	BValues = []
	
	# For all edges, add the vertices to either the boundary values
	# or the inner values.
	for i in range(len(edges)):
		edge = edges[i]
		begin, end = edge
		
		beginMatInfo = vertexToCorrectMatrix[begin]
		endMatInfo = vertexToCorrectMatrix[end]
		
		# Add vertex to the correct list to directly split the matrix on the correct columns.
		(IValues if beginMatInfo[0] == False else BValues) \
			.append((i, beginMatInfo[1], 1))
		(IValues if endMatInfo[0] == False else BValues) \
			.append((i, endMatInfo[1], -1))
	
	# Now create the d0 matrices as well
	d0I = ddm.Sparse_Matrix(IValues, len(edges), maxInnerID)
	d0B = ddm.Sparse_Matrix(BValues, len(edges), maxBoundaryID)
	
	# The diagonal weights matrix
	W = ddm.Sparse_Matrix([(i, i, weights[i]) for i in range(len(weights))], len(weights), len(weights))
	
	# The left hand side
	lhs = d0I.transposed() * W * d0I
	
	# The right hand sides
	rhsU = d0I.transposed() * W * d0B * Ub
	rhsV = d0I.transposed() * W * d0B * Vb	
	
	# Solve to get the U and V coords
	innerUCoords = lhs.solve(rhsU)
	innerVCoords = lhs.solve(rhsV)
	
	# Set the UV coords for everything that is not the boundary
	j = 0
	for i in range(len(isBoundary)):
		if not isBoundary[i]:
			M.uv_coordinates[i] = (innerUCoords[j], innerVCoords[j])
			j += 1
	
	return M

# Using Least Squares Conformal Mapping, calculate the uv-coordinates of a
# given mesh M and return M with those uv-coordinates applied
def LSCM(M):
	# The radius is used because we'll fix one triangle on (2xradius, 0)
	radius = 3
	
	# The values for AI and AB (respectively)
	values = []
	fixedValues = []
	
	row = 0 # The starting row of the triangle
	vertexLen = len(M.get_vertices())
	
	# Add each triangle into the matrix
	for triangle in M.get_faces():
		# Which vertex of the current triangle we're handling
		triangleVertexNum = 0
		
		(i, j, k) = triangle # Split up the triangle
		for v in triangle:
			col = v * 2 # The column
			valuesToUse = values # Which values array we add to
			# Check if this is a fixed vertex
			if col < 2 or col >= vertexLen * 2 - 2:
				# Fixed vertex, will end up in AB
				valuesToUse = fixedValues
				if col >= vertexLen * 2 - 2:
					col -= vertexLen * 2 - 4
			else:
				# Not a fixed vertex, will end up in AI
				# Most vertices will have this
				col -= 2
			
			# The row relative to the top row from this triangle
			relRow = triangleVertexNum * 2
			
			# First, the identity matrix on the position of the triangle
			valuesToUse.append((row + relRow, col, 1))
			valuesToUse.append((row + relRow + 1, col + 1, 1))
			
			# Add a 2x2 M matrix to the matrix
			# This will be the cos/sin/-sin mini matrix, but with some transform
			# (either the negative or - I2x2) 
			# transform: num:Int, onDiag:Bool -> newNum
			def addM(transform, relativeRow):
				# Get the current IJK that we use for the corner
				if relativeRow == 0:
					i2, j2, k2 = i, j, k
				elif relativeRow == 2:
					i2, j2, k2 = j, k, i
				elif relativeRow == 4:
					i2, j2, k2 = k, i, j
				else: raise ValueError
				
				# Which row we're going to add values on
				rowStart = relativeRow + row
				# Get the vertices from the indices
				v1, v2, v3 = (M.get_vertex(i2), M.get_vertex(j2), M.get_vertex(k2))
				# length division: lij/ljk
				lendiv = (v1 - v2).length / (v3 - v2).length

				# Get the angle from the normalized vectors
				norm1 = (v1 - v2)
				norm1.normalize()
				norm2 = (v3 - v2)
				norm2.normalize()
				angle = math.acos(norm1.dot(norm2))

				# Add this mini-matrix to the big matrix
				valuesToUse.append((rowStart, col, transform(lendiv * math.cos(angle), True)))
				valuesToUse.append((rowStart + 1, col, transform(lendiv * math.sin(angle), False)))
				valuesToUse.append(
					(rowStart, col + 1, transform(lendiv * -math.sin(angle), False)))
				valuesToUse.append((rowStart + 1, col + 1, transform(lendiv * math.cos(angle), True)))
			
			# The -M** part
			relRow = (relRow + 2) % 6
			addM(lambda a, _: -a, relRow)
			# The M** - I22 part
			relRow = (relRow + 2) % 6
			addM(lambda a, onDiag: (a - 1 if onDiag else a), relRow)
			
			# Now, handle the next vertex
			triangleVertexNum += 1
			
		# New triangle, new starting row
		row += 6

	# Unknown part of matrix A (matrix AI)
	AI = ddm.Sparse_Matrix(values, len(M.get_faces()) * 6, vertexLen * 2 - 4)
	
	# Known part of matrix A (matrix AB)
	AB = ddm.Sparse_Matrix(fixedValues, len(M.get_faces()) * 6, 4)
	
	#Known values
	xB = [0 for _ in range(4)]
	
	# The x of the last vertex is known, the other known values are zero
	# Set to negative value (normally would be 2 * radius)
	# to effectively negate the whole rhs
	xB[2] = -2 * radius
	
	# Left and right hand side
	lhs = AI.transposed() * AI
	rhs = AI.transposed() * AB * xB
	
	# Solve and add first and last values
	solved = [0, 0] + lhs.solve(rhs) + [2 * radius, 0]
	
	# Set the UV coordinates of the mesh
	for i in range(len(solved) // 2):
		M.uv_coordinates[i] = (solved[i * 2], solved[i * 2 + 1])
	
	# Return the matrix
	return M

# Builds a Mesh class object from the active object in the scene.
# in essence this function extracts data from the scene and returns it as
# a (simpler) Mesh class, triangulated where nessecary.
def get_mesh():
	#First get the active object.
	current_obj = bpy.context.active_object
	vertices = []
	faces = []

	#Get the needed data from all the faces and add them to the lists.
	for face in current_obj.data.polygons:
		thisFaceVerts = face.vertices[:]
		# Triangulate this face and add it to the triangles list (as a (v1,v2,v3) triangle)
		for startpos in range(1, len(thisFaceVerts) - 1):
			verts = [current_obj.data.vertices[thisFaceVerts[0]],
                            current_obj.data.vertices[thisFaceVerts[startpos]],
                            current_obj.data.vertices[thisFaceVerts[startpos + 1]]]
			faces.append((verts[0].index, verts[1].index, verts[2].index))

	# Then add the coords of each vertex to the vertices list
	for vertex in current_obj.data.vertices:
		vertices.append(vertex.co)

	return Mesh(vertices, faces)

# Given a Mesh class M, create a new object with name in the scene with
# the data from M
def show_mesh(M, name):
	#First creates a new mesh
	newMesh = bpy.data.meshes.new("mesh")
		
	# Pass vertices and faces to the mesh, then update it
	newMesh.from_pydata(M.vertices, [], M.faces)
	newMesh.update()

	# Add an uv texture
	newMesh.uv_textures.new("script_set_uv_coords")
	
	# To easily set UV's, use bmesh
	bm = bmesh.new()
	bm.from_mesh(newMesh)
	
	# Get the first UV layer
	uv_layer = bm.loops.layers.uv[0]
	
	# Blender needs an update of the lookup table
	bm.faces.ensure_lookup_table()
	
	# Set the UV coords of each face
	lenFaces = len(bm.faces)
	for fi in range(lenFaces):
		v1, v2, v3 = M.get_face(fi)
		bm.faces[fi].loops[0][uv_layer].uv = M.get_uv_coordinate(v1)
		bm.faces[fi].loops[1][uv_layer].uv = M.get_uv_coordinate(v2)
		bm.faces[fi].loops[2][uv_layer].uv = M.get_uv_coordinate(v3)
	
	# Go back from bmesh to a standard mesh and update it
	bm.to_mesh(newMesh)
	newMesh.update()
	
	# Create a new object
	ob = bpy.data.objects.new(name, newMesh)

	# Then add it to the scene and select it as active.
	scnobj = bpy.context.scene.objects
	scnobj.link(ob)
	scnobj.active = ob
	ob.select = True
	
	# Finally, return the new mesh
	return newMesh
