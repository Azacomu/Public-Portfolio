	# File created on: 2017-05-23 15:59:23.785515
#
# IMPORTANT:
# ----------
# - Before making a new Practical always make sure you have the latest version of the addon!
# - For the assignment description and to download the addon, see the course website at: http://www.cs.uu.nl/docs/vakken/ddm/
# - Mail any bugs and inconsistencies you see to: uuinfoddm@gmail.com


import ddm
import bpy
import numpy
import random
import math
from mathutils import Vector

# To view the printed output toggle the system console in "Window ->
# Toggle System Console"

def mesh_from_array(A, n):
	#First creates a new mesh and object
	newMesh = bpy.data.meshes.new("mesh")
	ob = bpy.data.objects.new("showObject", newMesh)

	#Then adds it to the scene and selects it as active.
	scnobj = bpy.context.scene.objects
	scnobj.link(ob)
	scnobj.active = ob
	ob.select = True

	vertexes = []
	faces = []
	faceID = {}
	maxFaceID = 0

	# Add vertices and faces.
	for j in range(n):
		for i in range(n):
			ind = j * n + i
			vertexes.append(A[ind])
			# Add two faces for every vertex that's not on the first row/column.
			if i > 0 and j > 0:
				faces.append((ind - 1, ind - n, ind - n - 1))
				faces.append((ind - 1, ind, ind - n))
	
	print(vertexes)
	
	# Finally we pass this data to the mesh and update the mesh.
	newMesh.from_pydata(vertexes, [], faces)
	newMesh.update()

	return newMesh
	
def De_Casteljau_Point(currentPoints, n, u, v):
	# Run through all points to get a final improved point according to the u and v position on the mesh.
	tempPoints = []
	for i in range(0, n):
		# Run through one row of points.
		tempPoints.append(De_Casteljau_2D([currentPoints[j] for j in range(i * n, (i + 1) * n)], u))
	# Use the returned points of the rows for the controlpoints of the columns.
	return De_Casteljau_2D(tempPoints, v)
	
def De_Casteljau_2D(controlPoints, u):
	# Run De Casteljau for one line of controlPoints.
	if len(controlPoints) == 2:
		return NewPoint(controlPoints[0], controlPoints[1], u)
	elif len(controlPoints) < 2:
		print("ERROR, not enough control points for De Casteljau 2D!")
		return
	# For every 2 vertices, get the new point and then return this algorithm recursively with those points.
	newPoints = []
	for i in range(1, len(controlPoints)):
		newPoints.append(NewPoint(controlPoints[i - 1], controlPoints[i], u))
	
	return De_Casteljau_2D(newPoints, u)

def NewPoint(v1, v2, u):
	#Returns the point on u between 2 vertices.
	vs = []
	for i in range(3):
		vs.append(v1[i] + u * (v2[i] - v1[i]))
	return (vs[0], vs[1], vs[2])

def De_Casteljau(A, n, s):
	#Special case s == 0 returns the same mesh.
	if s == 0:
		return A

	subs = subdivisions(n, s)
	stepvar = subs - 1
	newPoints = []
	#Run Casteljau for all rows.
	for j in range(0, subs):
		#Run Casteljau for all columns.
		for i in range(0, subs):
			newPoints.append(De_Casteljau_Point(A, n, i/stepvar, j/stepvar))
	
	return newPoints

# Get the new control points for splitting a bezier curve into two
def De_Casteljau_2D_split(controlPoints, u):
	#Run De Casteljau for one line of controlPoints
	if len(controlPoints) == 2:
		lastPoint = NewPoint(controlPoints[0], controlPoints[1], u)
		return ([lastPoint], [lastPoint])
	elif len(controlPoints) < 2:
		print("ERROR, not enough control points for De Casteljau 2D!")
		return
	
	# For every 2 vertices, get the new point and then return this algorithm
	# recursively with those points.
	newPoints = []
	for i in range(1, len(controlPoints)):
		newPoints.append(NewPoint(controlPoints[i - 1], controlPoints[i], u))

	(first, second) = De_Casteljau_2D_split(newPoints, u)
	
	# Return the part of the split curve we now know
	return ([newPoints[0]] + first, second + [newPoints[len(newPoints) - 1]])

# Split a bezier surface (with given control points and n)
# into four bezier surfaces, each with the same amount of control points
def split(currentPoints, n):
	#Split along columns (into two sets of rows)
	bottomRows = [[] for i in range(0, n)]
	topRows = [[] for i in range(0, n)]
	for i in range(0, n):
		#Run through one column of points and split it into two
		bottom, top = De_Casteljau_2D_split(
			[currentPoints[j] for j in range(i, i + n * n, n)], 0.5)
			
		# Add the first and last control point (that lie on the surface)
		bottom = [currentPoints[i]] + bottom
		top = top + [currentPoints[i + n * n - n]]
		
		# Add the columns to the rows
		for j in range(0, n):
			bottomRows[j].append(bottom[j])
			topRows[j].append(top[j])

	topLeft = []
	bottomLeft = []
	topRight = []
	bottomRight = []
	
	#And then along rows
	for i in range(0, n):
		#Run along the top half and split it into two
		left, right = De_Casteljau_2D_split(topRows[i], 0.5)
		left = [topRows[i][0]] + left
		right.append(topRows[i][len(topRows) - 1])
		topLeft += left
		topRight += right
		
		#Run along the bottom half and split it into two
		left, right = De_Casteljau_2D_split(bottomRows[i], 0.5)
		left = [bottomRows[i][0]] + left
		right.append(bottomRows[i][len(bottomRows) - 1])
		bottomLeft += left
		bottomRight += right
	
	return (bottomLeft, bottomRight, topLeft, topRight)

# Generate a random control mesh
def control_mesh(n, length):
	mesh = []
	l = length / (n - 1) # Length between two control points
	# Generate a mesh, sorted on increasing x first and then increasing y
	# So something like (0, 0) (1, 0) (0, 1) (1, 1) etc. as we understood it
	# (seemed the most logical way to sort it and this is what we think we needed to do)
	for j in range(n):
		for i in range(n):
			# Use z = 0 on edges and a random z in other places
			z = 0
			if i > 0 and j > 0 and i < n - 1 and j < n - 1:
				z = random.random()
			mesh.append((i * l, j * l, z))
	return mesh

def line_intersect(A, n, p1, p2, e):
	#Check intersection with this part.
	#Create the boundingbox.
	minPoint = Vector([math.inf, math.inf, math.inf])
	maxPoint = Vector([-math.inf, -math.inf, -math.inf])
	
	#Find the minimum and maximum points of the bounding volume of the current split.
	for point in A:
		for i in range(3):
			if point[i] < minPoint[i]:
				minPoint[i] = point[i]
			if point[i] > maxPoint[i]:
				maxPoint[i] = point[i]
	
	# Intersect the line with the AABB (because this is always a AABB)
	# Do a slab test, intersecting with all (6) planes that form the box 
	
	#Get the normalized direction between the two points
	direction = Vector(p2) - Vector(p1)
	direction.normalize()
	
	# We haven't intersected with a plane yet
	tmin = -math.inf
	tmax = math.inf
	
	# Try each plane
	for i in range(0, 3):
		if direction[i] != 0:
			# There are two collisions with the two planes of the box in this
			# direction.
			t1 = (minPoint[i] - p1[i]) / direction[i]
			t2 = (maxPoint[i] - p1[i]) / direction[i]
			
			tmin = max(tmin, min(t1, t2))
			tmax = min(tmax, max(t1, t2))
		else:
			# On this axis, the line never touches the planes
			# Return False if it lies outside the plane, or continue if it lies
			# within.
			if minPoint[i] > p1[i] or maxPoint[i] < p1[i]:
				return False

	# If we don't intersect, return false
	if tmax < tmin:
		return False
	
	#If there was an intersection, first check whether we are at desired subdivision level yet.
	#Check size of the boundingbox.
	if ((maxPoint - minPoint).length <= e):
		return True
	
	#Else split and try those parts as well, return the outcome of these 4 combined.
	(a,b,c,d) = split(A, n)
	return (line_intersect(a, n, p1, p2, e) or
		line_intersect(b, n, p1, p2, e) or
		line_intersect(c, n, p1, p2, e) or
		line_intersect(d, n, p1, p2, e))

def subdivisions(n, s):
	#Calculate the new size of the mesh after s subdivisions, the number of subdivisions
	#is equal to 1 between every pair of vertices, which is equal to the number of vertices - 1
	#This gives us a total count of the original vertices + s * (n - 1)
	#(since the number of pairs is equal to n - 1)
	return n + (s * (n - 1))

def DDM_Practical3(context):
	# Parameters
	n = 10
	length = 1
	s = 3

	# Create the control mesh
	A = control_mesh(n, length)
	# Run De Casteljau on the mesh
	B = De_Casteljau(A, n, s)

	# Calculate the new size of the subdivided surface
	n_B = subdivisions(n, s)

	# Then show the mesh
	mesh_from_array(B, n_B)

	# And do a line intersection
	p1 = (1, 2, 3)
	p2 = (3, 4, 5)

	print(line_intersect(A, n, p1, p2, 0.01))