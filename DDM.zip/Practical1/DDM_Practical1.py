# File created on: 2017-04-25 14:01:26.847907
#
# IMPORTANT:
# ----------
# - Before making a new Practical always make sure you have the latest version of the addon!
# - For the assignment description and to download the addon, see the course website at: http://www.cs.uu.nl/docs/vakken/ddm/
# - Mail any bugs and inconsistencies you see to: uuinfoddm@gmail.com

import bpy
import math
from mathutils import Vector as Vector
from mathutils import Matrix as Matrix

# To view the printed output toggle the system console in "Window -> Toggle System Console"

#Made by Florian van Strien (5632757) and Martin Boers (5676401)

# This function is called when the DDM operator is selected in Blender.
def DDM_Practical1(context):

	# DONE: create a copy of the active model that is mirrored in the xy-plane, then sheared in the x-direction by the z-direction, and finally rotated 45 degrees around the z-axis.

	# First gets the triangles of the current active object
	tris = get_triangles(context) 
	newtris = []
	#Scaling in the direction of z with scale -1 is to mirror in the xy-plane (this is the same as mirroring in xy as you only change z to -z to mirror in xy)
	#(looks weird with the bunny because it already has default rotation of some kind in blender)
	mirrorXY = scale_matrix(-1, Vector([0,0,1]))
	for vertexes in tris:
		#For each triangle, for each vertex:
		newvertexes = []
		for (v1, v2, v3) in vertexes:
			#Transform it by first mirroring it (scaling z by -1), then shearing it, then rotating it by 45 degrees around the z axis
			(r1, r2, r3) = mirrorXY * Vector([v1,v2,v3])
			(r1, r2, r3) = shear_matrix(Vector([1, 0, 0]), Vector([0.7, 0.7, 0])) * Vector([r1, r2, r3])
			(r1, r2, r3) = rotation_matrix(45, Vector([0, 0, 1])) * Vector([r1, r2, r3])
			#Append it to the new vertexes
			#NOTE: Since assignment 3 said that we should not make a translation matrix nor translate the object in the scene,
			#we have not translated the object to show it "side-by-side" as stated in assignment 7, it was kind of unclear whether we had to
			#translate the object for assignment 7 or not.
			newvertexes.append(Vector([r1, r2, r3]))
		newtris.append(newvertexes)

	#Show the new mesh
	show_mesh(newtris)

	
# Returns a matrix that describes a counter clockwise rotation of d degrees around v
def rotation_matrix(d, v):
	#First calculate the angle in radians and normalize the vector (important for the rotation, since we only want the direction of the rotation)
	angle = math.radians(d)
	v.normalize()
	
	#Precalculate some variables used in the matrix
	angleCos = math.cos(angle)
	angleSin = math.sin(angle)
	angle1Cos = 1 - math.cos(angle) # One minus cos of angle
	x, y, z = v
	
	#Finally create a matrix which gives the (counter-clockwise) rotation of angle radians in the direction of v.
	#Which is given by the new bases: (with a is d in radians)
	#Bx' = (cos(a) + Vx^2 * (1 - cos(a)), Vx * Vy * (1 - cos(a)) + Vz * sin(a), Vx * Vz * (1 - cos(a)) - Vy * sin(a))
	#By' = (Vx * Vy * (1 - cos(a)) - Vz * sin(a), cos(a) + Vy^2 * (1 - cos(a)), Vz * Vy * (1 - cos(a)) + Vx * sin(a))
	#Bz' = (Vx * Vz * (1 - cos(a)) + Vy * sin(a), Vx * Vz * (1 - cos(a)) - Vx * sin(a), cos(a) + Vz^2 * (1 - cos(a)))
	#And then we put the new bases in the colums of the matrix, so that every vector multiplied with this matrix will be in the 
	#new base that is a rotation around v.
	return Matrix([
		[angleCos + x * x * angle1Cos, x * y * angle1Cos - z * angleSin, x * z * angle1Cos + y * angleSin],
		[x * y * angle1Cos + z * angleSin, angleCos +  y * y * angle1Cos, y * z * angle1Cos - x * angleSin],
		[x * z * angle1Cos - y * angleSin, z * y * angle1Cos + x * angleSin, angleCos + z * z * angle1Cos]])

# Returns a matrix that describes a scaling by a factor r in the direction v
def scale_matrix(r, v):
	#Creates a matrix with each direction given in v scaled by the factor r, this happens by starting with the default factor of 1
	#such that if there is for example a scale of 2 in the direction of (1,0,0), only the x gets multiplied by 2, but also that the other
	#variables (y and z) stay the same (since those directions are not scaled and should stay the same).
	#Since scale only alters the component itself (x, y or z), the other values in the matrix are 0.
	return Matrix([
		[r * v.x + 1 - v.x, 0, 0], 
		[0, r * v.y + 1 - v.y, 0], 
		[0, 0, r * v.z + 1 - v.z]])
	
# Returns a matrix that describes a shearing in the direction of v by the direction of u
def shear_matrix(u, v):
	#We change the bases so that in the new base u is mapped on v, this means that we have to translate the bases
	#such that Bx' = Bx + (v - u), By' = By + (v - u) and Bz' = Bz + (v - u)
	#We can then use the new bases in a transformation matrix by putting the bases in the columns of the matrix,
	#which will translate any vectors multiplied with this matrix according to the new base.
	#(Added 1's to the "normal" x, y and z since we start with the unit vectors as bases and change those to new bases).
    return Matrix([	
		[1 + (v.x - u.x), v.x - u.x, v.x - u.x],
		[v.y - u.y, 1 + (v.y - u.y), v.y - u.y],
		[v.z - u.z, v.z - u.z, 1 + (v.z - u.z)]])
	
# Returns the faces of the active object as a list of triplets of points
def get_triangles(context):
	current_obj = context.active_object
	triangles = []

	# For all faces...
	for face in current_obj.data.polygons:
		thisFaceVerts = face.vertices[:]
		# Triangulate this face and add it to the triangles list (as a (v1,v2,v3) triangle)
		for startpos in range(1, len(thisFaceVerts) - 1):
			triangles.append((current_obj.data.vertices[thisFaceVerts[0]].co,
				current_obj.data.vertices[thisFaceVerts[startpos]].co,
				current_obj.data.vertices[thisFaceVerts[startpos + 1]].co))

	return triangles
	#return [(Vector([0, 0, 0]), Vector([0, 1, 0]), Vector([1, 1, 0])), (Vector([0, 0, 1]), Vector([0, 1, 1]), Vector([1, 1, 1]))]

# Builds a mesh using a list of triangles
def show_mesh(triangles):
	#First creates a new mesh and object
	newMesh = bpy.data.meshes.new("mesh")
	ob = bpy.data.objects.new("showObject", newMesh)
	
	#Then adds it to the scene and selects it as active.
	scnobj = bpy.context.scene.objects
	scnobj.link(ob)
	scnobj.active = ob
	ob.select = True

	vertexes = []
	faces = []
	faceID = {}
	maxFaceID = 0

	#Then we calculate all faceID's for the vertices in the triangle list and add them to seperate arrays.
	#We also give them their own faceID to connect the triangles with eachother (to create a connected mesh instead of seperate triangles)
	for tr in triangles:
		for v in tr:
			v.freeze()
			if not (v in faceID):
				faceID[v] = maxFaceID
				vertexes.append(v)
				maxFaceID += 1

	for (v1, v2, v3) in triangles:
		faces.append((faceID[v1], faceID[v2], faceID[v3]))

	#Finally we pass this data to the mesh and update the mesh.
	newMesh.from_pydata(vertexes, [], faces)
	newMesh.update()

	return newMesh