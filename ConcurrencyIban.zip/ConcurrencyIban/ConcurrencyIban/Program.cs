﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Security.Cryptography;

namespace ConcurrencyIban
{
    class Program
    {
        static public Thread[] threads;
        static public int totalCount;
        static public int found;
        static public MyLock Lock;
        static public bool cancel;

        static void Main(string[] args)
        {
            //First read the command from console.
            string[] temp = Console.ReadLine().Split();
            int l = int.Parse(temp[0]);
            int b = int.Parse(temp[1]);
            int e = int.Parse(temp[2]);
            int m = int.Parse(temp[3]);
            int p = int.Parse(temp[4]);
            int u = int.Parse(temp[5]);
            string hash = temp[6];

            threads = new Thread[p];
            cancel = false;
            Lock = new MyLock();
            totalCount = 0;
            found = -1;

            //Devide the searcharea to all threads.
            int amount = e - b;
            int leftover = amount % p;
            int baseAmount = amount / p;
            int lower = b;
            for (int i = 0; i < p; i++)
            {
                int upper = lower + baseAmount;
                //For the first #leftover threads, give 1 more to devide the range as fair as possible
                if (i < leftover)
                    upper++;
                //Make a new range object and let the task complete the required method.
                RangeObject rangeObj = new RangeObject(lower, upper, m, hash, l == 0);
                switch (u)
                {
                    case 0:
                        threads[i] = new Thread(rangeObj.Count);
                        break;
                    case 1:
                        threads[i] = new Thread(rangeObj.List);
                        break;
                    case 2:
                        threads[i] = new Thread(rangeObj.Search);
                        break;
                }
                threads[i].Start();
                lower = upper;
            }

            //Wait for all threads to be done (or terminated).
            foreach (Thread thread in threads)
                thread.Join();

            //Finally write final results to console.
            switch(u)
            {
                case 0:
                    Console.WriteLine(totalCount);
                    break;
                case 2:
                    Console.WriteLine(found);
                    break;
            }

            //Temp for seeing the results
            Console.ReadLine();
        }
    }
    class RangeObject
    {
        int lower;
        int upper;
        int m;
        string hash;
        bool myLock;
        SHA1 sha1 = SHA1.Create();

        //Make a new rangeobject, with all data needed for the thread
        public RangeObject(int lower, int upper, int m, string hash, bool myLock)
        {
            this.lower = lower;
            this.upper = upper;
            this.hash  = hash;
            this.m = m;
            this.myLock = myLock;
        }

        //Check whether the given number passes the 'm-proef'
        public bool Check(int num)
        {
            int div = num;
            int i = 1;
            int result = 0;

            while (div != 0)
            {
                result += i * (div % 10);
                div /= 10;
                i++;
            }

            return result % m == 0;
        }

        //Count how many numbers in given range pass the 'm-proef'
        public void Count()
        {
            for(int i = lower; i < upper; i++)
            {
                if (Check(i))
                {
                    if (myLock)
                    {
                        MyLock.Lock();
                        Program.totalCount++;
                        MyLock.Unlock();
                    }
                    else
                    {
                        lock (Program.Lock)
                        {
                            Program.totalCount++;
                        }
                    } 
                }
            }
        }

        //List all numbers that pass the 'm-proef'
        public void List()
        {
            for (int i = lower; i < upper; i++)
            {
                if (Check(i))
                {
                    if (myLock)
                    {
                        MyLock.Lock();
                        Program.totalCount++;
                        Console.WriteLine(Program.totalCount + " " + i);
                        MyLock.Unlock();
                    }
                    else
                    {
                        lock (Program.Lock)
                        {
                            Program.totalCount++;
                            Console.WriteLine(Program.totalCount + " " + i);
                        }
                    }
                }
            }
        }

        //Check the SHA1 hash of all numbers in given range to find the hash
        public void Search()
        {
            for (int i = lower; i < upper; i++)
            {
                //Check whether task should cancel
                if (Program.cancel)
                    break;
                
                //Only check the SHA if the number is valid (SHA takes way longer to calculate)
                if (Check(i))
                {
                    if (Hash(i) == hash)
                    {
                        //If the hash of i is the same as wanted hash, set found as i and terminate all threads
                        Program.found = i;
                        Program.cancel = true;
                        break;
                    }
                }
            }
        }

        //Calculate the hash string from given number
        string Hash(int num)
        {
            //First hash all bytes of given number
            byte[] bytes = Encoding.ASCII.GetBytes(num.ToString());
            byte[] hash = sha1.ComputeHash(bytes);

            //Then build a string from the hashed bytes
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                builder.Append(hash[i].ToString("x2"));
            }
            return builder.ToString();
        }
    }
    class MyLock
    {
        static public int TaS = 0;

        static public void Lock()
        {
            //Only allow the thread to continue if the lock is 0 (= unlocked)
            while (Interlocked.Exchange(ref TaS, 1) == 1) ;
        }
        static public void Unlock()
        {
            //Use interlocked to make sure the value is flushed
            Interlocked.Exchange(ref TaS, 0);
        }
    }
}
