-----How to build the game:-----
1. Make sure that Haskell has been installed on your pc: https://www.haskell.org/platform/
(2. Initialize a sandbox: in cmd (in the folder in which setup.hs is) run: "cabal sandbox init") You can skip this part, if you want the packages installed globally.
3. Install required packages, (in the folder in which setup.hs is) run: "cabal install"
4. You can now open the made .exe in the build folder, or use "cabal run" in cmd (in the folder in which setup.hs is) to run the game, enjoy :D

If you do not want to build the game, or it does not work, there is a prebuild one in "build.zip", the exe is called lambda-wars.exe.