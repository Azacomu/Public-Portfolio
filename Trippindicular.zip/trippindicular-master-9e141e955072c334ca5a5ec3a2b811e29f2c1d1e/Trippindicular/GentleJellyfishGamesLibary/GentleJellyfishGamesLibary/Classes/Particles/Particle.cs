﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Obsolete, still here for using later on (we continue the project after this period).
//Base class used for all particles.
public class Particle
{
    protected Texture2D texture;
    protected Vector2 position;
    protected Vector2 velocity;
    protected Color color;
    protected bool alive;
    protected float maxAge;
    protected float currAge;

    public bool Alive => alive;

    //Initialize a particle with a certain age at witch it will be removed, magAge 0 is unlimited.
    public Particle(Texture2D texture, Vector2 position, Vector2 velocity, Color color, float maxAgeSeconds)
    {
        this.texture = texture;
        this.position = position;
        this.velocity = velocity;
        this.color = color;
        maxAge = maxAgeSeconds;
        if (maxAge == 0)
            currAge = -1;
        alive = true;
    }

    public virtual void Update(GameTime gameTime)
    {
        //Change the position according to the velocity, this way is used as it is the most efficient one.
        Vector2 t = new Vector2();
        Vector2.Multiply(ref velocity, (float)gameTime.ElapsedGameTime.TotalSeconds, out t);
        Vector2.Add(ref t, ref position, out position);

        //If current age is -1, maxAge is unlimited, so don't update ages then.
        if (currAge != -1)
        {
            currAge += (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (currAge > maxAge)
                alive = false;
        }
    }
    public virtual void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Draw(texture, position, color);
    }

}

