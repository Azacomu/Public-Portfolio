﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Obsolete, still here for using later on (we continue the project after this period).
public class BlingParticle
{
    //TODO
}

