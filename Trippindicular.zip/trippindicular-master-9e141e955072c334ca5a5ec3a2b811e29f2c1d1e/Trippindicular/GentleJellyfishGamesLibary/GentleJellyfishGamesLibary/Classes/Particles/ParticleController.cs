﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Obsolete, still here for using later on (we continue the project after this period).
//Class that controls all particles, it updates them, draws them and deletes them once they died.
public class ParticleController : Controller
{
    protected List<Particle> particles;
    protected Texture2D pixel;
    protected Texture2D smoke;

    public ParticleController() : base()
    {
        particles = new List<Particle>();
    }

    public override void Update(GameTime gameTime)
    {
        for (int i = particles.Count; i >= 0; i--)
        {
            Particle p = particles[i];
            p.Update(gameTime);
            if (!p.Alive)
                particles.Remove(p);
        }
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        foreach (Particle p in particles)
            p.Draw(spriteBatch);
    }

    public void CreateSmoke(Vector2 centerPosition, float timeInSeconds)
    {

    }
    public void CreateBling(Vector2 centerPosition, float timeInSeconds)
    {

    }
    public void CreateMagic(Vector2 centerPosition, Vector2 objVelocity)
    {

    }
}

