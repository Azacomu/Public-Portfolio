using System;

namespace GentleJellyfishGamesLibrary
{
#if WINDOWS || XBOX
    static class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
#endif
}

