﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;

//Class used for objects with animations, this is the basic class that loads and plays those animations. (On top of everything in spritegameobject.)
public class AnimatedGameObject : SpriteGameObject
{
    protected Dictionary<string, Animation> animations;
    protected Vector2 oldPosition;
    protected SpriteSheet hitboxSprite;
    protected bool solidCollision;

    //Readonly properties.
    public Animation Current => sprite as Animation;
    public SpriteSheet HitboxSprite => hitboxSprite;
    public Vector2 OldPosition => oldPosition;
    public bool SolidColission => solidCollision;

    public AnimatedGameObject(string id = "", int layer = 0) : base("", 1, id, layer)
    {
        animations = new Dictionary<string, Animation>();
        hitboxSprite = new SpriteSheet("hitboxVert");
    }
    //Load a new animation, with given settings.
    public void LoadAnimation(string assetname, string id, bool looping, float frametime = 0.1f)
    {
        Animation anim = new Animation(assetname, looping, frametime);
        animations[id] = anim;
    }
    //Play animation with the given id and mirror it if needed.
    public void PlayAnimation(string id)
    {
        if (sprite == animations[id])
            return;
        if (sprite != null)
            animations[id].Mirror = sprite.Mirror;
        animations[id].Play();
        sprite = animations[id];
        origin = new Vector2(sprite.Width / 2, sprite.Height);
    }

    //Update the animation and the position and checks if there is a solid collision after moving.
    public override void Update(GameTime gameTime)
    {
        if (sprite == null)
            return;
        Current.Update(gameTime);
        oldPosition = position;
        base.Update(gameTime);
        solidCollision = CheckSolidCollision();
    }

    //Checks whether an animated object is colliding with a solid object.
    public bool CheckSolidCollision()
    {
        foreach (GameObject obj in GameWorld.SolidObjects)
        {
            SpriteGameObject sprObj = obj as SpriteGameObject;
            if (sprObj == null || !sprObj.Visible || obj == this)
                continue;

            Rectangle intersect = Collision.Intersection(BoundingBox, sprObj.BoundingBox);

            for (int x = 0; x < intersect.Width; x++)
                for (int y = 0; y < intersect.Height; y++)
                {
                    int thisx = intersect.X - (int)(GlobalPosition.X - Origin.X) + x;
                    int thisy = intersect.Y - (int)(GlobalPosition.Y - Origin.Y) + y;
                    int objx = intersect.X - (int)(obj.GlobalPosition.X - sprObj.Origin.X) + x;
                    int objy = intersect.Y - (int)(obj.GlobalPosition.Y - sprObj.Origin.Y) + y;
                    if (HitboxSprite.GetPixelColor(thisx, thisy).A != 0
                        && sprObj.Sprite.GetPixelColor(objx, objy).A != 0)
                    {
                        return true;
                    }
                }
        }
        return false;
    }
}

