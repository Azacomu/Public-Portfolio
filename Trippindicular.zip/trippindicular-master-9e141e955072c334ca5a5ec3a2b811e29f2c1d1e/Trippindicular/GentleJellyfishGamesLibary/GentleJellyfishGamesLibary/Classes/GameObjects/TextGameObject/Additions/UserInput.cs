﻿using Microsoft.Xna.Framework.Input;

//Class used to draw a string that the user typed himself.
public class UserInput : TextGameObject
{
    const int maxSize = 16;
    protected InputHelper ihTemp;
    public bool Locked = false;
    public bool AutoReset = false;

    public UserInput() :base("font")
    {
        text = "";
    }

    //Get the keypresses and make a string from them in the inputhandler, then draw it on screen by putting it in this object.
    public override void HandleInput(InputHelper ih)
    {
        ihTemp = ih;
        if (!Locked)
        {
            ih.GetKeysPressedText();
            if (ih.InputString.Length <= maxSize)
            {
                text = ih.InputString;
            }
            else
            {
                ih.InputString = ih.InputString.Substring(0, maxSize);
            }
            if (ih.KeyPressed(Keys.Enter))
            {
                Locked = true;
                ih.ResetInput();
            }
        }
        if((Locked || text.Length >= maxSize) && AutoReset)
        {
            Reset();
        }
    }
    //Empty the string and get keypresses again when reset.
    public override void Reset()
    {
        Locked = false;
        text = "";
        ihTemp?.ResetInput();
    }
}

