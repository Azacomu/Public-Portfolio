﻿using System;
using Microsoft.Xna.Framework;

//Class for a clock that you can see on the screen as a string, used to keep track of the time the player is playing.
public class TextTimer : TextGameObject
{
    protected TimeSpan timePlaying;
    protected int oldSec;
    protected bool paused;

    public int Seconds => timePlaying.Seconds;
    public int Minutes => (int)timePlaying.TotalMinutes;

    public bool Paused
    {
        get { return paused; }
        set { paused = value; }
    }

    //Property to set the correct timespan when loading the game.
    public TimeSpan TimePlaying
    {
        get { return timePlaying; }
        set { timePlaying = value; }
    }

    public TextTimer() : base("font")
    {
        timePlaying = new TimeSpan();
        text = "0:00";
    }
    //Add elapsed time and change the string if needed.
    public override void Update(GameTime gameTime)
    {
        if (paused)
            return;

        timePlaying = timePlaying.Add(gameTime.ElapsedGameTime);

        //Only change the string if the amount of seconds changed (Otherwise the string won't change anyway).
        if (timePlaying.Seconds != oldSec)
        {
            string secs;
            if (timePlaying.Seconds < 10)
                secs = "0" + timePlaying.Seconds.ToString();
            else
                secs = timePlaying.Seconds.ToString();
            string mins;
            if (timePlaying.Hours > 0)
                mins = (60 * timePlaying.Hours + timePlaying.Minutes).ToString();
            else
                mins = timePlaying.Minutes.ToString();
            text = mins + ":" + secs;

            oldSec = timePlaying.Seconds;
        }
    }

}

