﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

/// <summary>
/// This class draws a string on screen.
/// </summary>
public class TextGameObject : GameObject
{
    protected SpriteFont spriteFont;
    protected Color color;
    protected string text;

    //Read and write variables
    public Color Color
    {
        get { return color; }
        set { color = value; }
    }

    public string Text
    {
        get { return text; }
        set { text = value; }
    }

    //Readonly variables
    public Vector2 Size => spriteFont.MeasureString(text);

    public TextGameObject(string assetname, int layer = 0, string id = "")
        : base(id, layer)
    {
        //Starting values

        if (assetname != "")
            this.spriteFont = GameWorld.AssetLoader.GetFont(assetname);

        color = Color.Black;
    }

    //Draw string on screen
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (this.text == null)
            this.text = "null";

        if (visible)
            spriteBatch.DrawString(spriteFont, text, this.GlobalPosition, color);
    }
}

