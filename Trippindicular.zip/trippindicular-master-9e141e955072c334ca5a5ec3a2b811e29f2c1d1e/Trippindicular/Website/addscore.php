<?php
require_once ('db.connect.php');
$hstring = $_POST["PlayerName"].$_POST["TimeSeconds"].$_POST["EnemiesKilled"].$_POST["CoinsCollected"]."xsw21qaz";
if (md5($hstring) == $_POST["Hash"]){
	echo "Correct hash included.<br/>";
	$sql = "INSERT INTO `diegokd143_TRIPPINDICULAR`.`trippindicular_highscores` (`PlayerName`, `TimeSeconds`, `EnemiesKilled`, `CoinsCollected`) VALUES ('".$_POST["PlayerName"]."','".$_POST["TimeSeconds"]."','".$_POST["EnemiesKilled"]."',".$_POST["CoinsCollected"].")";
	if($connect->query($sql) === TRUE)
	{
		echo "Succes!";
	} else {
		echo "Error ".$sql."<br/>".$connect->error;
	}
} else {
	echo "Wrong hash, aborting.<br/>";
}
$connect->close;
?>