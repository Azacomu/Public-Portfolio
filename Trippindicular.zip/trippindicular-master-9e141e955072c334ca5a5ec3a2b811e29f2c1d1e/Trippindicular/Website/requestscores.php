<?php
require_once('db.connect.php');
if ($_POST["Format"] == "TOP10TIMES"){
	$sql = "SELECT * FROM trippindicular_highscores ORDER BY TimeSeconds ASC LIMIT 10";
} else if ($_POST["Format"] == "TOP10KILLED") {
	$sql = "SELECT * FROM trippindicular_highscores ORDER BY EnemiesKilled DESC LIMIT 10";
} else if ($_POST["Format"] == "TOP10COINS") {
	$sql = "SELECT * FROM trippindicular_highscores ORDER BY CoinsCollected DESC LIMIT 10";
} else {
	$sql = "SELECT * FROM trippindicular_highscores ORDER BY TimeSeconds ASC";
}
echo "START_";
$result = $connect->query($sql);
if ($result->num_rows > 0)
{
	$i = 0;
	while ($row = $result->fetch_assoc())
	{
		$i++;
		echo $row["PlayerName"]."_C_".$row["TimeSeconds"]."_C_".$row["EnemiesKilled"]."_C_".$row["CoinsCollected"]."_C_".$i;
		if($result->num_rows > $i) echo "_R_";
	}
} else {
	echo "No results!";
}
$connect->close;
?>