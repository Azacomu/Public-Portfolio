<?php
$hostname = '10.3.1.151';
$username = 'diegokd143_admin';
$password = 'xsw21qaz';
$database = 'diegokd143_TRIPPINDICULAR';
$connect = new mysqli($hostname,$username,$password,$database);
if ($connect->connect_error)
{ die('Could not connect: '.$connect->connect_error);}
?>