﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

static class DropTable
{
    public static Items DetermineWeakItem()
    {
        Items item;
        if (R.Dice(2) == 1)
        {
            int itemNr = R.Dice(1000);
            if (itemNr < 300)
                item = new Coin();
            else if (itemNr < 400)
                item = new Bomb();
            else if (itemNr < 500)
                item = new Key();
            else if (itemNr < 600)
                item = new HealthPotion();
            else if (itemNr < 800)
                item = new MysteryPotion();
            else if (itemNr < 850)
                item = new KnockBackScroll();
            else if (itemNr < 900)
                item = new CircleOfFire();
            else
                item = new SugarySubstance();
        }
        else
            item = null;
        return item;
    }

    public static Items DetermineStrongItem()
    {
        Items item;
        int itemNr = R.Dice(100);
        if (itemNr < 20)
            item = new Boomerang();
        else if (itemNr < 30)
            item = new TheDoubleTeam();
        else if (itemNr < 40)
            item = new StartingShield();
        else if (itemNr < 60)
            item = new SecondWand();
        else if (itemNr < 70)
            item = new NinjaHeadband();
        else if (itemNr < 80)
            item = new Laginator();
        else if (itemNr < 90)
            item = new CrystalArrow();
        else
            item = new PetSkunk();

        return item;
    }

    public static List<Items> MonsterDrop(int strength)
    {
        List<Items> itemList = new List<Items>();
        int floor = GameData.CurrentFloor;
        //Maximum 375, minimum 100
        int itemModifier = (1 + (strength / 50))/(1 - (floor / 10));
        int itemNr = 100 * itemModifier;
        itemList.Add(DetermineMonsterDrop(itemNr));
        if (itemNr > 200)
            itemList.Add(DetermineMonsterDrop(itemNr));
        return itemList;
    }

    public static Items DetermineMonsterDrop(int itemStrength)
    {
        Items item = new Coin();
        int itemNr = itemStrength * R.Dice(100) / 100 + itemStrength/10;
        if (itemNr < 90)
        {
            if (R.Dice(10) < 9)
                item = null;
            else
                item = new MysteryPotion();
        }
        else if (itemNr < 150)
        {
            if (itemNr < 170)
                item = new Coin();
            else if (itemNr < 200)
                item = new Bomb();
            else if (itemNr < 250)
                item = new HealthPotion();
        }
        else if (itemNr < 250)
            item = DetermineWeakItem();
        else
            item = DetermineStrongItem();

        return item;
    }

    public static List<Items> Treasure()
    {
        List<Items> item = new List<Items>();
        for (int counter = 0; counter < 3; counter++)
        {         
            int itemNr = R.Dice(125);
            if (itemNr < 10)
                item.Add(new HealthPotion());
            else if (itemNr < 20)
                item.Add(new MysteryPotion());
            else if (itemNr < 50)
                item.Add(new SugarySubstance());
            else if (itemNr < 75)
                item.Add(new Key());
            else if (itemNr < 100)
                item.Add(new Bomb());
        }
        if (item.Count == 0)
            item.Add(new Bomb());
        foreach (Items i in item)
            Log.Write(LogType.INFO, i.ID);
        return item;
    }
}
