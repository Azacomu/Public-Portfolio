﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class KeyDoor:Door
{
    public KeyDoor(string assetName, int sheetIndex, string id = "door", int layer = 0) : base("doorleft", 1, id, layer)
    {
        sprite = new SpriteSheet(assetName, sheetIndex);

    }
}
