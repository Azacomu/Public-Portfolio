﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class TrapDoor:Door
{
    public bool opened;

    public TrapDoor(string assetName, int sheetIndex, string id = "door", int layer = 0) : base("", 1, id, layer)
    {
        sprite = new SpriteSheet("trapdoor", 0);
    }

    public void Open()
    {
        opened = true;
        sprite = new SpriteSheet("trapdoor", 1);
    }

}
