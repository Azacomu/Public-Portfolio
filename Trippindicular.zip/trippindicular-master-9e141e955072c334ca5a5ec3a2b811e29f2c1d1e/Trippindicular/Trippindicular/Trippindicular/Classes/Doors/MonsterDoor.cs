﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class MonsterDoor : Door
{
    public MonsterDoor(string assetName, int sheetIndex, string id = "door", int layer = 0) : base("", 1, id, layer)
    {
        sprite = new SpriteSheet(assetName, sheetIndex);

    }
}
