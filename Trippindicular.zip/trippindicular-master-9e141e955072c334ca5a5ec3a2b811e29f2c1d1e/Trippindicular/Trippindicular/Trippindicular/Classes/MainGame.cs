using System;

//This is the main class, the game gets started from here.
class MainGame : GameWorld
{
    //Controller used to keep track of player achievements.
    public static Achievements AchievementController;


    static void Main()
    {
        MainGame game = new MainGame();
        
        game.Run();
    }

    //Initialize the game.
    public MainGame()
    {
        Log.Initialize();
        Content.RootDirectory = "Content";
        this.IsMouseVisible = true;

        Log.Write(LogType.INFO, "Build Directory: " + Testing.AssemblyDirectory);
        Console.WriteLine("Build Directory: " + Testing.AssemblyDirectory);
        AchievementController = new Achievements("Content/Settings/achievements.txt");
    }

    //Load all the game states.
    protected override void LoadContent()
    {
        base.LoadContent();

        gameStateManager.AddGameState("playing", new PlayingState());
        gameStateManager.AddGameState("hud", new HUD());
        gameStateManager.AddGameState("titleMenu", new TitleMenuState());
        gameStateManager.AddGameState("credits", new CreditsOverlay());
        gameStateManager.AddGameState("gameOver", new GameOverState());
        gameStateManager.AddGameState("pauseMenu", new PauseMenuOverlay());

        gameStateManager.AddGameState("achievementsTitle", new AchievementOverlay(gameStateManager.GetGameState("titleMenu")));
        gameStateManager.AddGameState("achievementsPause", new AchievementOverlay(gameStateManager.GetGameState("pauseMenu")));

        gameStateManager.AddGameState("settingsMenuTitle", new SettingsMenuOverlay(gameStateManager.GetGameState("titleMenu")));
        gameStateManager.AddGameState("settingsMenuPause", new SettingsMenuOverlay(gameStateManager.GetGameState("pauseMenu")));

        gameStateManager.AddGameState("highscoresTitle", new HighscoresOverlay(gameStateManager.GetGameState("titleMenu")));
        gameStateManager.AddGameState("highscoresPause", new HighscoresOverlay(gameStateManager.GetGameState("pauseMenu")));

        gameStateManager.AddGameState("gameOver", new GameOverState());
        gameStateManager.AddGameState("finish", new FinishState());

        gameStateManager.SwitchTo("titleMenu");
    }
}

