﻿using System;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework;
using System.IO;
using System.Xml.Serialization;

//Struct used for the data that we need to load the game again.
public struct SaveGameData
{
    public int EnemiesKilled;
    public int CoinsCollected;
    public int CurrentFloor;
    public TextTimer CurrTime;
    public int Seconds;
    public int Minutes;
    public int PlayerMaxHealth;
    public int PlayerCurrHealth;
    public float PlayerDamage;
    public float PlayerMovementSpeed;
    public float PlayerAttSpeed;
    public string[] Items;
    public int Coins;
    public int Keys;
    public int Bombs;
    public int HealthPots;
    public bool CrystalArrow;
    public bool ShieldUpgrade;
    public bool DoubleTeamer;
    public string[] Powerups;
    public bool Cheated;
}
//Class used to save games and to load them again.
class SaveGame
{
    protected StorageDevice device;
    protected const string containerName = "GameSaveStorage";
    protected const string fileName = "gamesave.trippindicular";
    protected bool exists;

    //Method to check if there is an existing savefile.
    public bool CheckSaveFile()
    {
        device = null;
        StorageDevice.BeginShowSelector(PlayerIndex.One, Check, null);
        bool temp = exists;
        exists = false;
        return temp;
    }
    protected void Check(IAsyncResult result)
    {
        device = StorageDevice.EndShowSelector(result);
        if (device != null && device.IsConnected)
        {
            IAsyncResult res = device.BeginOpenContainer(containerName, null, null);
            result.AsyncWaitHandle.WaitOne();
            StorageContainer con = device.EndOpenContainer(res);
            result.AsyncWaitHandle.Close();
            exists = con.FileExists(fileName);
            Log.Write(LogType.INFO, "File status: " + exists);
        }
        else
            Log.Write(LogType.ERROR, "Device null or not connected, failed to check savegame!");
    }
    //Method to delete the savefile.
    public void DeleteSave()
    {
        device = null;
        StorageDevice.BeginShowSelector(PlayerIndex.One, Delete, null);
    }
    protected void Delete(IAsyncResult result)
    {
        device = StorageDevice.EndShowSelector(result);
        if (device != null && device.IsConnected)
        {
            IAsyncResult res = device.BeginOpenContainer(containerName, null, null);
            result.AsyncWaitHandle.WaitOne();
            StorageContainer con = device.EndOpenContainer(res);
            result.AsyncWaitHandle.Close();
            if (con.FileExists(fileName))
                con.DeleteFile(fileName);
            Log.Write(LogType.INFO, "Save file deleted.");
        }
        else
            Log.Write(LogType.ERROR, "Device null or not connected, failed to delete savegame!");
    }

    //First initialize the async save, then use the SaveToDevice to actually save the file to the StorageDevice.
    public void InitializeSave()
    {
        device = null;
        StorageDevice.BeginShowSelector(PlayerIndex.One, SaveToDevice, null);
    }
    protected void SaveToDevice(IAsyncResult result)
    {
        device = StorageDevice.EndShowSelector(result);
        if (device != null && device.IsConnected)
        {
            Player p = GameData.GetPlayer;
            Inventory i = p.Inventory;
            string[] powerups = new string[i.PowerUps.Count];
            for (int c = 0; c < i.PowerUps.Count; c++)
            {
                powerups[c] = i.PowerUps[c].ID;
            }
            string[] items = new string[4];
            for (int c = 0; c < items.Length; c++)
            {
                items[c] = i.GetItem(c)?.ID;
            }
            //Saves all important data in a SaveGameData struct.
            SaveGameData data = new SaveGameData()
            {
                EnemiesKilled = GameData.EnemiesKilled,
                CoinsCollected = GameData.CoinsCollected,
                CurrentFloor = GameData.CurrentFloor,
                CurrTime = GameData.PlayingTime,
                PlayerMaxHealth = p.MaxHealth,
                PlayerCurrHealth = p.CurHealth,
                PlayerAttSpeed = p.AttackSpeed,
                PlayerDamage = p.Damage,
                PlayerMovementSpeed = p.MovementSpeed,
                Coins = i.GetCoins,
                Keys = i.GetKeys,
                Bombs = i.GetBombs,
                HealthPots = i.GetHealthPotions,
                Items = items,
                CrystalArrow = i.HasCrystalArrows,
                DoubleTeamer = i.HasDoubleTeamer,
                ShieldUpgrade = i.HasShieldUpgrade,
                Powerups = powerups,
                Seconds = GameData.PlayingTime.Seconds,
                Minutes = GameData.PlayingTime.Minutes,
                Cheated = GameData.Cheated,
            };
            IAsyncResult res = device.BeginOpenContainer(containerName, null, null);
            result.AsyncWaitHandle.WaitOne();
            StorageContainer con = device.EndOpenContainer(res);
            if (con.FileExists(fileName))
                con.DeleteFile(fileName);
            Stream stream = con.CreateFile(fileName);
            XmlSerializer serializer = new XmlSerializer(typeof(SaveGameData));
            serializer.Serialize(stream, data);
            stream.Close();
            con.Dispose();
            result.AsyncWaitHandle.Close();
            Log.Write(LogType.INFO, "Succesfully saved the game!");
        }
        else
            Log.Write(LogType.ERROR, "Failed to save game, device null or not connected!");
    }
    //First initialize the async load, then use the LoadFromDevice to actually save the file to the StorageDevice.
    public void InitializeLoad()
    {
        device = null;
        StorageDevice.BeginShowSelector(PlayerIndex.One, LoadFromDevice, null);
    }
    protected void LoadFromDevice(IAsyncResult result)
    {
        device = StorageDevice.EndShowSelector(result);
        IAsyncResult res = device.BeginOpenContainer(containerName, null, null);
        result.AsyncWaitHandle.WaitOne();
        StorageContainer con = device.EndOpenContainer(res);
        result.AsyncWaitHandle.Close();
        if (con.FileExists(fileName))
        {
            Stream stream = con.OpenFile(fileName, FileMode.Open);
            XmlSerializer serializer = new XmlSerializer(typeof(SaveGameData));
            SaveGameData data = (SaveGameData)serializer.Deserialize(stream);
            stream.Close();
            con.Dispose();

            //Load the data in the game and set the game to loaded.
            GameData.EnemiesKilled = data.EnemiesKilled;
            GameData.CoinsCollected = data.CoinsCollected;
            GameData.CurrentFloor = data.CurrentFloor;
            GameData.PlayingTime = data.CurrTime;
            GameData.PlayingTime.TimePlaying = new TimeSpan(data.Minutes / 60, data.Minutes % 60, data.Seconds);
            GameData.Cheated = data.Cheated;

            //Load player stats.
            Player p = GameData.GetPlayer;
            p.MaxHealth = data.PlayerMaxHealth;
            p.AttackSpeed = data.PlayerAttSpeed;
            p.Damage = data.PlayerDamage;
            p.CurHealth = data.PlayerCurrHealth;
            p.MovementSpeed = data.PlayerMovementSpeed;

            //Load inventory.
            Inventory inv = p.Inventory;
            LoadItems(data.Items);
            LoadItems(data.Powerups);
            inv.GetBombs = data.Bombs;
            inv.GetCoins = data.Coins;
            inv.GetHealthPotions = data.HealthPots;
            inv.GetKeys = data.Keys;
            inv.HasCrystalArrows = data.CrystalArrow;
            inv.HasDoubleTeamer = data.DoubleTeamer;
            inv.HasShieldUpgrade = data.ShieldUpgrade;

            Log.Write(LogType.INFO, "Succesfully loaded the game!");
       }
        else
            Log.Write(LogType.WARNING, " No savegame found!"); 
    }
    protected void LoadItems(string[] items)
    {
        //Add the items to the inventory of the player again.
        Inventory inv = GameData.GetPlayer.Inventory;

        for (int i = 0; i < items.Length; i++)
        {
            string s = items[i];
            switch (s)
            {
                case "woodenbow": inv.AddItem(new WoodenBow());
                    break;
                case "woodarrow": inv.AddItem(new WoodArrow());
                    break;
                case "thedoubleteam": inv.AddItem(new TheDoubleTeam());
                    break;
                case "laginator": inv.AddItem(new Laginator());
                    break;
                case "legendarysword": inv.AddItem(new LegendarySword());
                    break;
                case "startingsword": inv.AddItem(new StartingSword());
                    break;
                case "startingwand": inv.AddItem(new StartingWand());
                    break;
                case "secondwand": inv.AddItem(new SecondWand());
                    break;
                case "ninjaheadband": inv.AddItem(new NinjaHeadband());
                    break;
                case "azalea": inv.AddItem(new PetSkunk());
                    break;
                case "crystalarrow": inv.AddItem(new CrystalArrow());
                    break;
                case "boomerang": inv.AddItem(new Boomerang());
                    break;
                case "startingshield": inv.AddItem(new StartingShield());
                    break;
                case "mysteryPotion": inv.AddItem(new MysteryPotion());
                    break;
                case "sugarysubstance": inv.AddItem(new SugarySubstance());
                    break;
                case "circleoffire": inv.AddItem(new CircleOfFire());
                    break;
                case "knockbackscroll": inv.AddItem(new KnockBackScroll());
                    break;
                default:
                    Log.Write(LogType.WARNING, "Item not recognised when loading! " + s);
                    break;
            }
        }
        
    }
}

