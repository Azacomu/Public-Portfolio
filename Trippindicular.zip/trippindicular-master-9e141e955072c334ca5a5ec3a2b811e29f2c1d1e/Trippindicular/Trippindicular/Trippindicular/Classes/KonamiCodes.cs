﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;


//Class to keep track of keypresses in a certain order, if a special order is applied, cheats are activated.
public class KonamiCodes : Controller
{
    protected const float maxTimer = 2.0f;
    protected const int maxListSize = 8;
    protected float keyTimer;
    protected UserInput input;
    protected bool locked;
    protected List<string> lockedStrings;

    public KonamiCodes()
    {
        input = new UserInput();
        input.Visible = false;
        input.Position = new Vector2(300, 300);
        input.AutoReset = true;
        lockedStrings = new List<string>();
    }

    //Add the pressed keys to the pressedKeys List, check for maxSize and compare pressed keys with the dictionary.
    public override void HandleInput(InputHelper ih)
    {
        input.HandleInput(ih);
        
    }
    //Update the timer and reset list if needed.
    public override void Update(GameTime gameTime)
    {
        keyTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
        if (keyTimer >= maxTimer)
        {
            keyTimer = 0;
        }
        CheckCheats(input.Text);
        if (locked)
        {
            foreach (string s in lockedStrings)
            {
                CheckCheats(s);
            }
        }
    }
    //Method that picks the right cheat according to the string given.
    private void CheckCheats(string s)
    {
        if (s.Contains("LOCK"))
        {
            locked = true;
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("UNLOCK"))
        {
            locked = false;
            input.Reset();
            Console.WriteLine("UNLOCK");
            GameData.Cheated = true;
        }
        if (s.Contains("KILL"))
        {
            KillEnemies();
            GameData.Cheated = true;
        }
        if (s.Contains("SPEEDUP"))
        {
            GameData.GetPlayer.MovementSpeed += 200;
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("SPEEDDOWN"))
        {
            GameData.GetPlayer.MovementSpeed -= 200;
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("CONFUSE"))
        {
            GameData.GetPlayer.MovementSpeed *= -1;
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("SOLIDMOVE"))
        {
            GameData.GetPlayer.MoveSolid = true;
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("GODLIKE"))
        {
            CheckCheats("LOCKKILLSPEEDUPSOLIDMOVEMOTHERLODE");
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("MOTHERLODE"))
        {
            Inventory i = GameData.GetPlayer.Inventory;
            i.GetBombs = 99;
            i.GetKeys = 99;
            i.GetCoins = 99;
            i.GetHealthPotions = 99;
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("INSTAWIN") || s.Contains("OPAF"))
        {
            input.Reset();
            GameData.Cheated = true;
            GameWorld.GameStateManager.SwitchTo("gameOver");
        }
        if (s.Contains("STRENGTH"))
        {
            GameData.GetPlayer.Damage = 100;
            input.Reset();
            GameData.Cheated = true;
        }
        if (s.Contains("FINISH"))
        {
            GameData.Cheated = true;
            GameWorld.GameStateManager.SwitchTo("finish");
            input.Reset();
        }
        if (s.Contains("HEAL"))
        {
            GameData.Cheated = true;
            GameData.GetPlayer.CurHealth += 2;
            input.Reset();
        }
    }
    //Method that kills all enemies in the current level.
    private void KillEnemies()
    {
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
                GameData.LevelObjects.Objects.RemoveAt(i);
        }
        if (locked && !lockedStrings.Contains("KILL"))
        {
            lockedStrings.Add("KILL");
            input.Reset();
        }
        if (!locked)
            input.Reset();
    }
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        input.Draw(gameTime, spriteBatch);
    }
}

