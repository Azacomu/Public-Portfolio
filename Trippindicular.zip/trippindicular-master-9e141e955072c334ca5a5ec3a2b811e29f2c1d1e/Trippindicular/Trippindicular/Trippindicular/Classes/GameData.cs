﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

//Class used for static data used in the game.
static class GameData
{
    static int currentFloor;
    static Point currentRoom;
    static int enemiesKilled;
    static int coinsCollected;
    static Point resolution;
    static Player player;
    static List<GameObject> solidObjects;
    static List<GeneralEnemy> enemies;
    static TextTimer playingTime;

    //This is the list with all the objects of the current level in it.
    static public GameObjectList LevelObjects;
    static public bool Cheated;

    //Controller for controlling the weather.
    static public WeatherController WeatherController;

    //Static items needed for saving and loading exact floors (Obsolete, still here for improving later on).
    static public List<string> RoomPaths;
    static public List<Point> AllRoomPoints;
    static public List<Point> CompletedRooms;
    static public List<bool> RoomsMirroredX;
    static public List<bool> RoomsMirroredY;
    static public bool PuzzleSolved;

    //Readonly properties.    
    static public Player GetPlayer => player;
    static public List<GeneralEnemy> Enemies => enemies;

    //Other properties.
    static public int EnemiesKilled
    {
        get { return enemiesKilled; }
        set { enemiesKilled = value; }
    }
    static public int CoinsCollected
    {
        get { return coinsCollected; }
        set { coinsCollected = value; }
    }
    static public TextTimer PlayingTime
    {
        get {return playingTime; }
        set { playingTime = value; }
    }
    static public int CurrentFloor
    {
        get { return currentFloor; }
        set { currentFloor = value; }
    }
    static public Point CurrentRoom
    {
        get { return currentRoom; }
        set { currentRoom = value; }
    } 
    static public Point Resolution
    {
        get { return resolution; }
        set { if (resolution == null) resolution = value; }
    }

    //Stat functions (used for highscores).
    static public void AddCoin() { coinsCollected++; }
    static public void EnemyKill() { enemiesKilled++; }

    //Updates the levelobjects and gives achievements for stats.
    static public void Update(GameTime gameTime)
    {
        LevelObjects.Update(gameTime);
        UpdateSolidList();
        playingTime.Update(gameTime);
        WeatherController.Update(gameTime);
        if (coinsCollected >= 25)
            MainGame.AchievementController.FinishAchievement("Collector");
        if (enemiesKilled >= 80)
            MainGame.AchievementController.FinishAchievement("Massacre");
    }

    //This is where the objects in the game (LevelObjects) are drawn.
    static public void DrawGame(GameTime gameTime, SpriteBatch spriteBatch)
    {
        LevelObjects.Draw(gameTime, spriteBatch);
        playingTime.Draw(gameTime, spriteBatch);
        WeatherController.Draw(gameTime,spriteBatch);
    }

    //Method that initializes the settings and data used in GameData.
    static public void Initialize()
    {
        LevelObjects = new GameObjectList();
        WeatherController = new WeatherController();
        solidObjects = new List<GameObject>();
        enemies = new List<GeneralEnemy>();
        RoomPaths = new List<string>();
        AllRoomPoints = new List<Point>();
        CompletedRooms = new List<Point>();
        RoomsMirroredX = new List<bool>();
        RoomsMirroredY = new List<bool>();
        playingTime = new TextTimer();
        GameWorld.SolidObjects = solidObjects;
        currentFloor = 0;
        enemiesKilled = 0;
        coinsCollected = 0;
    }
    static public void AfterInitialize()
    {
        player = LevelObjects.Find("Soren") as Player;
    }
    //Method that returns a list with all objects that are nearby the given object (Used for collision detection).
    static public List<SpriteGameObject> FindNearbyTiles(SpriteGameObject testObj)
    {
        Point tileIndex = testObj.TileIndex;
        List<SpriteGameObject> sprList = new List<SpriteGameObject>();
        for (int x = tileIndex.X - 1; x <= tileIndex.X + 1; x++)
        {
            for (int y = tileIndex.Y - 1; y <= tileIndex.Y + 1; y++)
            {
                List<SpriteGameObject> tempList = LevelObjects.FindTiles(new Point(x, y));
                foreach (SpriteGameObject sprObj in tempList)
                    sprList.Add(sprObj);
            }
        }
        sprList.Remove(testObj); //Make sure the object itself is not in the list.
        return sprList;
    }
    //Updates the list with solid objects, used when entering a new room with other objects.
    static public void UpdateSolidList()
    {
        solidObjects = new List<GameObject>();
        enemies = new List<GeneralEnemy>();
        foreach(GameObject obj in LevelObjects.Objects)
        {
            if (obj is GameObjectList)
            {
                GameObjectList objList = obj as GameObjectList;
                foreach (GameObject obj2 in objList.Objects)
                {
                    if (obj2.Solid && !(obj2 is GeneralEnemy))
                        solidObjects.Add(obj2);
                    else if (obj2 is GeneralEnemy)
                        enemies.Add(obj2 as GeneralEnemy);
                }
            }
            if (obj.Solid && !(obj is GeneralEnemy))
                solidObjects.Add(obj);
            else if (obj is GeneralEnemy)
                enemies.Add(obj as GeneralEnemy);
        }
        GameWorld.SolidObjects = solidObjects;
    }
}

