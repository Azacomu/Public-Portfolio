﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Class for the raindrops created by rain, created in the top left outside of the screen
//and when they move outside of the right side of the screen or the bottom side they reset to the top or left side of the screen
//raindrops a semi-random X and Y location and a semi-random X Velocity based on the sprite scale which is random between 0 and 1
class RainDrop : SpriteGameObject
{
    protected float rainVelocityY = 800f;
    protected float rainVelocityX;

    public RainDrop() : base("raindrop", 0)
    {
    }
    //Resets the raindrops to top or left side of the screen after they move outside of it, has a higher X velocity the smaller the sprite scale is
    //Adjusts the rotation based on velocity
    public override void Update(GameTime gameTime)
    {
        rainVelocityX = 400 / Sprite.Scale;
        if (this.PositionY > 1080)
        {
            PositionY = -200+R.NextFloat()*200;
            PositionX = R.NextFloat() * 1900f;
            Sprite.Scale = R.NextFloat();
        }
        if (this.PositionX > 1900)
        {
            PositionX = 0;
        }
        float t = (float)gameTime.ElapsedGameTime.TotalSeconds;
        this.Velocity = new Vector2(rainVelocityX, rainVelocityY);
        Position += Velocity * t;
        AdjustRotation();
    }
   
    //Adjusts the rotation based on the Velocity by calculating the angle
    protected void AdjustRotation()
    {
        float differenceXPos = Math.Abs(this.Velocity.X);
        float differenceYPos = Math.Abs(this.Velocity.Y);
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        if (this.Velocity.X > 0)
        {
             if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)((Math.PI * 1.7) + angle);
            }
        }
        else if (this.Velocity.X < 0)
        {
            if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)(angle);
            }
        }
    }
}

