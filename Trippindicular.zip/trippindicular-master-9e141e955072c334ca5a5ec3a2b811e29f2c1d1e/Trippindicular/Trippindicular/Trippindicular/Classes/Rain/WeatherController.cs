﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Class for controlling the rain, since that is currently the only weather in the game
class WeatherController : GameObject
{
    protected bool isRaining;
    protected bool removeRain;
    protected int rainSplatChance = 4;
    protected int rainInCounter = 0;
    protected int rainCounter = 0;
    protected int rainOutCounter = 0;
    protected bool createdRain;
    protected List<SpriteGameObject> raindrops;
    protected SpriteGameObject filter;
    protected SpriteGameObject filter2;
    protected bool decreasedFilter = false;
    protected float rainDuration;
    Timer removeRainTimer;
    Timer startRemovingRain;
    Timer startRaining;
    Timer addSplatTimer;
    Timer newRainTimer;
    //float for how long it will rain
    public float RainDuration
    {
        get { return rainDuration; }
        set { rainDuration = value; }
    }
    //bool to make it start raining
    public bool IsRaining
    {
        get { return isRaining; }
        set { isRaining = value; }
    }
    //property to remove rain
    public bool RemoveRain
    {
        get { return removeRain; }
        set { removeRain = value; }
    }

    public WeatherController() : base("weathercontroller", 0)
    {
        isRaining = false;
        createdRain = false;
        rainDuration = 50f;
        filter = new SpriteGameObject("filter20", 0, "filter", 0);
        filter2 = new SpriteGameObject("filter10", 0, "filter2", 0);
        raindrops = new List<SpriteGameObject>();
        removeRainTimer = new Timer(rainDuration);
        startRemovingRain = new Timer(4f);
        startRaining = new Timer(4f);
        addSplatTimer = new Timer(0.1f);
        newRainTimer = new Timer(60f);
    }
    //Updates the timers for different rain states,  updates the raindrops and adds them when it just started raining, adds splats
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        removeRainTimer.Update(gameTime);
        addSplatTimer.Update(gameTime);
        if (IsRaining)
            StartRaining(gameTime);
        CheckForRain(gameTime);
        if (GameData.CurrentFloor > 0)
            Reset();
        if (isRaining)
        {
            AddSplats();

            if (!createdRain)
            {
                removeRainTimer = new Timer(RainDuration - 4.1f);
                CreateRain();
            }
            if (removeRainTimer.Ended || RemoveRain)
            {
                StartRemovingRain(gameTime);
            }
        }
        for (int i = 0; i < raindrops.Count; i++)
        {
            if (raindrops[i] != null)
            {
                SpriteGameObject p = raindrops[i];
                p.Update(gameTime);
            }
        }
    }
    //Draws the raindrops
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        for (int i = 0; i < raindrops.Count; i++)
        {
            if (raindrops[i] != null)
            {
                SpriteGameObject p = raindrops[i];
                p.Draw(gameTime, spriteBatch);
            }
        }
    }
    //Creates raindrops and adds a filter to make the game darker
    protected void CreateRain()
    {
        for (int i = 0; i < 700; i++)
        {
            RainDrop b = new RainDrop();
            if (i < 100)
                b.Position = new Vector2(-500 + R.NextFloat() * 1900f, -300 + R.NextFloat() * 200);
            else if (i < 200)
                b.Position = new Vector2(-550 + R.NextFloat() * 1900f, -500 + R.NextFloat() * 200);
            else if (i < 300)
                b.Position = new Vector2(-600 + R.NextFloat() * 1900f, -700 + R.NextFloat() * 200);
            else if (i < 400)
                b.Position = new Vector2(-650 + R.NextFloat() * 1900f, -900 + R.NextFloat() * 200);
            else if (i < 500)
                b.Position = new Vector2(-700 + R.NextFloat() * 1900f, -1100 + R.NextFloat() * 200);
            else if (i < 600)
                b.Position = new Vector2(-750 + R.NextFloat() * 1900f, -1300 + R.NextFloat() * 200);
            else if (i < 700)
                b.Position = new Vector2(-780 + R.NextFloat() * 1900f, -1500 + R.NextFloat() * 200);
            b.Sprite.Scale = R.NextFloat();
            AddToList(b);
        }
        AddToList(filter);
        createdRain = true;
    }
    //Method for adding raindrops to the list, because it for some reason worked better
    protected void AddToList(SpriteGameObject raindrop)
    {
        raindrops.Add(raindrop);
    }
    //Method to slowly start removing raindrops and making the filther less dark
    protected void StartRemovingRain(GameTime gameTime)
    {
        startRemovingRain.Update(gameTime);
        for (int i = 0; i < raindrops.Count; i++)
        {
            if (raindrops[i] != null)
            {
                switch (R.Dice(45))
                {
                    case 1:
                        raindrops.Remove(raindrops[i]);
                        break;
                    default:
                        break;
                }
            }
        }
        rainSplatChance = 8;
        if (!decreasedFilter)
        {
            raindrops.Remove(filter);
            AddToList(filter2);
            decreasedFilter = true;
        }
        if (startRemovingRain.Ended)
        {
            Reset();
        }
    }
    //Method that plays different sounds based on the current rain state, start raining, israining and start removing rain.
    protected void StartRaining(GameTime gameTime)
    {
        startRaining.Update(gameTime);
        if (!startRaining.Ended && rainInCounter < 1)
        {
            rainInCounter += 1;
            GameWorld.AssetLoader.PlaySound("rainIn");
        }
        else if (!removeRainTimer.Ended && rainCounter < 1)
        {
            rainCounter += 1;
            GameWorld.AssetLoader.PlaySound("rain");
        }
        else if (isRaining && rainOutCounter < 1)
        {
            rainOutCounter += 1;
            GameWorld.AssetLoader.PlaySound("rainOut");
        }
    }
    //Resets all the properties and timers and removes the raindrops and splats
    public override void Reset()
    {
        isRaining = false;
        createdRain = false;
        decreasedFilter = false;
        removeRainTimer.Reset();
        startRemovingRain.Reset();
        newRainTimer.Reset();
        addSplatTimer.Reset();
        startRaining.Reset();
        rainSplatChance = 4;
        rainInCounter = 0;
        rainCounter = 0;
        rainOutCounter = 0;
        for (int i = 0; i < raindrops.Count; i++)
        {
            if (raindrops[i] != null)
            {
                raindrops[i] = null;
            }
        }
        raindrops.Remove(filter2);
    }
    //Adds rainsplats on random positions on the screen
    protected void AddSplats()
    {
        if (addSplatTimer.Ended)
        {
            switch (R.Dice(rainSplatChance))
            {
                case 1:
                    RainSplat splat = new RainSplat();
                    splat.Position = new Vector2(R.NextFloat() * 1900, R.NextFloat() * 1000);
                    GameData.LevelObjects.Add(splat);
                    break;
                default:
                    break;
            }
        }
    }
    //Has a 50% of making it rain after every 60 seconds
    protected void CheckForRain(GameTime gameTime)
    {
        if (!IsRaining && GameData.CurrentFloor == 0)
        {
            newRainTimer.Update(gameTime);
            if (newRainTimer.Ended)
            {
                switch (R.Dice(2))
                {
                    case 1:
                        {
                            RainDuration = 64f;
                            IsRaining = true;
                        }
                        break;
                    default:
                        break;
                }
                newRainTimer.Reset();
            }
        }
    }
}

