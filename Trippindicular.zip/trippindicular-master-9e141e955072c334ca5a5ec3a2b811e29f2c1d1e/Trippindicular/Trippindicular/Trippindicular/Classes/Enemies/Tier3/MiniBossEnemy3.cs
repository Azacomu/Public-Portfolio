﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class is for the enemy at the end of the last floor for the player to defeat to get to the final boss.
/// His special attack is flying in the air and when he lands back down, he freezes the player if he is in the area.
/// </summary>

class MiniBossEnemy3 : GeneralEnemy
{
    Stopwatch swTimer;
    Stopwatch swTimerAnimation1, swTimerAnimation2, swTimerInAir;
    Stopwatch swTimerFrozen;
    SpriteGameObject attackCircle, shadowCircle, fallRange;
    Vector2 velocityTemp;
    int specialTimer;
    int specialAnimationTime, specialTimerInAir;
    int timeFrozen;
    int posXLeft, posXRight, posYTop, posYBottom;
    int specialDamage;
    bool specialActive;
    bool specialBeginDone, specialEndDone;

    public MiniBossEnemy3(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("MiniBoss3", 1)
    {
        LoadAnimation("miniBoss3Enemy", "MovingUp", false, 0.1f);
        PlayAnimation("MovingUp");

        hitboxSprite = new SpriteSheet("miniBoss3Enemy", 0);

        this.position = startPosition;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;


        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        //Timers for basic attack
        attackTimer = 0.0f;
        waitTime = 0.5f;

        //Timers for special attack
        swTimer = new Stopwatch();
        swTimer.Start();
        specialTimer = 10;
        swTimerAnimation1 = new Stopwatch();
        swTimerAnimation2 = new Stopwatch();
        specialAnimationTime = 1500;
        swTimerInAir = new Stopwatch();
        specialTimerInAir = 2;
        swTimerFrozen = new Stopwatch();
        timeFrozen = 1000;
        velocityTemp = Vector2.Zero;

        //booleans for special attack
        specialActive = false;
        specialBeginDone = false;
        specialEndDone = false;

        //Basic attack and special attack damage stats
        damage = 4;
        specialDamage = 1;
        health = 40;
        this.MaxHealth = this.EnemyHealth;
        DropStrength = 100;

        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;

        //The range of impact when the boss lands
        fallRange = new SpriteGameObject("fallRange", 0, "fallRange", 0);
        fallRange.Origin = new Vector2(fallRange.Width / 2, fallRange.Height / 2);
        fallRange.Position = this.GlobalPosition;
        fallRange.Visible = false;

        //The shadow of where the boss flies/will land
        shadowCircle = new SpriteGameObject("shadow", 0, "shadowDrop", 0);
        shadowCircle.Origin = new Vector2(shadowCircle.Width / 2, shadowCircle.Height / 2);
        shadowCircle.Position = this.GlobalPosition;
        shadowCircle.Visible = false;

        //Positions of the game window
        posXLeft = GameSettings.GameFieldOffset + GameSettings.TileHeight + Width / 2;
        posYTop = GameSettings.GameFieldOffset + GameSettings.TileHeight + Height / 2;
        posXRight = GameSettings.GameFieldOffset + GameSettings.TileHeight - Width / 2 + ((LevelLoader.horTiles - 2) * GameSettings.TileWidth);
        posYBottom = GameSettings.GameFieldOffset + GameSettings.TileHeight - Height / 2 + ((LevelLoader.verTiles - 2) * GameSettings.TileHeight);
    }
    
    public override void Update(GameTime gameTime)
    {
        //If his health is below 0, give the player specific achievements, play the correct music
        if (this.health <= 0)
        {
            GameWorld.AssetLoader.PlayMusic("floor2music");
            CheckAchievements();
            GameData.GetPlayer.Frozen = false;
        }

        base.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;
        fallRange.Update(gameTime);
        fallRange.Position = this.GlobalPosition;
        shadowCircle.Update(gameTime);
        shadowCircle.PositionX = this.GlobalPosition.X;
        shadowCircle.PositionY = this.GlobalPosition.Y + this.Height/2 - shadowCircle.Height/2;

        //Freeze the player if he is frozen(when the timer starts)
        if (swTimerFrozen.ElapsedMilliseconds > timeFrozen)
        {
            GameData.GetPlayer.Frozen = false;
            swTimerFrozen.Reset();
        }

        //Starts the special attack after a certain amount of seconds
        if (swTimer.Elapsed.Seconds > specialTimer)
        {
            specialActive = true;
            velocityTemp = Velocity;
            Velocity = Vector2.Zero;
            swTimer.Reset();
        }

        if (specialActive)
        {
            //always put his velocity on zero
            Velocity = Vector2.Zero;
            if (!specialBeginDone)
            {
                SpecialAttackBegin();
            }
            //if the 'fly-animation is done' start the time in air (flying)
            else if(swTimerAnimation1.ElapsedMilliseconds > specialAnimationTime)
            {
                shadowCircle.Visible = false;
                swTimerAnimation1.Reset();
                swTimerInAir.Start();
            }
            //when the 'flying' is done, let the 'fall animation' begin
            else if(swTimerInAir.Elapsed.Seconds > specialTimerInAir)
            {
                Position = GameData.GetPlayer.Position;
                CheckCollision();
                shadowCircle.Visible = true;
                GameWorld.AssetLoader.PlaySound("specFall");
                swTimerAnimation2.Start();
                swTimerInAir.Reset();
            }
            //If the 'fall animation' is done land the boss
            else if (swTimerAnimation2.ElapsedMilliseconds > specialAnimationTime && !specialEndDone)
            {
                SpecialAttackEnd();
            }
        }
        else
        {
            //Always move to player and attack the player
            isMovingToPlayer = true;
            if (SolidColission)
            {
                MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
            }
            else MoveToPlayer(startingVelocityX, startingVelocityY);
            waitTime = 0.0f;
        }
    }


    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        attackCircle.Draw(gameTime, spriteBatch);
        shadowCircle.Draw(gameTime, spriteBatch);
        fallRange.Draw(gameTime, spriteBatch);
        DrawTesting.DrawHitbox(spriteBatch, BoundingBox, Color.Blue);
        DrawTesting.DrawHitbox(spriteBatch, attackCircle.BoundingBox, Color.Blue);
        DrawTesting.DrawHitbox(spriteBatch, fallRange.BoundingBox, Color.Blue);
    }

    //Begin the special attack with the 'fly animation': make boss invisible and show his shadow
    protected void SpecialAttackBegin()
    {
        specialBeginDone = true;
        isMovingToPlayer = false;
        Visible = false;
        healthBar.Visible = false;
        shadowCircle.Visible = true;
        Velocity = Vector2.Zero;
        GameWorld.AssetLoader.PlaySound("specJump");
        swTimerAnimation1.Start();
    }

    //End the special attack with the 'land animation': make boss visible and check if the player collides with the fall range.
    //if so freeze him and do damage
    protected void SpecialAttackEnd()
    {
        specialEndDone = true;
        shadowCircle.Visible = false;
        Visible = true;
        healthBar.Visible = true;
        if (fallRange.CollidesWith(GameData.GetPlayer))
        {
            GameData.GetPlayer.Frozen =  true;
            GameData.GetPlayer.DealDamage(specialDamage);
            swTimerFrozen.Start();
        }
        specialActive = false;
        specialBeginDone = false;
        specialEndDone = false;
        GameWorld.AssetLoader.PlaySound("specLand");
        swTimerAnimation2.Reset();
        swTimer.Start();
    }
    
    protected void CheckAchievements()
    {
        //Kill Rmakus.
        if (!(MainGame.AchievementController.GetFinished("Rmakus")))
        {
            MainGame.AchievementController.FinishAchievement("Rmakus");
        }
    }

    //Check if the boss collides with the wall or is outside the screen. If so, change his position
    protected void CheckCollision()
    {
        if(PositionX < posXLeft)
        {
            PositionX = posXLeft;
        }
        if(PositionX > posXRight)
        {
            PositionX = posXRight;
        }
        if(PositionY < posYTop)
        {
            PositionY = posYTop;
        }
        if(PositionY > posYBottom)
        {
            PositionY = posYBottom;
        }
    }
}

