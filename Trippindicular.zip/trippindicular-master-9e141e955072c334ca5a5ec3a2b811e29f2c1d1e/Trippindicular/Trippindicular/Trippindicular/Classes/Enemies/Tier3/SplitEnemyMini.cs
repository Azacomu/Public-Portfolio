﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class is for the mini splitenemy on the third floor, he spawns when SplitEnemy dies or FinalBoss spawns this enemy.
/// </summary>

class SplitEnemyMini : GeneralEnemy
{
    Stopwatch spawnTimer;
    SpriteGameObject attackCircle;
    Vector2 tempPos;
    bool notSpawned;
    int mSecDelay;
    
    public SplitEnemyMini(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed, int milliSecondsDelay) : base("SplitEnemyMini", 1)
    {
        this.LoadAnimation("splitEnemyMini", "MovingUp", true, 0.1f);
        this.PlayAnimation("MovingUp");

        tempPos = startPosition;
        this.position = Vector2.Zero;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;


        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        //Timers for spawning the enemy
        spawnTimer = new Stopwatch();
        spawnTimer.Start();
        mSecDelay = milliSecondsDelay;
        Visible = false;
        notSpawned = true;

        //Timers for basic attack
        attackTimer = 0.0f;
        waitTime = 0.5f;

        //Basic stats of the enemy
        damage = 2;
        health = 6;
        this.MaxHealth = this.EnemyHealth;
        DropStrength = 30;

        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;
    }

    // updates the timers,attackcircle and swordposition
    public override void Update(GameTime gameTime)
    {
        //if he is not spawned yet(inVisible), put velocity on 0
        if(spawnTimer.ElapsedMilliseconds <= mSecDelay)
        {
            Velocity = Vector2.Zero;
        }
        //if it is the enemy's time to spawn, make him visible
        if(spawnTimer.ElapsedMilliseconds > mSecDelay && notSpawned)
        {
            if (!Visible)
            {
                Visible = true;
                this.position = tempPos;
                GameWorld.AssetLoader.PlaySound("enemySpawn");
            }
            spawnTimer.Stop();
            notSpawned = false;
        }

        base.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;

        //Always move to player and attack the player
        isMovingToPlayer = true;
        if (SolidColission)
        {
            MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
        }
        else MoveToPlayer(startingVelocityX, startingVelocityY);
        waitTime = 0.0f;
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        attackCircle.Draw(gameTime, spriteBatch);
        DrawTesting.DrawHitbox(spriteBatch, attackCircle.BoundingBox, Color.Blue);
    }
}

