﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class Crippler : GeneralEnemy
{
    Stopwatch stopWatch;
    GameObjectList projectiles;
    SpriteGameObject attackCircle;

    //obsolet, still here for later purposes
    public Crippler(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("FERanged",1) 
    {
        this.LoadAnimation("ghost", "Idle", true, 0.1f);
        this.PlayAnimation("Idle");

        this.position = startPosition;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;

        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        projectiles = new GameObjectList(0, "attackList");
        // initializes the attackrange with a circle sprite
        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;


        waitTime = 0.0f;
        attackTimer = 0.0f;
        stopWatch = new Stopwatch();
        stopWatch.Start();
        damage = 3;
        health = 8;

    }

    public override void Reset()
    {
        base.Reset();

    }

    public override void Update(GameTime gameTime)
    {
        if(this.health <=0)
        {
            invulnerable = true;
        }

        if(invulnerable)
        {
            this.VelocityX = this.startingVelocityX / 2;
            this.VelocityY = this.startingVelocityY / 2;
        }

        base.Update(gameTime);
        projectiles.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;

        waitTime -= (float)stopWatch.Elapsed.TotalSeconds;
        attackTimer -= stopWatch.Elapsed.Seconds;

        // if the player is contained in the range(attackCircle) it moves to the player
        if (attackCircle.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox))
        {
            isMovingToPlayer = true;
            if (moveSpecialTimer > 4f)
            {
                MoveRandom();
                Console.WriteLine("moving random");
            }
            else if (SolidColission)
            {
                MoveToPlayerSpecial(startingVelocityX, startingVelocityY);

            }
            else MoveToPlayer(startingVelocityX, startingVelocityY);
            waitTime = 0.0f;
        }
        else isMovingToPlayer = false;

        // if the player is contained in the range(attackCircle) it attacks the player based on the attacktimer and lineofsight
        if (attackCircle.CollidesWith(GameData.GetPlayer) && (attackTimer < 0.0f) && InLineOfSight)// && attackRange.Contains((int)GameData.GetPlayer.GlobalPosition.X, (int)GameData.GetPlayer.GlobalPosition.Y))  
        {
            Attack();
            attackTimer = 50.0f;
            stopWatch.Restart();
        }

        // checks if the attack collides with the player and removes it out of the list afterwards
        for (int i = projectiles.Objects.Count - 1; i > 0; i--)
        {
            SpriteGameObject attack = projectiles.Objects[i] as SpriteGameObject;
            if (GameData.GetPlayer.Inventory.GetItem(1) is StartingShield)
            {
                StartingShield sshield = GameData.GetPlayer.Inventory.GetItem(1) as StartingShield;
                if (sshield.HitBox.Contains(attack.BoundingBox))
                {
                    projectiles.Remove(attack);
                    Console.WriteLine("shieldhit");
                    GameWorld.AssetLoader.PlaySound("arrowHitShield");
                }
            }
            if (attack.CollidesWith(GameData.GetPlayer))
            {
                //GameWorld.AssetLoader.PlaySound("startingSwordhit");
                GameData.GetPlayer.CurHealth -= Damage;
                projectiles.Remove(attack);
            }
            foreach (GameObject obj in GameWorld.SolidObjects)
            {
                if (attack.CollidesWith(obj) && obj.ID != "water")
                {
                    projectiles.Remove(attack);
                }
            }
        }



    }

    // creates a new projectile attack with the velocity set to the current direction
    protected override void Attack()
    {
        SpriteGameObject simpleAttack = new SpriteGameObject("redFlame", 0, "simpleAttack", 0);
        simpleAttack.Position = new Vector2(this.GlobalPosition.X, this.GlobalPosition.Y);
        simpleAttack.Origin = new Vector2(simpleAttack.Width / 2, simpleAttack.Height / 2);
        Vector2 difference = GameData.GetPlayer.Position - this.Position;
        difference.Normalize();
        difference *= 600;
        simpleAttack.Velocity = difference;
        projectiles.Add(simpleAttack);
        GameWorld.AssetLoader.PlaySound("arrowFire");
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        projectiles.Draw(gameTime, spriteBatch);
        attackCircle.Draw(gameTime, spriteBatch);
    }





}
