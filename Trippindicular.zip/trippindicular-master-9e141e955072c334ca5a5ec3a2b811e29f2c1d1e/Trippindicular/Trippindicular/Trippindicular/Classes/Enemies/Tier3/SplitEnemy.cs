﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class is for the splitenemy on the third floor, his special ability is: if he dies, he split into two mini SplitEnemies.
/// </summary>

class SplitEnemy : GeneralEnemy
{
    SpriteGameObject attackCircle;

    public SplitEnemy(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("SplitEnemy", 1)
    { 
        this.LoadAnimation("splitEnemy", "MovingUp", true, 0.1f);
        this.PlayAnimation("MovingUp");
        this.position = startPosition;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;


        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        //Timers for basic attack
        attackTimer = 0.0f;
        waitTime = 0.5f;

        //Basic stats of the enemy
        damage = 3;
        health = 8;
        this.MaxHealth = this.EnemyHealth;

        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;
    }

    // updates the timers,attackcircle and swordposition
    public override void Update(GameTime gameTime)
    {
        //Spawn, with a delay in between, 2 mini splitenemies on his last position, if his health is below 0
        if (this.health <= 0 && !invulnerable)
        {
            SplitEnemyMini enemy1 = new SplitEnemyMini(this.Position, 100, 100, 500);
            SplitEnemyMini enemy2 = new SplitEnemyMini(this.Position, 100, 100, 2000);
            GameData.LevelObjects.Add(enemy1);
            GameData.LevelObjects.Add(enemy2);
        }

        base.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;

        //Always move to player and attack the player
        isMovingToPlayer = true;
        if (SolidColission)
        {
            MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
        }
        else MoveToPlayer(startingVelocityX, startingVelocityY);
        waitTime = 0.0f;
    }


    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        attackCircle.Draw(gameTime, spriteBatch);
        DrawTesting.DrawHitbox(spriteBatch, attackCircle.BoundingBox, Color.Blue);
    }
}

