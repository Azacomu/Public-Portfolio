﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class FERanged:GeneralEnemy
{
    Stopwatch stopWatch;
    GameObjectList projectiles;
    SpriteGameObject attackCircle;

    //initiates the simpleEnemy, the velocity and position are set with the levelloading inside the constructor
    //also has a projectiles gameobjectlist for the attacks it creates
    //has a stopwatch to time the attacks
    public FERanged(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("FERanged",1) 
    {

        if (CurrentFloor == 1)
        {
            this.LoadAnimation("blueGhost", "Idle", true, 0.1f);
            this.PlayAnimation("Idle");
            damage = 1;
            health = 8;
            dropStrength = 40;
        }
        else
        {
            this.LoadAnimation("purpleGhost", "Idle", true, 0.1f);
            this.PlayAnimation("Idle");
            health = 4;
            damage = 1;
            dropStrength = 20;
        }
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.position = startPosition;
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;

        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        projectiles = new GameObjectList(0, "attackList");

        // initializes the attackrange with a circle sprite
        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;

        waitTime = 0.0f;
        attackTimer = 0.0f;
        stopWatch = new Stopwatch();
        stopWatch.Start();

        this.MaxHealth = this.EnemyHealth;
    }

    public override void Reset()
    {
        base.Reset();

    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        projectiles.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        
        if(!knockBacked)
        {
            PlayAnimation("Idle");
        }

        waitTime -= (float)stopWatch.Elapsed.TotalSeconds;
        specialAttackTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
        attackTimer -= stopWatch.Elapsed.Seconds;
        
        if (attackCircle.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox) && !knockBacked)
        {
            if (SolidColission) 
            {
                MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
                
            }
            else MoveToPlayer(startingVelocityX, startingVelocityY);
            waitTime = 0.0f;
        }
        else isMovingToPlayer = false;

        // if the player is contained in the range(attackCircle) it attacks the player based on the attacktimer and lineofsight
        if (attackCircle.CollidesWith(GameData.GetPlayer) && (attackTimer < 0.0f) && InLineOfSight)  
        {
            Attack();
            attackTimer = 50.0f;
            stopWatch.Restart();
            specialAttackCounter = 0;
        }

        if (attackTimer > 0)
        {
            isAttacking = true;
        }
        else isAttacking = false;

        ProjectileUpdate();

    }


    //loops through the projectile list and checks if the player uses an shield it plays a sound and removes the attack
    //if it collides with the player it deals damage and removes the attack
    //if the attack collides with a solidobject that isn't a water tile it get's removed
    protected void ProjectileUpdate()
    {
        for (int i = projectiles.Objects.Count - 1; i >= 0; i--)
        {
            SpriteGameObject attack = projectiles.Objects[i] as SpriteGameObject;

            if (specialAttackTimer < 0 && isAttacking && specialAttackCounter < 4 && currentFloor == 1 && attack.ID != "specialAttack")
            {
                SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(0, missileSpeed));
                SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(0, -missileSpeed));
                SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(missileSpeed, 0));
                SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(-missileSpeed, 0));
                projectiles.Remove(attack);
                return;
            }

            if (GameData.GetPlayer.Inventory.GetItem(1) is StartingShield)
            {
                StartingShield sshield = GameData.GetPlayer.Inventory.GetItem(1) as StartingShield;
                if (sshield.HitBox.Intersects(attack.BoundingBox) && sshield.IsUsingShield)
                {
                    projectiles.Remove(attack);
                    Console.WriteLine("shieldhit");
                    GameWorld.AssetLoader.PlaySound("arrowHitShield");
                }
            }
            if (attack.CollidesWith(GameData.GetPlayer))
            {
                GameData.GetPlayer.DealDamage(damage);
                projectiles.Remove(attack);
            }
            for (int x = GameWorld.SolidObjects.Count - 1; x > 0; x--)
            {
                GameObject obj = GameWorld.SolidObjects[x];
                if (attack.CollidesWith(obj) && obj.ID != "water" && !(obj is GeneralEnemy))
                {
                    if (attack.ID != "specialAttack" && currentFloor == 1)
                    {
                        SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(0, missileSpeed));
                        SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(0, -missileSpeed));
                        SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(missileSpeed, 0));
                        SpecialAttack(attack.GlobalPosition.X, attack.GlobalPosition.Y, new Vector2(-missileSpeed, 0));
                        projectiles.Remove(attack);
                        return;
                    }
                    projectiles.Remove(attack);
                }
            }
        }
    }

    //creates a new spritegameobject with the right sprite, the position is set based on the enemys'current position
    //the velocity is set, and added to the projectile list, updates the isattacking boolea
    protected override void Attack()
    {
        SpriteGameObject simpleAttack = new SpriteGameObject("redFlame", 0, "simpleAttack", 0);
        simpleAttack.Position = new Vector2(this.GlobalPosition.X, this.GlobalPosition.Y);
        simpleAttack.Origin = new Vector2(simpleAttack.Width / 2, simpleAttack.Height / 2);
        Vector2 difference = GameData.GetPlayer.Position - this.Position;
        difference.Normalize();
        difference *= missileSpeed;
        simpleAttack.Velocity = difference;
        projectiles.Add(simpleAttack);
        GameWorld.AssetLoader.PlaySound("knockbackscroll");
        specialAttackTimer = 1f;
    }

    //creates a new spritegameobject with the right sprite, the position is set based on the enemys'current position
    //the velocity is set, and added to the projectile list, updates the isattacking boolea
    protected void SpecialAttack(float x, float y, Vector2 velocity)
    {
        AnimatedGameObject specialAttack = new AnimatedGameObject("specialAttack", 1);
        specialAttack.LoadAnimation("redFlame", "RedFlame", true, 0.1f);
        specialAttack.PlayAnimation("RedFlame");
        specialAttack.Position = new Vector2(x, y);
        specialAttack.Origin = new Vector2(specialAttack.Width / 2, specialAttack.Height / 2);
        specialAttack.Velocity = velocity;
        projectiles.Add(specialAttack);
        specialAttackCounter++;
    }


    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        projectiles.Draw(gameTime, spriteBatch);
        attackCircle.Draw(gameTime, spriteBatch);
        
    }

    

    

}
