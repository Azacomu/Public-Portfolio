﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class is for the enemy at the end of the first floor for the player to defeat to get to the next floor.
/// His special attack is spawning three areas that do damage over time if the player stands on it.
/// </summary>

class MiniBossEnemy : GeneralEnemy
{
    Stopwatch stopWatch;
    Stopwatch swTimer, swSpecActiveTimer;
    GameObjectList simpleAtt;
    List<SpriteGameObject> specials;
    SpriteGameObject specialArea;
    int projectileSpeed, projectileScale;
    int specDamage, nmbSpecArea;
    int specialTimerBegin, specialTimerEnd, beginAttack;
    int widthLeft, heightTop;
    float attTime;
    float specialTimer, specTimer;
    bool specialVisible;

    public MiniBossEnemy(Vector2 startPosition) : base("MiniBoss1", 1)
    {
        LoadAnimation("miniBoss1Enemy", "MovingUp", false, 0.1f);
        PlayAnimation("MovingUp");

        hitboxSprite = new SpriteSheet("miniBoss1Enemy", 0);

        this.position = startPosition;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        Position += Origin;

        //Stopwatch for special attack timer, freeze time player and boss
        swTimer = new Stopwatch();
        swTimer.Start();
        swSpecActiveTimer = new Stopwatch();

        //Values for the special attack
        specialTimer = 0.0f;
        specTimer = 30.0f;
        specDamage = 1;
        specialTimerBegin = 5;
        specialTimerEnd = 3;

        //Basic stats of the enemy
        simpleAtt = new GameObjectList(0, "simpleAttackList");
        beginAttack = 1000;
        projectileSpeed = 600;
        projectileScale = 2;
        damage = 2;
        health = 15;
        this.MaxHealth = this.EnemyHealth;
        DropStrength = 60;

        //Timers for basic attack
        attackTimer = 0.0f;
        waitTime = 0.0f;
        attTime = 40.0f;
        stopWatch = new Stopwatch();
        stopWatch.Start();

        //Special attack area

        //X- and Y-position where the playing field is. (Width of hud left side and a wall)
        widthLeft = GameSettings.GameFieldOffset + GameSettings.TileWidth;
        heightTop = GameSettings.GameFieldOffset + GameSettings.TileHeight;
        specialVisible = false;
        nmbSpecArea = 3;
        specials = new List<SpriteGameObject>();
        for (int i = 0; i < nmbSpecArea; i++)
        {
            specialArea = new SpriteGameObject("infectedArea", 0, "specialAttack1", 0);
            specialArea.Position = Vector2.Zero;
            specials.Add(specialArea);
        }
    }

    public override void Update(GameTime gameTime)
    {
        if (this.health <= 0)
        {
            CheckAchievements();
            GameWorld.AssetLoader.PlayMusic("floor1music");
        }

        base.Update(gameTime);
        simpleAtt.Update(gameTime);
        attackTimer -= stopWatch.Elapsed.Seconds;
        specialTimer -= stopWatch.Elapsed.Seconds;
        waitTime -= (float)stopWatch.Elapsed.TotalSeconds;

        //Attacks the player after 1 second into the game
        if (gameTime.TotalGameTime.TotalMilliseconds >= beginAttack && (attackTimer < 0.0f))
        {
            Attack();
            attackTimer = attTime;
            stopWatch.Restart();
        }

        //Initiation of the special attack of the boss
        if (swTimer.Elapsed.Seconds > specialTimerBegin)
            SpecialAttackBegin();

        //check if the special area collides with enemy and deal damage
        for (int i = 0; i < specials.Count; i++)
        {
            if (specials[i].CollidesWith(GameData.GetPlayer) && (specialTimer < 0.0f) && specialVisible)
            {
                GameData.GetPlayer.DealDamage(specDamage);
                specialTimer = specTimer;
            }
        }

        //End the special attack if the special is 'specialTimerEnd' seconds active
        if (swSpecActiveTimer.Elapsed.Seconds > specialTimerEnd)
            SpecialAttackEnd();

        //check for all the attacks if they collide, deal damage or delete it
        for (int i = 0; i < simpleAtt.Objects.Count; i++)
        {
            SpriteGameObject attack = simpleAtt.Objects[i] as SpriteGameObject;
            if (attack.CollidesWith(GameData.GetPlayer))
            {
                GameData.GetPlayer.DealDamage(damage);
                simpleAtt.Remove(simpleAtt.Objects[i]);
            }
            for (int x = GameWorld.SolidObjects.Count - 1; x > 0; x--)
            {
                GameObject obj = GameWorld.SolidObjects[x];
                if (attack.CollidesWith(obj) && obj.ID != "water" && !(obj is GeneralEnemy))
                {
                    simpleAtt.Remove(attack);
                }
            }
        }

    }

    //Draw method, draws the enemy and if the special attack is visible, draw the area
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (specialVisible)
        {
            for (int i = 0; i < specials.Count; i++)
            {
                specials[i].Draw(gameTime, spriteBatch);
            }
        }
        simpleAtt.Draw(gameTime, spriteBatch);
        base.Draw(gameTime, spriteBatch);
    }

    //basic attack of the Boss
    protected override void Attack()
    {
        //Makes a simple attack
        AnimatedGameObject simpleAttack = new AnimatedGameObject("projectile", 0);
        simpleAttack.LoadAnimation("greenFire","greenFire", true, 0.1f);
        simpleAttack.PlayAnimation("greenFire");
        simpleAttack.Scale = projectileScale;
        simpleAttack.Position = new Vector2(this.GlobalPosition.X, this.GlobalPosition.Y);
        simpleAttack.Origin = new Vector2(simpleAttack.Width / 2, simpleAttack.Height / 2);

        //Calculates the ratios of X and Y values for the angle to shoot at the player
        Vector2 difference = GameData.GetPlayer.Position - this.Position;
        difference.Normalize();
        difference *= projectileSpeed;
        simpleAttack.Velocity = difference;

        //Add the attack in the list
        simpleAtt.Add(simpleAttack);
        GameWorld.AssetLoader.PlaySound("fireball");
    }

    //Initialize the special attack
    protected void SpecialAttackBegin()
    {
        specialVisible = true;
        swTimer.Reset();
        swSpecActiveTimer.Start();

        //Set a random position for the special area inside the playing area
        for (int i = 0; i < specials.Count; i++)
        {
            //Random number in the width and height of the playing field and substracting the width/height of the special area.
            //(minus two tiles which are meant for the left and right walls)
            specials[i].PositionX = this.widthLeft + R.Dice((LevelLoader.horTiles - 2) * GameSettings.TileWidth - specialArea.Width);
            specials[i].PositionY = heightTop + R.Dice((LevelLoader.verTiles - 2) * GameSettings.TileHeight - specialArea.Width);

            for (int j = 0; j < specials.Count; j++)
            {
                SpriteGameObject temp1 = specials[i];
                SpriteGameObject temp2 = specials[j];
                if (temp1 != temp2)
                {
                    while (temp1.CollidesWith(GameData.GetPlayer) || temp1.CollidesWith(this) || temp1.CollidesWith(temp2))
                    {
                        specials[i].PositionX = widthLeft + R.Dice((LevelLoader.horTiles - 2) * GameSettings.TileWidth - specialArea.Width);
                        specials[i].PositionY = heightTop + R.Dice((LevelLoader.verTiles - 2) * GameSettings.TileHeight - specialArea.Width);
                    }
                }
            
            }
        }
        GameWorld.AssetLoader.PlaySound("infSpawn");

    }

    //End the special attack
    protected void SpecialAttackEnd()
    {
        specialVisible = false;
        GameWorld.AssetLoader.PlaySound("infDespawn");
        swSpecActiveTimer.Reset();
        swTimer.Start();
    }

    protected override void KnockBack(GameTime gameTime)
    {
    }

    protected void CheckAchievements()
    {
        //Kill Necrotaul.
        if (!(MainGame.AchievementController.GetFinished("Necrotaul")))
        {
            MainGame.AchievementController.FinishAchievement("Necrotaul");
        }
    }
}