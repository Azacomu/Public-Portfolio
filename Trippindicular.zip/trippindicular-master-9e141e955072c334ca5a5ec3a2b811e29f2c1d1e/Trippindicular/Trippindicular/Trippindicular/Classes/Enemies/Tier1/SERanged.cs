﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class SERanged : GeneralEnemy
{
    GameObjectList projectiles;
    Stopwatch stopWatch;
    //initiates the simpleEnemy, the velocity and position are set with the levelloading inside the constructor
    //also has a projectiles gameobjectlist for the attacks it creates
    // has a stopwatch to time the attacks
    public SERanged(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("SERanged",1)
    {
        this.LoadAnimation("ghost", "Idle", true, 0.1f);
        this.PlayAnimation("Idle");

        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.position = startPosition + Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;

        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        projectiles = new GameObjectList(0, "attackList");

        attackTimer = 0.0f;
        stopWatch = new Stopwatch();
        stopWatch.Start();

        damage = 1;
        health = 4;
        dropStrength = 20;

        this.MaxHealth = this.EnemyHealth;

    }
    //updates the projectiles shot from the enemy and checks if the projectile collides with the player or another object
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        projectiles.Update(gameTime);

        attackTimer -= stopWatch.Elapsed.Seconds;
        specialAttackTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;

        //plays the animation if not knockbacked
        if(!knockBacked)
        {
            PlayAnimation("Idle");
        }

        // if the player is contained in the line of sight it attacks
        if ((attackTimer < 0.0f) && InLineOfSight)  
        {
                Attack();
                attackTimer = 50.0f;
                stopWatch.Restart();
                specialAttackCounter = 0;
        }

        
        if (attackTimer > 0)
        {
            isAttacking = true;
        }
        else isAttacking = false;

        ProjectileUpdate();

    }

    //loops through the projectile list and checks if the player uses an shield it plays a sound and removes the attack
    //if it collides with the player it deals damage and removes the attack
    //if the attack collides with a solidobject that isn't a water tile it get's removed
    protected void ProjectileUpdate()
    {
        for (int i = projectiles.Objects.Count - 1; i >= 0; i--)
        {
            SpriteGameObject attack = projectiles.Objects[i] as SpriteGameObject;

            if (GameData.GetPlayer.Inventory.GetItem(1) is StartingShield)
            {
                StartingShield sshield = GameData.GetPlayer.Inventory.GetItem(1) as StartingShield;
                if (sshield.HitBox.Intersects(attack.BoundingBox) && sshield.IsUsingShield)
                {
                    projectiles.Remove(attack);
                    Console.WriteLine("shieldhit");
                    GameWorld.AssetLoader.PlaySound("arrowHitShield");
                }
            }
            if (attack.CollidesWith(GameData.GetPlayer))
            {
                GameWorld.AssetLoader.PlaySound("startingSwordhit");
                GameData.GetPlayer.DealDamage(damage);
                projectiles.Remove(attack);

            }
            for (int x = GameWorld.SolidObjects.Count - 1; x > 0; x--)
            {
                GameObject obj = GameWorld.SolidObjects[x];
                if (attack.CollidesWith(obj) && obj.ID != "water")
                {
                    projectiles.Remove(attack);
                }
            }
        }
    }

    //creates a new spritegameobject with the right sprite, the position is set based on the enemys'current position
    //the velocity is set, and added to the projectile list, updates the isattacking boolea
    protected override void Attack()
    {

        SpriteGameObject simpleAttack = new SpriteGameObject("redFlame", 0, "simpleAttack", 0);
        simpleAttack.Position = new Vector2(this.GlobalPosition.X, this.GlobalPosition.Y);
        simpleAttack.Origin = new Vector2(simpleAttack.Width / 2, simpleAttack.Height / 2);
        Vector2 difference = GameData.GetPlayer.Position - this.Position;
        difference.Normalize();
        difference *= missileSpeed;
        simpleAttack.Velocity = difference;
        projectiles.Add(simpleAttack);
        GameWorld.AssetLoader.PlaySound("knockbackscroll");
        specialAttackTimer = 1.5f;
        
    }
    //creates a new spritegameobject with the right sprite, the position is set based on the enemys'current position
    //the velocity is set, and added to the projectile list, updates the isattacking boolea
    protected void SpecialAttack(float x, float y, Vector2 velocity)
    {
        AnimatedGameObject specialAttack = new AnimatedGameObject("specialAttack", 1);
        specialAttack.LoadAnimation("redFlame", "RedFlame", true, 0.1f);
        specialAttack.PlayAnimation("RedFlame");
        specialAttack.Position = new Vector2(x, y);
        specialAttack.Origin = new Vector2(specialAttack.Width / 2, specialAttack.Height / 2);
        specialAttack.Velocity = velocity;
        projectiles.Add(specialAttack);
        specialAttackCounter++;
        Console.WriteLine("Special attack");
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        projectiles.Draw(gameTime, spriteBatch);
    }
}
