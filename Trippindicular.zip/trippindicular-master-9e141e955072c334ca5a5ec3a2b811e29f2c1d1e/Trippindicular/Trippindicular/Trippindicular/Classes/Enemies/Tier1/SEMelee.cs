﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


class SEMelee : GeneralEnemy
{
    //initiates the the velocity and position are set with the levelloading inside the constructor
    //based on the currentfloor it's on it loads different animation and sets the strength and health properties
    //it sets both the startingvelocities to the value which is given in the constructor
    public SEMelee(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("SEMelee",1)
    {
        this.LoadAnimation("meleeEnemyUp", "MovingUp", true, 0.1f);
        this.PlayAnimation("MovingUp");
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.position = startPosition;
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;

        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        DropStrength = 10;
        damage = 1;
        health = 6;
       
        this.MaxHealth = this.EnemyHealth;

    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        // if this isn't knockbacked the animation get's updated
        if (!knockBacked)
        {
            AnimationHelper();
        }

        // if the enemies "sees" the player it moves faster towards the player
        if(InLineOfSight && !knockBacked)
        {
            MoveToPlayer(200, 200);
        }
        else isMovingToPlayer = false;
        
        
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
    }

    //updates the animation based on the direction its facing
    protected void AnimationHelper()
    {
        switch (direction)
        {
            case "right":
                PlayAnimation("MovingUp");
                //animations["MovingRight"].Mirror = false;
                break;
            case "left":
                PlayAnimation("MovingUp");
                //animations["MovingRight"].Mirror = true;
                break;
            case "up":
                PlayAnimation("MovingUp");
                break;
            case "down":
                PlayAnimation("MovingUp");
                animations["MovingUp"].Mirror = true;
                break;
            default:
                break;
        }
    }
}

