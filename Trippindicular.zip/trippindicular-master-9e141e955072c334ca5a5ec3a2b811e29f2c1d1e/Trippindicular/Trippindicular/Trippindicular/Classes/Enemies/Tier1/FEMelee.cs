﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class FEMelee : GeneralEnemy
{
    SpriteGameObject attackCircle;

    //initiates the the velocity and position are set with the levelloading inside the constructor
    //based on the currentfloor it's on it loads different animation and sets the strength and health properties
    //it initiates a attackCircle spritegameobject, if this circle collides with the player it moves towards the player
    //it sets both the startingvelocities to the value which is given in the constructor
    public FEMelee(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("FEMelee", 1)
    {
        if (GameData.CurrentFloor == 1)
        {
            this.LoadAnimation("meleeEnemyUp3", "MovingUp", true, 0.1f);
            this.PlayAnimation("MovingUp");
            dropStrength = 40;
            damage = 2;
            health = 10;
        }
        else
        {
            this.LoadAnimation("meleeEnemyUp2", "MovingUp", true, 0.1f);
            this.PlayAnimation("MovingUp");
            DropStrength = 20;
            damage = 1;
            health = 6;
        }

        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.position = startPosition;
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;


        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        attackTimer = 0.0f;
        waitTime = 0.5f;
        
        this.MaxHealth = this.EnemyHealth;

        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;
    }


    public override void Update(GameTime gameTime)
    {

        base.Update(gameTime);

        //if the enemy isn't knockbacked it updates the current animation
        // based on the direction it is facing
        if (!knockBacked)
        {
            AnimationHelper();
        }

        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;
        
        //if the attackCircle bounding box intersects with the players' it moves towards the player
        //based on the startingvelocity, if there's a solid object in the way it uses movetoplayerspecial
        //this way it walks around the objects
        if (attackCircle.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox) && !knockBacked)
        {
            isMovingToPlayer = true;
            if (moveSpecialTimer > 4f)
            {
                MoveRandom();
            }
            else if (SolidColission) 
            {
                MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
            }
            else MoveToPlayer(startingVelocityX, startingVelocityY);
            waitTime = 0.0f;
        }
        else isMovingToPlayer = false;

        
    }


    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        attackCircle.Draw(gameTime, spriteBatch);
    }

    
    //adjusts the position of the sword based on the players' direction
    protected void AnimationHelper()
    {
        switch (direction)
        {
            case "right":
                PlayAnimation("MovingUp");
                //animations["MovingRight"].Mirror = false;
                break;
            case "left":
                PlayAnimation("MovingUp");
                //animations["MovingRight"].Mirror = true;
                break;
            case "up":
                PlayAnimation("MovingUp");
                break;
            case "down":
                PlayAnimation("MovingUp");
                animations["MovingUp"].Mirror = true;
                break;
            default:
                break;
        }
    }
}

