﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
class Watersprout : GeneralEnemy
{
    GameObjectList projectiles;
    Stopwatch stopWatch;
    Stopwatch stopWatchAttack;


    //obsolete, still here for later purposes
    public Watersprout(Vector2 startPosition) : base("placeholderEnemy", 1)
    {
        this.LoadAnimation("placeholderEnemy", "Idle", false, 0.1f);
        this.PlayAnimation("Idle");

        this.position = startPosition;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        
        projectiles = new GameObjectList(0, "attackList");

        waitTime = 200f;
        stopWatch = new Stopwatch();
        stopWatch.Start();
        stopWatchAttack = new Stopwatch();
        stopWatchAttack.Start();
        this.Visible = false;

        if(GameData.CurrentFloor == 2)
        {
            damage = 3;
            health = 6;
        }
        else if(GameData.CurrentFloor == 1)
        {
            damage = 2;
            health = 6;
        }
        else
        {
            damage = 1;
            health = 4;
        }

        this.MaxHealth = this.EnemyHealth;
    }

    //updates the projectiles shot from the enemy and checks if the projectile collides with the player or another object
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        projectiles.Update(gameTime);

        attackTimer -= stopWatchAttack.Elapsed.Seconds;
        waitTime -= (float)stopWatch.Elapsed.TotalSeconds;

        if (waitTime <300f)
        {
            this.Visible = true;
            if (waitTime < 0)
            {

                waitTime = 400f;
                stopWatch.Restart();
            }
        }

        if (waitTime> 300f)
        {
            this.Visible = false;
        }


        // if the player is contained in the line of sight it attacks
        if ((attackTimer < 0.0f) && this.Visible)
        {
            Attack();
            attackTimer = 50.0f;
            stopWatchAttack.Restart();
        }

        //checks for every projectile inside the projectile list if it collides with the player or the shield 
        for (int i = 0; i < projectiles.Objects.Count; i++)
        {
            SpriteGameObject attack = projectiles.Objects[i] as SpriteGameObject;
            if (GameData.GetPlayer.Inventory.GetItem(1) is StartingShield)
            {
                StartingShield sshield = GameData.GetPlayer.Inventory.GetItem(1) as StartingShield;
                if (sshield.HitBox.Contains(attack.BoundingBox))
                {
                    projectiles.Remove(projectiles.Objects[i]);
                    Console.WriteLine("shieldhit");
                    GameWorld.AssetLoader.PlaySound("arrowHitShield");
                }
            }
            if (attack.CollidesWith(GameData.GetPlayer))
            {
                GameWorld.AssetLoader.PlaySound("startingSwordhit");
                GameData.GetPlayer.CurHealth -= this.Damage;
                projectiles.Remove(projectiles.Objects[i]);
            }
            if (attack.CollidesWith(GameData.LevelObjects))
            {
                projectiles.Remove(projectiles.Objects[i]);
                Console.WriteLine("collides");
            }
        }

    }

    //creates a new spritegameobject, and gives it a velocity and shoots it from the the enemy
    protected override void Attack()
    {
        SpriteGameObject simpleAttack = new SpriteGameObject("projectile", 0, "simpleAttack", 0);
        simpleAttack.Position = new Vector2(this.GlobalPosition.X, this.GlobalPosition.Y);
        simpleAttack.Origin = new Vector2(simpleAttack.Width / 2, simpleAttack.Height / 2);
        Vector2 difference = GameData.GetPlayer.Position - this.Position;
        difference.Normalize();
        difference *= 600;
        simpleAttack.Velocity = difference;
        projectiles.Add(simpleAttack);
        GameWorld.AssetLoader.PlaySound("arrowFire");
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        projectiles.Draw(gameTime, spriteBatch);
    }

    protected override void KnockBack(GameTime gameTime)
    {
        
    }
}

