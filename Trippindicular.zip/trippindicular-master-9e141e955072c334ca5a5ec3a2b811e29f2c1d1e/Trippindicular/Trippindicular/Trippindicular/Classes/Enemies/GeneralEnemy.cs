﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using System.Diagnostics;
class GeneralEnemy : AnimatedGameObject
{
    protected string direction;
    protected int damage;
    protected float waitTime;
    protected float attackTimer;
    protected float knockBackTimer;
    protected float moveRandomTimer;
    protected float moveSpecialTimer;
    protected float moveTimer;
    protected float startingVelocityX;
    protected float startingVelocityY;
    protected float recoverTimer;
    protected float stunTimer;
    protected float fearTimer;
    protected float movingSpecialTimer;
    protected float specialAttackTimer;
    protected bool feared;
    protected bool isMovingToPlayer;
    protected bool isAttacking;
    protected bool knockBacked;
    protected bool stunned;
    protected bool invulnerable;
    protected bool digging;
    protected bool enemyCollision;
    protected float health;
    protected float maxHealth;
    protected int turnAroundCounter;
    protected int collideCounter;
    protected int currentFloor;
    protected int specialAttackCounter;
    protected int dropStrength;
    protected int missileSpeed;
    protected HealthBar healthBar;


    virtual public bool Feared
    {
        get { return feared; }
        set { feared = value; }
    }

    virtual public float FearTimer
    {
        get { return fearTimer; }
        set { fearTimer = value; }
    }

    virtual public bool Stunned
    {
        get { return stunned; }
        set { stunned = value; }
    }
    virtual public float StunTimer
    {
        get { return stunTimer; }
        set { stunTimer = value; }
    }

    virtual public float KnockBackTimer
    {
        get { return knockBackTimer; }
        set { knockBackTimer = value; }
    }
    virtual public bool KnockBacked
    {
        get { return knockBacked; }
        set { knockBacked = value; }
    }

    virtual public float EnemyHealth
    {
        get { return this.health; }
        set { this.health = value; }
    }

    virtual public int Damage
    {
        get { return this.damage; }
        set { this.damage = value; }
    }

    virtual public int CurrentFloor
    {
        get { return this.currentFloor;}
    }

    virtual public int DropStrength
    {
        get { return dropStrength; }
        set { dropStrength = value; }
    }

    virtual public float MaxHealth
    {
        get { return maxHealth; }
        set { maxHealth = value; }
    }

    virtual public bool Invulnerable
    {
        get { return invulnerable; }
    }

    //The superclass for the enemies, it initializes all of the timers, the healthbar of the the enemies
    //and checks what the currentfloor is and sets it's value to the designated property
    public GeneralEnemy(string id = "", int layer = 0) : base("Enemy", layer)
    {
        direction = "";

        isAttacking = false;
        isMovingToPlayer = false;
        stunned = false;
        knockBacked = false;
        feared = false;
        digging = false;
        
        currentFloor = GameData.CurrentFloor;

        moveSpecialTimer = 0f;
        knockBackTimer = 0.0f;
        recoverTimer = 0.0f;
        moveRandomTimer = 0.0f;
        movingSpecialTimer = 0.0f;
        moveTimer = 0.0f;
        stunTimer = 0.0f;
        fearTimer = 0.0f;
        movingSpecialTimer = 0f;
        turnAroundCounter = 0;
        movingSpecialTimer = 0;
        specialAttackCounter = 0;
        missileSpeed = 400;

        healthBar = new HealthBar(this.GlobalPosition);
        this.LoadAnimation("knockback", "knockback", false, 0.1f); 
        this.Solid = false;
        startingVelocityX = 0f;
        startingVelocityY = 0f;
    }

    public override void Update(GameTime gameTime)
    {
        if (stunned)
        {
            Stun(gameTime);
            return;
        }

        base.Update(gameTime);
        
        //updates the boolean based on the CheckEnemyCollision method
        enemyCollision = CheckEnemyCollision();

        //if there's a collision between the enemy and something solid or between two enemies and they aren't digging
        //the position gets reset before the collision, this way it won't get stuck in an object
        if (solidCollision && !digging || enemyCollision && !digging)
            position = oldPosition;

        // if there's is a collision between an enemy and a digging enemy, the digging enemy gets knockbacked for .2 seconds
        // this way the enemies don't get stuck on eachother
        if(enemyCollision && digging)
        {
            knockBackTimer = .2f;
            knockBacked = true;
            position = OldPosition;
            SpecialKnockBack(gameTime);
        }

        movingSpecialTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
        moveTimer -= gameTime.ElapsedGameTime.Seconds;
        UpdateHealthBar();
        KnockBackRecover(gameTime);

        // if it get's knockbacked and there isn't a solidCollision or enemyCollison or isn't digging
        // the knockback plays
        if (knockBacked && !solidCollision && !enemyCollision && !digging)
        {
            KnockBack(gameTime);
        }

        //if the enemy's boundingbox intersects with the player && !digging && Visible
        // the enemy gets knockbacked, this way it doesnt instakill the player
        // it also deals the damage once based on the collidecounter which gets reset when the 
        // knockback is done
        if (this.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox) && !digging && Visible)
        {
            if (collideCounter == 0)
            {
                knockBacked = true;
                knockBackTimer = 1f;
                GameData.GetPlayer.DealDamage(damage);
                collideCounter++;
                GameWorld.AssetLoader.PlaySound("hithurt");
            }
        }

        //when the enemy collides with a solidobject and its not moving towards the player 
        // or isnt getting knockbacked. it turns around
        if (solidCollision && !isMovingToPlayer && !knockBacked)
        {
            TurnAround();
        }

        // if enemies collide with eachother they choose a random point to move towards
        // the random point is contained inside the level's boundaries
        if (enemyCollision && !knockBacked && !digging)
        {
            MoveToPoint(new Vector2(R.Dice(29) * tileWidth, R.Dice(14) * tileHeight));
        }

        // when the enemy has turned around 2 times, it moves towards a random location
        if (turnAroundCounter >= 2)
        {
            moveRandomTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (moveRandomTimer < 0)
            {
                MoveRandom();
            }
        }

        // if the move special timer is bigger than 5 and the enemy isn't moving towards the player
        // it moves towards a random point
        if(movingSpecialTimer > 5f && !isMovingToPlayer)
        {
            MoveToPoint(new Vector2(R.Dice(29) * tileWidth, R.Dice(14) * tileHeight));
        }


        if (this.health <= 0)
        {
            Die();
        }

        // updates the direction string based on the velocity
        DirectionUpdate();

        // updates the velocity towards it's starting velocity, some enemies use different
        // velocities when moving towards the player
        if (!isMovingToPlayer && !knockBacked)
        {
            VelocityUpdate();
        }
        


    }

    // checks if the player is in his line of sight based on his current direction and if the player is contained is his boundingbox
    virtual protected bool InLineOfSight
    {
        get
        {
            float playerPosX = GameData.GetPlayer.GlobalPosition.X;
            float playerPosY = GameData.GetPlayer.GlobalPosition.Y;
            int playerBBRight = GameData.GetPlayer.BoundingBox.Right;
            int playerBBLeft = GameData.GetPlayer.BoundingBox.Left;
            int playerBBTop = GameData.GetPlayer.BoundingBox.Top;
            int playerBBBottom = GameData.GetPlayer.BoundingBox.Bottom;
            int PlayerHeightHalf = GameData.GetPlayer.Height / 2;

            if (direction == "up" && this.GlobalPosition.Y >= playerPosY && (int)this.GlobalPosition.X <= playerBBRight && (int)this.GlobalPosition.X >= playerBBLeft)
                return true;
            else if (direction == "down" && this.GlobalPosition.Y < playerPosY && (int)this.GlobalPosition.X < playerBBRight && (int)this.GlobalPosition.X > playerBBLeft)
                return true;
            else if (direction == "right" && (int)this.GlobalPosition.Y > playerBBTop - PlayerHeightHalf && this.GlobalPosition.Y < playerBBBottom +PlayerHeightHalf && this.GlobalPosition.X < playerPosX)
                return true;
            else if (direction == "left" && (int)this.GlobalPosition.Y > playerBBTop - PlayerHeightHalf && this.GlobalPosition.Y < playerBBBottom + PlayerHeightHalf && this.GlobalPosition.X > playerPosX)
                return true;
            else return false;
        }

    }

    virtual protected void Attack()
    {

    }

    // updates the enemykill achievement
    // drops an item based on the dropstrength
    // removes this from the game
    virtual protected void Die()
    {
        GameData.EnemyKill();
        DropItem();
        GameData.LevelObjects.Remove(this);
    }

    //updates the velocity based on the direction it's facing, startingvelocity is given in the constructor of every enemy
    virtual protected void VelocityUpdate()
    {
        switch (direction)
        {
            case "right":
                this.VelocityX = startingVelocityX;
                break;
            case "left":
                this.VelocityX = -startingVelocityX;
                break;
            case "up":
                this.VelocityY = -startingVelocityY;
                break;
            case "down":
                this.VelocityY = startingVelocityY;
                break;
            default:
                break;
        }
    }

    

    //updates the direction based on the current velocity
    virtual protected void DirectionUpdate()
    {
        if (this.velocity.X > 0)
            direction = "right";
        if (this.velocity.X < 0)
            direction = "left";
        if (this.velocity.Y > 0)
            direction = "down";
        if (this.velocity.Y < 0)
            direction = "up";
    }

    //updates the position of the healthbar and if damage is done to the enemy it changes the color/width of the bar
    virtual protected void UpdateHealthBar()
    {
        healthBar.Update(new Vector2(this.BoundingBox.Center.X, this.BoundingBox.Top));
        healthBar.ChangeHealth((float)this.EnemyHealth / (float)this.MaxHealth);
    }
    
    // drops an item based on the dropstrength given to the enemyand adds it to the levelobjects list, dropstrength is given to every enemy
    virtual protected void DropItem()
    {
        List<Items> obj = DropTable.MonsterDrop(DropStrength);
        if (obj != null)
        {
            for (int i = obj.Count - 1; i >= 0; i--)
            {
                if (obj[i] != null)
                {
                    GameData.LevelObjects.Add(obj[i]);
                    obj[i].Position = this.position + new Vector2(obj[i].Width * i, 0);
                }
            }
        }
    }

    // move's to the player based on the difference in the position between the player and the current position
    // and reflects what difference is higher 
    virtual protected void MoveToPlayer(float x, float y)
    {
            float differenceXPos = Math.Abs(GameData.GetPlayer.GlobalPosition.X - this.GlobalPosition.X);
            float differenceYPos = Math.Abs(GameData.GetPlayer.GlobalPosition.Y - this.GlobalPosition.Y);
            if (differenceXPos > differenceYPos && GameData.GetPlayer.GlobalPosition.X > this.GlobalPosition.X)
                this.Velocity = new Vector2(x, 0);
            if (differenceXPos > differenceYPos && GameData.GetPlayer.GlobalPosition.X < this.GlobalPosition.X)
                this.Velocity = new Vector2(-x, 0);
            if (differenceXPos < differenceYPos && GameData.GetPlayer.GlobalPosition.Y < this.GlobalPosition.Y)
                this.Velocity = new Vector2(0, -y);
            if (differenceXPos < differenceYPos && GameData.GetPlayer.GlobalPosition.Y > this.GlobalPosition.Y)
                this.Velocity = new Vector2(0, y);
            isMovingToPlayer = true;
    }

    // if there's a solidcollision it only bases its velocity on the difference between its position and the players position
    // this way you avoid being stuck on an object
    virtual protected void MoveToPlayerSpecial(float x, float y)
    {
        switch (direction)
        {
            case "right":
                if (this.GlobalPosition.Y < GameData.GetPlayer.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(0, y);
                }
                else if(this.GlobalPosition.Y >GameData.GetPlayer.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(0, -y);
                }
                break;
            case "left":
                if (this.GlobalPosition.Y < GameData.GetPlayer.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(0, y);
                }
                else if (this.GlobalPosition.Y > GameData.GetPlayer.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(0, -y);
                }
                break;
            case "up":
                if (this.GlobalPosition.X < GameData.GetPlayer.GlobalPosition.X)
                {
                    this.Velocity = new Vector2(x, 0);
                }
                else if (this.GlobalPosition.X > GameData.GetPlayer.GlobalPosition.X)
                {
                    this.Velocity = new Vector2(-x, 0);
                }
                break;
            case "down":
                if (this.GlobalPosition.X < GameData.GetPlayer.GlobalPosition.X)
                {
                    this.Velocity = new Vector2(x, 0);
                }
                else if (this.GlobalPosition.X > GameData.GetPlayer.GlobalPosition.X)
                {
                    this.Velocity = new Vector2(-x, 0);
                }
                break;
            default: this.Velocity = Vector2.Zero;
                break;
        }
        isMovingToPlayer = true;
    }

    // moves with the opposite velocity based on a random number
    virtual protected void MoveRandom()
    {
        int random = R.Dice(2);
           switch (direction)
        {
            case "right":
                this.VelocityX = 0f;
                if (random == 1)
                {
                    this.VelocityY = startingVelocityY;
                }
                else this.VelocityY = -startingVelocityY;
                break;
            case "left":
                this.VelocityX = 0f;
                if (random == 1)
                {
                    this.VelocityY = startingVelocityY;
                }
                else this.VelocityY = -startingVelocityY;
                break;
            case "up":
                this.VelocityY = 0f;
                if (random == 1)
                {
                    this.VelocityX = startingVelocityX;
                }
                else this.VelocityX = -startingVelocityX;
                break;
            case "down":
                this.VelocityY = 0f;
                if (random == 1)
                {
                    this.VelocityX = startingVelocityX;
                }
                else this.VelocityX = -startingVelocityX;
                break;
            default:
                break;
        
        }
        turnAroundCounter = 0;
        moveRandomTimer = 1f;
    }

    //uses a vector as a reference point and moves towards it
    virtual protected void MoveToPoint(Vector2 Pos)
    {
        float differenceXPos = Math.Abs(Pos.X - this.GlobalPosition.X);
        float differenceYPos = Math.Abs(Pos.Y - this.GlobalPosition.Y);
        if (differenceXPos > differenceYPos && Pos.X > this.GlobalPosition.X)
            this.Velocity = new Vector2(startingVelocityX, 0);
        if (differenceXPos > differenceYPos &&  Pos.X < this.GlobalPosition.X)
            this.Velocity = new Vector2(-startingVelocityX, 0);
        if (differenceXPos < differenceYPos && Pos.Y < this.GlobalPosition.Y)
            this.Velocity = new Vector2(0, -startingVelocityY);
        if (differenceXPos < differenceYPos && Pos.Y > this.GlobalPosition.Y)
            this.Velocity = new Vector2(0, startingVelocityY);
        movingSpecialTimer = 0.0f;
    }

    // updates the recover timer, only if the recover timer is bigger than the stuntimer
    // it loops through the whole update method
    virtual protected void Stun(GameTime gameTime)
    {
        Console.WriteLine("stunned!");
        recoverTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
        if (recoverTimer > stunTimer)
        {
            Stunned = false;
            StunTimer = 0;
            recoverTimer = 0.0f;
            Console.WriteLine("notstunned!");
        }
        else return;
    }

    //adjusts the position of the enemy based on a timer, if the property KnockBacked is set to true
    // we are getting knockbacked and the timer starts running and if it runs out it can move again
    virtual protected void KnockBack(GameTime gameTime)
    {  
        this.Velocity = Vector2.Zero;
        if (GameData.GetPlayer.GlobalPosition.X > this.GlobalPosition.X)
            this.PositionX -= 2;
        if (GameData.GetPlayer.GlobalPosition.X < this.GlobalPosition.X)
            this.PositionX += 2;
        if (GameData.GetPlayer.GlobalPosition.Y < this.GlobalPosition.Y)
            this.PositionY += 2;
        if (GameData.GetPlayer.GlobalPosition.Y > this.GlobalPosition.Y)
            this.PositionY -= 2;
        solidCollision = CheckSolidCollision();
        if (solidCollision)
        {
            position = oldPosition;
            knockBacked = false;
            KnockBackTimer = 0f;
            recoverTimer = 0f;
            return;
        }
    }
    
    //
    virtual protected void SpecialKnockBack(GameTime gameTime)
    {
        this.Velocity = Vector2.Zero;
        if (GameData.GetPlayer.GlobalPosition.X > this.GlobalPosition.X)
            this.PositionX -= 2;
        if (GameData.GetPlayer.GlobalPosition.X < this.GlobalPosition.X)
            this.PositionX += 2;
        if (GameData.GetPlayer.GlobalPosition.Y < this.GlobalPosition.Y)
            this.PositionY += 2;
        if (GameData.GetPlayer.GlobalPosition.Y > this.GlobalPosition.Y)
            this.PositionY -= 2;
        enemyCollision = CheckEnemyCollision();
        if (enemyCollision)
        {
            position = oldPosition;
            knockBacked = false;
            KnockBackTimer = 0f;
            recoverTimer = 0f;
            return;
        }
    }

    // updates the recovertimer , and resets the knockbacktimer
    // plus it sets the knockback to false
    virtual protected void KnockBackRecover(GameTime gameTime)
    {
        recoverTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;

        if (recoverTimer > knockBackTimer)
        {
            knockBackTimer = 0f;
            recoverTimer = 0f;
            knockBacked = false;
            collideCounter = 0;
        }
    }

    //set's the animation to mirrored and makes the current velocity the opposite
    virtual protected void TurnAround()
    {
        this.Mirror = !this.Mirror;
        if(this.Mirror)
        this.velocity.X = -this.velocity.X;
        this.velocity.Y = -this.velocity.Y;
        turnAroundCounter++;
    }

    
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        healthBar.Draw(gameTime, spriteBatch);
    }

    public override void Reset()
    {
        base.Reset();
    }

    // a seperate method for checking the enemy list which contains all enemies
    // returns true if it pixelcollides with an other enemy
    public bool CheckEnemyCollision()
    {
        foreach (GameObject obj in GameData.Enemies)
        {
            SpriteGameObject sprObj = obj as SpriteGameObject;
            if (sprObj == null || !sprObj.Visible || obj == this)
                continue;

            Rectangle intersect = Collision.Intersection(BoundingBox, sprObj.BoundingBox);

            for (int x = 0; x < intersect.Width; x++)
                for (int y = 0; y < intersect.Height; y++)
                {
                    int thisx = intersect.X - (int)(GlobalPosition.X - Origin.X) + x;
                    int thisy = intersect.Y - (int)(GlobalPosition.Y - Origin.Y) + y;
                    int objx = intersect.X - (int)(obj.GlobalPosition.X - sprObj.Origin.X) + x;
                    int objy = intersect.Y - (int)(obj.GlobalPosition.Y - sprObj.Origin.Y) + y;
                    if (HitboxSprite.GetPixelColor(thisx, thisy).A != 0
                        && sprObj.Sprite.GetPixelColor(objx, objy).A != 0)
                    {
                        return true;
                    }
                }
        }
        return false;
    }
    }
