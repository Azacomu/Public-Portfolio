﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


class Digger :GeneralEnemy
{

    //initiates all the rangeddigger needed for the exploding enemy, based on the currentfloor it adjusts the current damage, health
    //and dropstrength, the velocity is set to what is given in the constructor
    //based on the currentfloor strength, damage and dropstrength is given
    public Digger(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("digger",1)
    {
        this.LoadAnimation("diggerAttackFront", "attackFront", false, 0.1f);
        this.LoadAnimation("diggerMoveUp", "MovingUp", true, 0.1f);
        this.LoadAnimation("diggerMoveRight", "MovingRight", true, 0.1f);
        this.LoadAnimation("diggerMoveDown", "MovingDown", true, 0.1f);
        this.PlayAnimation("attackFront");
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.position = startPosition;
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;

        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        attackTimer = 0.0f;

        if(GameData.CurrentFloor == 2)
        {
            damage = 3;
            health = 8;
            dropStrength = 80;
        }
        else
        {
            damage = 2;
            health = 8;
            dropStrength = 40;
        }

        this.MaxHealth = this.EnemyHealth;
        this.Solid = false;
        
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime); ;
        attackTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;

        if (attackTimer < 0f)
        {
            isAttacking = false;
            digging = true;
        }

        //if this isn't attacking it moves towards the player
        if (!isAttacking)
        {
            MoveToPlayer(startingVelocityX, startingVelocityY);
        }

        //this collides with the player and it isn't attacking
        //it attacks if the timer allows it, this deals damage 
        //if this isnt attacking and doesn't intersect with the player
        //the animations are updated
        if (this.CollidesWith(GameData.GetPlayer))
        {
            if (!isAttacking)
            {
                Attack();
                Velocity = Vector2.Zero;
            }

            if (attackTimer < 0f)
            {
                GameData.GetPlayer.DealDamage(damage);
                attackTimer = 2f;
            }
        }
        else if (!BoundingBox.Intersects(GameData.GetPlayer.BoundingBox) && !isAttacking && !knockBacked)
        {
            AnimationHelper();
            digging = true;
        }
    }

    //the digger pops up from the ground , while this animation is playing the velocity is set to zero
    protected override void Attack()
    {
        isAttacking = true;
        digging = false;
        PlayAnimation("attackFront");
        if (!animations["attackFront"].AnimationEnded)
        {
            Velocity = Vector2.Zero;
        }
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
    }

    //updates the animation based on the direction we are facing
    protected void AnimationHelper()
    {
        switch (direction)
        {
            case "right":
                PlayAnimation("MovingRight");
                animations["MovingRight"].Mirror = false;
                break;
            case "left":
                PlayAnimation("MovingRight");
                animations["MovingRight"].Mirror = true;
                break;
            case "up":
                PlayAnimation("MovingUp");
                break;
            case "down":
                PlayAnimation("MovingDown");
                break;
            default:
                break;
        }
    }

}

