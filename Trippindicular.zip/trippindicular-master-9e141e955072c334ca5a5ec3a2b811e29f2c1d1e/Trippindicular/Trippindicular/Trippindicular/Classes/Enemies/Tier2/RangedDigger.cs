﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class RangedDigger : GeneralEnemy
{
    SpriteGameObject attackCircle;
    GameObjectList projectiles;

    //initiates all the rangeddigger needed for the exploding enemy, based on the currentfloor it adjusts the current damage, health
    //and dropstrength, the velocity is set to what is given in the constructor
    //based on the currentfloor strength, damage and dropstrength is given
    //it initiates an attackcircle which is used to check if the ranged digger can attack or not
    public RangedDigger(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("rangeddigger", 1)
    {
        this.LoadAnimation("diggerAttackFront", "attackFront", false, 0.1f);
        this.LoadAnimation("diggerAttackBack", "attackDown", false, 0.1f);
        this.LoadAnimation("diggerAttackSide", "attackSide", false, 0.1f);
        this.LoadAnimation("diggerMoveUp", "MovingUp", true, 0.1f);
        this.LoadAnimation("diggerMoveRight", "MovingRight", true, 0.1f);
        this.LoadAnimation("diggerMoveDown", "MovingDown", true, 0.1f);
        this.PlayAnimation("attackFront");
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.position = startPosition;
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;

        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        attackTimer = 0.0f;

        if (GameData.CurrentFloor == 2)
        {
            damage = 2;
            health = 8;
            dropStrength = 50;
        }
        else
        {
            damage = 1;
            health = 6;
            dropStrength = 30;
        }

        this.MaxHealth = this.EnemyHealth;

        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;
        projectiles = new GameObjectList(0, "attackList");
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        // updates the projectilelist, the attackcircle and the timer
        projectiles.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;

        //if this isnt attacking it moves towards the player
        if (!isAttacking)
        {
            MoveToPlayer(startingVelocityX, startingVelocityY);
        }

        //sets the booleans based on the timer, and if the attacktimer is bigger than 0 it has no velocity
        if (attackTimer < 0f)
        {
            isAttacking = false;
            digging = true;
        }
        else if (attackTimer > 0f)
        {
            Velocity = Vector2.Zero;
        }

        //if the attackcircle collides with the player
        //the proper animation gets player and if the timer allows it
        //it attacks
        if (attackCircle.CollidesWith(GameData.GetPlayer))
        {
            Velocity = Vector2.Zero;
            AnimationHelperAttack();
            if (attackTimer < 0f)
            {
                Attack();
            }
            
        }
        else if(!attackCircle.CollidesWith(GameData.GetPlayer)&& !isAttacking && !knockBacked)
        {
            AnimationHelper();
            digging = true;
        }

        ProjectileUpdate();

    }

    //creates a new spritegameobject with the right sprite, the position is set based on the enemys'current position
    //the velocity is set, and added to the projectile list, updates the isattacking boolean
    protected override void Attack()
    {
        if(!AnimationEnded)
        {
            Velocity = Vector2.Zero;
        }
        attackTimer = 2f;
        digging = false;
        SpriteGameObject simpleAttack = new SpriteGameObject("mudBall", 0, "simpleAttack", 0);
        simpleAttack.Position = new Vector2(this.position.X, this.position.Y - this.Height/2);
        simpleAttack.Origin = new Vector2(simpleAttack.Width / 2, simpleAttack.Height / 2);
        Vector2 difference = GameData.GetPlayer.Position - this.Position;
        difference.Normalize();
        difference *= 600;
        simpleAttack.Velocity = difference;
        projectiles.Add(simpleAttack);
        GameWorld.AssetLoader.PlaySound("knockbackscroll");
        isAttacking = true;
    }

    //loops through the projectile list and checks if the player uses an shield it plays a sound and removes the attack
    //if it collides with the player it deals damage and removes the attack
    //if the attack collides with a solidobject that isn't a water tile it get's removed
    protected void ProjectileUpdate()
    {
        for (int i = 0; i < projectiles.Objects.Count; i++)
        {
            SpriteGameObject attack = projectiles.Objects[i] as SpriteGameObject;
            if (GameData.GetPlayer.Inventory.GetItem(1) is StartingShield)
            {
                StartingShield sshield = GameData.GetPlayer.Inventory.GetItem(1) as StartingShield;
                if (sshield.HitBox.Intersects(attack.BoundingBox) && sshield.IsUsingShield)
                {
                    projectiles.Remove(projectiles.Objects[i]);
                    GameWorld.AssetLoader.PlaySound("arrowHitShield");
                }
            }
            if (attack.CollidesWith(GameData.GetPlayer))
            {
                GameData.GetPlayer.DealDamage(damage);
                projectiles.Remove(projectiles.Objects[i]);
            }
            for (int x = GameWorld.SolidObjects.Count - 1; x > 0; x--)
            {
                GameObject obj = GameWorld.SolidObjects[x];
                if (attack.CollidesWith(obj) && obj.ID == "wall")
                {
                    projectiles.Remove(attack);
                }
            }
        }
    }

    //updates the animation based on the current direction
    protected void AnimationHelper()
    {
        switch (direction)
        {
            case "right":
                PlayAnimation("MovingRight");
                animations["MovingRight"].Mirror = false;
                break;
            case "left":
                PlayAnimation("MovingRight");
                animations["MovingRight"].Mirror = true;
                break;
            case "up":
                PlayAnimation("MovingUp");
                break;
            case "down":
                PlayAnimation("MovingDown");
                break;
            default:
                break;
        }
    }

    //based on the direction its facing it plays the proper attack animation
    protected void AnimationHelperAttack()
    {
        switch (direction)
        {
            case "right":
                PlayAnimation("attackSide");
                animations["attackSide"].Mirror = false;
                break;
            case "left":
                PlayAnimation("attackSide");
                animations["attackSide"].Mirror = true;
                break;
            case "up":
                PlayAnimation("attackDown");
                break;
            case "down":
                PlayAnimation("attackFront");
                break;
            default:
                break;
        }
    }

    // property that checks if the animations are finished
    protected bool AnimationEnded
    {
        get
        {
            if (animations["attackSide"].AnimationEnded)
                return true;
            if (animations["attackDown"].AnimationEnded)
                return true;
            if (animations["attackFront"].AnimationEnded)
                return true;
            else return false;
        }

    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        attackCircle.Draw(gameTime, spriteBatch);
        projectiles.Draw(gameTime, spriteBatch);
    }


}

