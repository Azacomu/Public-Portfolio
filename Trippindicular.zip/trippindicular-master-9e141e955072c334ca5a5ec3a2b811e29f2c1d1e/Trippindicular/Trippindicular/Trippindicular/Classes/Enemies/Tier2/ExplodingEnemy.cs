﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class ExplodingEnemy :GeneralEnemy
{

    //initiates all the animations needed for the exploding enemy, based on the currentfloor it adjusts the current damage, health
    //and dropstrength, the velocity is set to what is given in the constructor
    public ExplodingEnemy(Vector2 startPosition, float HorizontalWalkingSpeed, float VerticalWalkingSpeed) :base("placeholder",1)
    {
        this.LoadAnimation("explodingEnemyFront1", "explodingEnemyFront1", true, 0.1f);
        LoadAnimation("explodingEnemyFront2", "explodingEnemyFront2", true, 0.1f);
        LoadAnimation("explodingEnemyFront3", "explodingEnemyFront3", true, 0.1f);
        LoadAnimation("explodingEnemySide", "explodingEnemySide", true, 0.1f);
        LoadAnimation("explosion", "Explosion", false, 0.1f);
        this.PlayAnimation("explodingEnemyFront1");
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        this.position = startPosition;
        Position += Origin;
        this.velocity.X = HorizontalWalkingSpeed;
        this.velocity.Y = VerticalWalkingSpeed;
        startingVelocityX = HorizontalWalkingSpeed;
        startingVelocityY = VerticalWalkingSpeed;

        isAttacking = false;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;
        if(CurrentFloor == 2)
        {
            damage = 4;
            health = 1;
            dropStrength = 50;
        }
        else
        {
            damage = 3;
            health = 1;
            dropStrength = 150;
        }

        this.MaxHealth = this.EnemyHealth;
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        //if there is a solidcollision it moves towards the player around the solidobjects
        //otherwise it moves towards the player normally
        if (SolidColission && !isAttacking)
        {
            MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
            AnimationHelper();
        }
        else if(!isAttacking)
        {
            MoveToPlayer(startingVelocityX, startingVelocityY);
        }

        if (this.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox) && !isAttacking) 
        {
            Attack();
        }

        //if this doenst intersect with the player the animation gets updated
        if (!this.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox) && !isAttacking)
        {
            AnimationHelper();
        }

        // if the explosion animation ends this gets removed
        if (animations["Explosion"].AnimationEnded)
        {
            GameData.LevelObjects.Remove(this);
        }
    }

    // plays the animation "explosion" and deals damage against the player
    protected override void Attack()
    {
        isAttacking = true;
        PlayAnimation("Explosion");
        GameData.GetPlayer.DealDamage(damage);
        GameWorld.AssetLoader.PlaySound("explosionSFX");
    }

    //updates the animation based on the direction its facing
    protected void AnimationHelper()
    {
        switch (direction)
        {
            case "right":
                PlayAnimation("explodingEnemySide");
                animations["explodingEnemySide"].Mirror = false;
                break;
            case "left":
                PlayAnimation("explodingEnemySide");
                animations["explodingEnemySide"].Mirror = true;
                break;
            case "up":
                PlayAnimation("explodingEnemyFront3");
                animations["explodingEnemyFront3"].Mirror = false;
                break;
            case "down":
                PlayAnimation("explodingEnemyFront3");
                animations["explodingEnemyFront3"].Mirror = true;
                break;
            default:PlayAnimation("explodingEnemySide");
                break;
        }
    }

    protected override void KnockBack(GameTime gameTime)
    {
        this.Velocity = Vector2.Zero;
    }

    protected override void Die()
    {
        PlayAnimation("Explosion");
        isAttacking = true;
        if (animations["Explosion"].AnimationEnded)
        {
            GameData.EnemyKill();
            DropItem();
            GameData.LevelObjects.Remove(this);
        }
       
    }
}

