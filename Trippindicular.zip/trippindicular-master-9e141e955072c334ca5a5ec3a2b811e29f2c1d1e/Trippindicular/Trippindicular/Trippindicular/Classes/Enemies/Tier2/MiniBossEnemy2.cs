﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class is for the enemy at the end of the second floor for the player to defeat to get to the last floor.
/// His special attack is doing a rush attack and stunning the player.
/// </summary>

class MiniBossEnemy2 : GeneralEnemy
{
    Stopwatch swTimer;
    Stopwatch swPlayerFrTimer, swBossFrTimer;
    SpriteGameObject attackCircle;
    int specialDamage, knockBackRange;
    int specialTimer;
    int playerFreezeTime, bossFreezeTime;
    float tempSpeed;
    float specMultiplier;
    bool specialActive;
    bool frozen;

    public MiniBossEnemy2(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("MiniBoss2", 1)
    {
        LoadAnimation("miniBoss2Enemy", "MovingUp", false, 0.1f);
        PlayAnimation("MovingUp");

        hitboxSprite = new SpriteSheet("miniBoss2Enemy", 0);

        this.position = startPosition;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;


        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        //Stopwatch for basic attacks
        attackTimer = 0.0f;
        waitTime = 0.5f;

        //Stopwatch for special attack timer, freeze time player and boss
        swTimer = new Stopwatch();
        swTimer.Start();
        swPlayerFrTimer = new Stopwatch();
        swBossFrTimer = new Stopwatch();

        //Values for the special attack 
        specMultiplier = 3.0f;
        specialActive = false;
        specialTimer = 5;
        specialDamage = 1;
        bossFreezeTime = 500;
        playerFreezeTime = 700;
        Frozen = false;
        knockBackRange = 15;
      
        //Basic attack of the enemy
        damage = 3;
        health = 30;
        this.MaxHealth = this.EnemyHealth;
        DropStrength = 80;

        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;
    }

    //Updates the timers,attackcircle and swordposition
    public override void Update(GameTime gameTime)
    {
        //Load the correct music and give achievement if player killed the boss
        if (this.health <= 0)
        {
            GameWorld.AssetLoader.PlayMusic("floor3music");
            CheckAchievements();
            GameData.GetPlayer.Frozen = false;
        }

        base.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;

        //If amount of seconds for the special is elapsed, make the special attack active and multiply his velocity
        if (swTimer.Elapsed.Seconds > specialTimer && InLineOfSight && this.VelocityY == 0)
        {
            specialActive = true;
            Visible = false;
            swTimer.Reset();
            tempSpeed = this.VelocityX;
            VelocityX = tempSpeed * specMultiplier;
        }

        //Freeze the player if he is frozen(when the timer starts)
        if (swPlayerFrTimer.ElapsedMilliseconds > playerFreezeTime)
        {
            GameData.GetPlayer.Frozen = false;
            swPlayerFrTimer.Reset();
        }

        //Freeze the boss if he is frozen(when the timer starts)
        if(swBossFrTimer.ElapsedMilliseconds > bossFreezeTime)
        {
            Frozen = false;
            VelocityX = -tempSpeed;
            swBossFrTimer.Reset();
        }

        if (specialActive)
        {
            //If boss collides with the player it freezes player and boss, knocks them both back, deals damage,
            //stops the special attack en restarts timer.
            if (this.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox))
            {
                Frozen = true;
                if (tempSpeed < 0) PositionX += knockBackRange;
                if (tempSpeed > 0) PositionX -= knockBackRange;
                swBossFrTimer.Start();
                
                GameData.GetPlayer.Frozen = true;
                if (tempSpeed < 0) GameData.GetPlayer.PositionX -= knockBackRange;
                if (tempSpeed > 0) GameData.GetPlayer.PositionX += knockBackRange;
                swPlayerFrTimer.Start();
                GameData.GetPlayer.DealDamage(specialDamage);
                
                specialActive = false;
                Visible = true;
                GameWorld.AssetLoader.PlaySound("hithurt");
                swTimer.Start();

            }
            //If boss collides with a solid object it freezes the boss, knocks him back, deals damage,
            //stops the special attack en restarts timer. 
            for (int i = GameWorld.SolidObjects.Count - 1; i > 0; i--)
            {
                GameObject obj = GameWorld.SolidObjects[i];
                if (this.BoundingBox.Intersects(obj.BoundingBox) && !(obj is GeneralEnemy))
                {
                    Frozen = true;
                    if (tempSpeed < 0) PositionX += knockBackRange;
                    if (tempSpeed > 0) PositionX -= knockBackRange;
                    swBossFrTimer.Start();
                    
                    specialActive = false;
                    Visible = true;
                    GameWorld.AssetLoader.PlaySound("hithurt");
                    swTimer.Start();
                    break;
                }
            }
        }
        else
        {
            //If the boss isn't frozen move to player and attack the player
            if (!frozen)
            {
                isMovingToPlayer = true;
                if (SolidColission)
                {
                    MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
                }
                else MoveToPlayer(startingVelocityX, startingVelocityY);
                waitTime = 0.0f;
            }
        }        
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        Sprite.Draw(spriteBatch, Position, Origin);
        healthBar.Draw(gameTime, spriteBatch);
        DrawTesting.DrawHitbox(spriteBatch, BoundingBox, Color.Blue);
        DrawTesting.DrawHitbox(spriteBatch, attackCircle.BoundingBox, Color.Blue);
    }

    public bool Frozen
    {
        get { return frozen; }
        set { frozen = value; Velocity = Vector2.Zero; }
    }

    protected void CheckAchievements()
    {
        //Kill Bubbles.
        if (!(MainGame.AchievementController.GetFinished("Bubbles")))
        {
            MainGame.AchievementController.FinishAchievement("Bubbles");
        }
    }
}