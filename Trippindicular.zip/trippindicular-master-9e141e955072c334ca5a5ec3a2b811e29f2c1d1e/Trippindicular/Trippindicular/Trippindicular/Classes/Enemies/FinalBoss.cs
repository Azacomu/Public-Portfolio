﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class is for the Final Boss. You face him after killing the third Mini Boss.
/// His special attack is spawning enemies or rushing to you with a high velocity.
/// </summary>

class FinalBoss : GeneralEnemy
{
    Stopwatch swTimer;
    Stopwatch swPlayerFrTimer, swBossFrTimer;
    SpriteGameObject attackCircle;
    int specMultiplier, specialDamage, knockBackRange;
    int specialTimer;
    int playerFreezeTime, bossFreezeTime;
    int chooseSpecial;
    int amountEnemies;
    float tempSpeed;
    bool specialActive;
    bool frozen;

    public FinalBoss(Vector2 startPosition, float horizontalWalkingSpeed, float verticalWalkingSpeed) : base("FinalBoss", 1)
    {
        LoadAnimation("finalBossEnemy", "Idle", false, 0.1f);
        PlayAnimation("Idle");

        hitboxSprite = new SpriteSheet("finalBossEnemy", 0);

        this.position = startPosition;
        this.Origin = new Vector2(this.Width / 2, this.Height / 2);
        Position += Origin;
        this.velocity.X = horizontalWalkingSpeed;
        this.velocity.Y = verticalWalkingSpeed;

        startingVelocityX = horizontalWalkingSpeed;
        startingVelocityY = verticalWalkingSpeed;

        if (startingVelocityX == 0)
            startingVelocityX = startingVelocityY;
        if (startingVelocityY == 0)
            startingVelocityY = startingVelocityX;

        //Stopwatch for basic attacks
        attackTimer = 0.0f;
        waitTime = 0.5f;

        //Stopwatch for special attack timer, freeze time player and boss
        swTimer = new Stopwatch();
        swTimer.Start();
        swPlayerFrTimer = new Stopwatch();
        swBossFrTimer = new Stopwatch();

        //Values for the special attack
        chooseSpecial = 0;
        amountEnemies = 2;
        specMultiplier = 3;
        specialActive = false;
        specialTimer = 10;
        specialDamage = 1;
        bossFreezeTime = 500;
        playerFreezeTime = 700;
        Frozen = false;
        knockBackRange = 15;

        //Basic stats for the enemy
        damage = 3;
        health = 30;
        this.MaxHealth = this.EnemyHealth;

        attackCircle = new SpriteGameObject("attackCircle", 0, "attackRange", 0);
        attackCircle.Origin = new Vector2(attackCircle.Width / 2, attackCircle.Height / 2);
        attackCircle.Position = this.GlobalPosition;
        attackCircle.Velocity = this.Velocity;
        attackCircle.Visible = false;
    }

    // updates the timers,attackcircle and swordposition
    public override void Update(GameTime gameTime)
    {
        //If his health is below 0, give the player specific achievements, remove all other enemies and play finish music
        if (this.health <= 0)
        {
            GameWorld.AssetLoader.PlayMusic("finishedmusic");
            CheckAchievements();
            for (int i = GameData.LevelObjects.Objects.Count - 1; i > 0; i--)
            {
                GameObject obj = GameData.LevelObjects.Objects[i];
                if ((obj is GeneralEnemy) && !(obj is FinalBoss))
                {
                    GameData.LevelObjects.Remove(obj);
                }
            }
            GameData.GetPlayer.Frozen = false;
        }

        base.Update(gameTime);
        attackCircle.Update(gameTime);
        attackCircle.Position = this.GlobalPosition;

        //De-freeze the player if he is frozen (until the timer surpasses the given time)
        if (swPlayerFrTimer.ElapsedMilliseconds > playerFreezeTime)
        {
            GameData.GetPlayer.Frozen = false;
            swPlayerFrTimer.Reset();
        }

        //De-freeze the boss if he is frozen (until the timer surpasses the given time)
        if (swBossFrTimer.ElapsedMilliseconds > bossFreezeTime)
        {
            Frozen = false;
            VelocityX = -tempSpeed;
            swBossFrTimer.Reset();
        }

        //Choose the special attack when it's time for a special attack
        if (swTimer.Elapsed.Seconds > specialTimer)
        {
            if (maxEnemies()) chooseSpecial = 1;
            else chooseSpecial = R.Dice(2);
            tempSpeed = this.VelocityX;
            specialActive = true;
            swTimer.Reset();
        }

        //If the special attack chosen was 1, he will do his rush special attack
        if (chooseSpecial == 1 && specialActive)
        {
            //Multiply the boss his velocity and make him invulnerable
            if (InLineOfSight && this.VelocityY == 0)
            {
                Visible = false;
                VelocityX = tempSpeed * specMultiplier;
            }
            //If Final Boss hits the player, freeze and knock the player and the boss back, and deal damage
            if (this.BoundingBox.Intersects(GameData.GetPlayer.BoundingBox))
            {
                Frozen = true;
                if (tempSpeed < 0) PositionX += knockBackRange;
                if (tempSpeed > 0) PositionX -= knockBackRange;
                swBossFrTimer.Start();

                GameData.GetPlayer.Frozen = true;
                if (tempSpeed < 0) GameData.GetPlayer.PositionX -= knockBackRange;
                if (tempSpeed > 0) GameData.GetPlayer.PositionX += knockBackRange;
                swPlayerFrTimer.Start();
                GameData.GetPlayer.DealDamage(specialDamage);

                specialActive = false;
                Visible = true;
                GameWorld.AssetLoader.PlaySound("hithurt");
                swTimer.Start();
                }

            //if the boss hits a solid object knockback the boss and deal damage
            for (int i = GameWorld.SolidObjects.Count - 1; i > 0; i--)
            {
                GameObject obj = GameWorld.SolidObjects[i];
                if (this.BoundingBox.Intersects(obj.BoundingBox) && !(obj is GeneralEnemy))
                {
                    Frozen = true;
                    if (tempSpeed < 0) PositionX += knockBackRange;
                    if (tempSpeed > 0) PositionX -= knockBackRange;
                    swBossFrTimer.Start();

                    specialActive = false;
                    Visible = true;
                    GameWorld.AssetLoader.PlaySound("hithurt");
                    swTimer.Start();
                    break;
                }
            }
        }
        //If the special attack chosen was 2, he will do his spawn mini SplitEnemies special attack
        else if (chooseSpecial == 2 && specialActive)
        {
            specialActive = false;
            SplitEnemyMini enemy1 = new SplitEnemyMini(GameData.GetPlayer.Position, 100, 100, 1000);
            SplitEnemyMini enemy2 = new SplitEnemyMini(GameData.GetPlayer.Position, 100, 100, 2500);
            GameData.LevelObjects.Add(enemy1);
            GameData.LevelObjects.Add(enemy2);
            swTimer.Start();
        }
        else
        {
            //If the boss isn't frozen move to player and attack the player
            if (!frozen)
            {
                isMovingToPlayer = true;
                if (SolidColission)
                {
                    MoveToPlayerSpecial(startingVelocityX, startingVelocityY);
                }
                else MoveToPlayer(startingVelocityX, startingVelocityY);
                waitTime = 0.0f;
            }
        }
    }


    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        Sprite.Draw(spriteBatch, Position, Origin);
        healthBar.Draw(gameTime, spriteBatch);
        DrawTesting.DrawHitbox(spriteBatch, BoundingBox, Color.Blue);
        DrawTesting.DrawHitbox(spriteBatch, attackCircle.BoundingBox, Color.Blue);
    }

    public bool Frozen
    {
        get { return frozen; }
        set { frozen = value; Velocity = Vector2.Zero; }
    }

    protected void CheckAchievements()
    {
        //Finish the game by killing the final boss.
        if (!(MainGame.AchievementController.GetFinished("Finisher")))
        {
            MainGame.AchievementController.FinishAchievement("Finisher");
        }

        //Kill the final boss with a sword.
        if (GameData.GetPlayer.Inventory.GetItem(0) is Sword)
        {
            if (!(MainGame.AchievementController.GetFinished("SwordFighter")))
            {
                MainGame.AchievementController.FinishAchievement("SwordFighter");
            }
        }

        //Kill the final boss with a magical wand.
        if (GameData.GetPlayer.Inventory.GetItem(0) is StartingWand || GameData.GetPlayer.Inventory.GetItem(0) is SecondWand)
        {
            if (!(MainGame.AchievementController.GetFinished("Mage")))
            {
                MainGame.AchievementController.FinishAchievement("Mage");
            }
        }

        //Kill the final boss with a bow.
        if (GameData.GetPlayer.Inventory.GetItem(0) is Bow)
        {
            if (!(MainGame.AchievementController.GetFinished("Hunter")))
            {
                MainGame.AchievementController.FinishAchievement("Hunter");
            }
        }
    }

    //Checks how many enemies there are in the level
    protected bool maxEnemies()
    {
        int x = 0;
        for (int i = GameData.LevelObjects.Objects.Count - 1; i > 0; i--)
        {
            GameObject obj = GameData.LevelObjects.Objects[i];
            if ((obj is GeneralEnemy) && !(obj is FinalBoss))
            {
                x++;
            }
        }
        if (x >= amountEnemies) return true;
        else return false;
        
    }

    //Die method for the enemy, drops the sword to end the game
    protected override void Die()
    {
        GameData.EnemyKill();
        LegendarySword legendarySword = new LegendarySword();
        legendarySword.Position = this.GlobalPosition;
        GameData.LevelObjects.Add(legendarySword);
        GameData.LevelObjects.Remove(this);
    }
}