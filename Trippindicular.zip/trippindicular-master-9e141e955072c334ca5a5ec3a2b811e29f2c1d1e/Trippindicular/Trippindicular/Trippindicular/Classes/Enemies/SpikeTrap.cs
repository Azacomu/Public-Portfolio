﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class SpikeTrap : AnimatedGameObject
{
    int damage;
    int attackCounter;

    //initiates the animation and position
    public SpikeTrap(Vector2 startPosition) : base("placeholderEnemy",1)
    {
        this.LoadAnimation("spikeTrap", "Attack", true, 1f);
        this.PlayAnimation("Attack");
        this.position = startPosition;
        damage = 1;
        attackCounter = 0;
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        Attack();
    }

    //plays the animation, if the sheetindex is 1, which means that the spikes are showing
    //if the spikes collide with the player it deals damage 1 time only
    //afterwards it resets the counter so it can deal damage again
    protected void Attack()
    {
        this.PlayAnimation("Attack");
        if (animations["Attack"].SheetIndex == 1 && this.CollidesWith(GameData.GetPlayer))
        {
            if (attackCounter < 1)
            {
                GameData.GetPlayer.DealDamage(damage);
                attackCounter++;
            }
        }
        else attackCounter = 0;
    }

}


