﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


public class Room : SpriteGameObject
{
    public bool north;
    public bool east;
    public bool south;
    public bool west;
    public bool bossKey;
    bool monsterDoors;

    int enemies = 0;

    public string roomType;
    public string tag;
    string roomNumber;
    string path = "Content/Levels/";

    public GameObjectList tileList;
    public GameObjectList objectList;
    public GameObjectList backgroundList;

    public Point point;

    public LevelLoader loader;

    public Room(bool northD, bool eastD, bool southD, bool westD, string assetName, int sheetIndex, string id = "", int layer = 0) : base("room", 1, id, layer)
    {
        monsterDoors = true;
        north = northD;
        east = eastD;
        south = southD;
        west = westD;
        visible = true;
        loader = new LevelLoader();
        tileList = new GameObjectList(-1, "TileList"); //Added ID to find it in the LevelObject list
        backgroundList = new GameObjectList(-1, "backgroundList");
        objectList = new GameObjectList();
    }

    public int X
    {
        get { return point.X; }
    }

    public int Y
    {
        get { return point.Y; }
    }
    //LoadNewRoom determines a string for the current room by checking the rooms on all sides. Then, using this string, it builds a room from scratch.
    public virtual void LoadNewRoom()
    {
        roomNumber = "";

        if (this.point == new Point(5, 5))
        {
            tag = "start";
            roomNumber += "Start";
            if (GameData.CurrentFloor == 0)//The startingroom on the first floor should have startingitems and a tutorial
            {
                Items sword = new StartingSword();
                sword.Position = new Vector2(14 * tileWidth + GameSettings.GameFieldOffset, 11 * tileHeight + GameSettings.GameFieldOffset);
                GameData.LevelObjects.Add(sword);
                Items wand = new StartingWand();
                wand.Position = new Vector2(11 * tileWidth + GameSettings.GameFieldOffset, 11 * tileHeight + GameSettings.GameFieldOffset);
                GameData.LevelObjects.Add(wand);
                Items bow = new WoodenBow();
                bow.Position = new Vector2(17 * tileWidth + GameSettings.GameFieldOffset, 11 * tileHeight + GameSettings.GameFieldOffset);
                GameData.LevelObjects.Add(bow);

                SpriteGameObject tutorial = new SpriteGameObject("tutorialc", layer: 1);
                tutorial.Scale = 2;
                tutorial.Position = new Vector2(10 * tileWidth - tutorial.Width, 5 * tileHeight);
                GameData.LevelObjects.Add(tutorial);

                SpriteGameObject tutorial2 = new SpriteGameObject("tutorialk", layer: 1);
                tutorial2.Scale = 2;
                tutorial2.Position = new Vector2(20 * tileWidth - tutorial2.Width, 5 * tileHeight);
                GameData.LevelObjects.Add(tutorial2);

                SpriteGameObject treasureChest = new TreasureChest();
                treasureChest.Position = new Vector2(14 * tileWidth, 9 * tileHeight);
                GameData.LevelObjects.Add(treasureChest);
            }


        }
        else if (this is PuzzleRoomSimon)
        {
            roomNumber += "Puzzle";
            tag = "puzzle";

        }
        else if (roomType == "treasure")
        {
            roomNumber += "Treasure";
            tag = "treasure";
        }
        else if (roomType == "finalBoss")
        {
            roomNumber += "Start";
            FinalBoss finalBoss = new FinalBoss(new Vector2(15 * GameSettings.TileWidth, 7 * GameSettings.TileHeight), 100, 0);
            GameData.LevelObjects.Add(finalBoss);
        }
        else
        {
            roomNumber += R.Dice(5);
            tag = "monster";
        }

        string doors = "";
        if (north)
            doors += "N";
        if (east)
            doors += "E";
        if (south)
            doors += "S";
        if (west)
            doors += "W";

        loader.BuildGround(backgroundList);//Build the backgroundtile list.

        switch (doors)
        {
            case "NESW":
                LoadFourDoors();
                break;
            case "NES":
                LoadThreeDoorsUpDown(true);
                break;
            case "NSW":
                LoadThreeDoorsUpDown(false);
                break;
            case "NEW":
                LoadThreeDoorsLeftRight(false);
                break;
            case "ESW":
                LoadThreeDoorsLeftRight(true);
                break;
            case "NE":
                LoadCorner(false, true);
                break;
            case "ES":
                LoadCorner(true, true);
                break;
            case "SW":
                LoadCorner(true, false);
                break;
            case "NW":
                LoadCorner(false, false);
                break;
            case "NS":
                LoadUpDown();
                break;
            case "EW":
                LoadLeftRight();
                break;
            case "N":
                LoadUp(false);
                break;
            case "E":
                LoadSide(true);
                break;
            case "S":
                LoadUp(true);
                break;
            case "W":
                LoadSide(false);
                break;
            default:
                break;
        }
        //Added: After loading the tileList, replace the old list in the LevelObjects list
        AddToLevelObjects();
        if (FloorBuilder.CurrentRoom is PuzzleRoomSimon)
            loader.MakePuzzleDoor();
    }

    //Each type of room has a small amount of rooms, which are randomly generated.
    void LoadFourDoors()
    {
        tileList = loader.Loadlevel(path+"FourDoorLevels/Four"+roomNumber+".txt", false, false, tag);
        GameData.RoomPaths.Add(path + "FourDoorLevels/Four" + roomNumber + ".txt");
        GameData.RoomsMirroredX.Add(false);
        GameData.RoomsMirroredY.Add(false);
    }

    void LoadThreeDoorsUpDown(bool mirror) {
        tileList = loader.Loadlevel(path + "ThreeDoorLevels/UpDownLeft/UpDownLeft" +roomNumber+".txt", false, mirror, tag);
        GameData.RoomPaths.Add(path + "ThreeDoorLevels/UpDownLeft/UpDownLeft" + roomNumber + ".txt");
        GameData.RoomsMirroredX.Add(false);
        GameData.RoomsMirroredY.Add(mirror);
    }

    void LoadThreeDoorsLeftRight(bool mirror)
    {
        tileList = loader.Loadlevel(path + "ThreeDoorLevels/LeftRightUp/LeftRightUp" +roomNumber+".txt", mirror, false, tag);
        GameData.RoomPaths.Add(path + "ThreeDoorLevels/LeftRightUp/LeftRightUp" + roomNumber + ".txt");
        GameData.RoomsMirroredX.Add(mirror);
        GameData.RoomsMirroredY.Add(false);
    }

    void LoadCorner(bool xMirror, bool yMirror)
    {
        tileList = loader.Loadlevel(path + "TwoDoorLevels/Corner/Corner" + roomNumber +".txt", xMirror, yMirror, tag);
        GameData.RoomPaths.Add(path + "TwoDoorLevels/Corner/Corner" + roomNumber + ".txt");
        GameData.RoomsMirroredX.Add(xMirror);
        GameData.RoomsMirroredY.Add(yMirror);
    }

    void LoadUpDown()
    {
        if (roomType == "boss")
        {
            tileList = loader.Loadlevel(path + "OneDoorLevels/BossRoom/BossUp.txt", false, false, tag);
            GameData.RoomPaths.Add(path + "OneDoorLevels/BossRoom/BossUp.txt");
        }
        else
        {
            tileList = loader.Loadlevel(path + "TwoDoorLevels/UpDown/UpDown" + roomNumber + ".txt", false, false, tag);
            GameData.RoomPaths.Add(path + "TwoDoorLevels/UpDown/UpDown" + roomNumber + ".txt");
        }
        GameData.RoomsMirroredX.Add(false);
        GameData.RoomsMirroredY.Add(false);
    }

    void LoadLeftRight()
    {
        tileList = loader.Loadlevel(path + "TwoDoorLevels/LeftRight/LeftRight" + roomNumber + ".txt", false, false, tag);
        GameData.RoomPaths.Add(path + "TwoDoorLevels/LeftRight/LeftRight" + roomNumber + ".txt");
        GameData.RoomsMirroredX.Add(false);
        GameData.RoomsMirroredY.Add(false);
    }

    void LoadUp(bool mirror)
    {
        switch (roomType)
        {
            case "boss":
                GameWorld.AssetLoader.PlayMusic("bossmusic");
                tileList = loader.Loadlevel(path + "OneDoorLevels/BossRoom/BossUp.txt", mirror, false, tag);
                GameData.RoomPaths.Add(path + "OneDoorLevels/BossRoom/BossUp.txt");
                break;
            case "item":
                tileList = loader.Loadlevel(path + "OneDoorLevels/ItemRoom/ItemRoomUp.txt", mirror, false, tag);
                GameData.RoomPaths.Add(path + "OneDoorLevels/ItemRoom/ItemRoomUp.txt");
                break;
            case "shop":
                tileList = loader.Loadlevel(path + "OneDoorLevels/ShopRoom/ShopUp.txt", mirror, false, tag);
                GameData.RoomPaths.Add(path + "OneDoorLevels/ShopRoom/ShopUp.txt");
                break;
            default:
                tileList = loader.Loadlevel(path + "OneDoorLevels/Up/Up" + roomNumber + ".txt", mirror, false, tag);
                GameData.RoomPaths.Add(path + "OneDoorLevels/Up/Up" + roomNumber + ".txt");
                break;
        }
        GameData.RoomsMirroredX.Add(mirror);
        GameData.RoomsMirroredY.Add(false);
    }

    void LoadSide(bool mirror)
    {
        if (roomType == "item")
        {
            tileList = loader.Loadlevel(path + "OneDoorLevels/ItemRoom/ItemRoomLeft.txt", false, mirror, tag);
            GameData.RoomPaths.Add(path + "OneDoorLevels/ItemRoom/ItemRoomLeft.txt");

        }
        else if (roomType == "shop")
        {
            tileList = loader.Loadlevel(path + "OneDoorLevels/ShopRoom/ShopLeft.txt", false, mirror, tag);
            GameData.RoomPaths.Add(path + "OneDoorLevels/ShopRoom/ShopLeft.txt");
        }
        else
        {
            tileList = loader.Loadlevel(path + "OneDoorLevels/Left/Left" + roomNumber + ".txt", false, mirror, tag);
            GameData.RoomPaths.Add(path + "OneDoorLevels/Left/Left" + roomNumber + ".txt");
        }
        GameData.RoomsMirroredY.Add(mirror);
        GameData.RoomsMirroredX.Add(false);
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        enemies = CountEnemies();

        if (monsterDoors && enemies == 0)
            DestroyMonsterDoors();

        CheckDoors();
    }

    //Check if there are any enemies left, and if not, delete all monsterdoors.
    //If a keydoortile is touched, and there is a key in your inventory, open the keydoor
    public void CheckDoors()
    {
        if (GameData.GetPlayer.Inventory.GetKeys > 0 && enemies == 0)
        {
            for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
            {
                if (GameData.LevelObjects.Objects[i].ID == "doortile" && GameData.GetPlayer.CollidesWith(GameData.LevelObjects.Objects[i]))
                {
                    GameData.GetPlayer.Inventory.GetKeys--;
                    GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
                    int a = 0;
                    while (!(GameData.LevelObjects.Objects[a] is KeyDoor) && a < GameData.LevelObjects.Objects.Count - 1)
                        a++;
                        
                    if (GameData.LevelObjects.Objects[a] is KeyDoor)
                        GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[a]);
                }
            }
        }
    }

    //Find all monsterdoors and remove them.
    public void DestroyMonsterDoors()
    {
        monsterDoors = false;
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (GameData.LevelObjects.Objects[i] is MonsterDoor)
                GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
        }
    }

    //Count the enemies. This is used to check if there are any left.
    public int CountEnemies()
    {
        int enemycount = 0;
        for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
        {
            if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
                enemycount++;
        }
        return enemycount;
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        tileList.Draw(gameTime, spriteBatch);
    }

    //Add to GameData.LevelObjects method
    public void AddToLevelObjects()
    {
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (GameData.LevelObjects.Objects[i].ID == "TileList" || GameData.LevelObjects.Objects[i].ID == "backgroundList")
                GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
        }
        GameData.LevelObjects.Add(tileList);
        GameData.LevelObjects.Add(backgroundList);
    }
}
