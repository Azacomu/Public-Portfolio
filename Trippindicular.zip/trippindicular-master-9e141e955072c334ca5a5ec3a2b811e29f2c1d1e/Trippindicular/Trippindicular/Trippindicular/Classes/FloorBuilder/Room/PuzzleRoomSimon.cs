﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

class PuzzleRoomSimon : Room
{
    PressurePlate redPlate;
    PressurePlate bluePlate;
    PressurePlate greenPlate;
    PressurePlate yellowPlate;

    PressurePlate currentFlash;

    PressurePlate startPlate;

    List<PressurePlate> plateList;

    string sequence;
    string playerSeq;
    string phase;

    int seqCounter;

    bool touching;

    // 1 = Rood, 2 = Blauw, 3 = Groen, 4 = Geel
    public PuzzleRoomSimon(bool northD, bool eastD, bool southD, bool westD, string assetName, int sheetIndex, string id = "", int layer = 0)
        : base(true, true, true, true, "puzzleroom", 1, id, layer)
    {
        north = northD;
        east = eastD;
        south = southD;
        west = westD;
        sequence = "";
        seqCounter = 0;
        for (int i = 0; i < 2; i++)
        {
            sequence += R.Dice(4);
        }

        currentFlash = new PressurePlate("redplate", 0);

        plateList = new List<PressurePlate>();
        playerSeq = "";

    }

    public override void LoadNewRoom()
    {
        base.LoadNewRoom();

        startPlate = new PressurePlate("redplate", 1, layer: 1, id: "pressureplate");
        startPlate.Position = new Vector2(926, 448);
        GameData.LevelObjects.Add(startPlate);
        redPlate = new PressurePlate("redplate", 1, layer:1, id: "pressureplate");
        redPlate.Position = new Vector2(726, 248);
        GameData.LevelObjects.Add(redPlate);
        bluePlate = new PressurePlate("blueplate", 1, layer: 1, id: "pressureplate");
        bluePlate.Position = new Vector2(1126, 248);
        GameData.LevelObjects.Add(bluePlate);
        greenPlate = new PressurePlate("greenplate", 1, layer: 1, id: "pressureplate");
        greenPlate.Position = new Vector2(726, 648);
        GameData.LevelObjects.Add(greenPlate);
        yellowPlate = new PressurePlate("yellowplate", 1, layer: 1, id: "pressureplate");
        yellowPlate.Position = new Vector2(1126, 648);
        GameData.LevelObjects.Add(yellowPlate);

        plateList.Add(redPlate);
        plateList.Add(bluePlate);
        plateList.Add(greenPlate);
        plateList.Add(yellowPlate);
    }


    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        if (GameData.GetPlayer.CollidesWith(startPlate) && phase != "do" && phase != "clear")
        {
            bool clear = true;
            foreach (GameObject obj in GameData.LevelObjects.Objects)
            {
                if (obj is GeneralEnemy)
                    clear = false;
            }
            if (clear)
                phase = "show";
        }

        switch (phase)
        {
            case "show":
                ShowSequence();
                break;
            case "do":
                MakePlayerSequence();
                break;
            case "clear":
                foreach (PressurePlate plate in plateList)
                    plate.Flash();
                for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
                {
                    if (GameData.LevelObjects.Objects[i] is PuzzleDoor)
                        GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
                }
                break;
            default:
                break;
        }

    }

    void MakePlayerSequence()
    {
        if (playerSeq.Length == sequence.Length)
        {
            TurnOffAll();
            if (playerSeq == sequence)
            {
                if (sequence.Length < 6)
                {
                    playerSeq = "";
                    sequence += R.Dice(4);
                    phase = "show";
                }
                else
                {
                    foreach (PressurePlate plate in plateList)
                        plate.Flash();
                    phase = "clear";
                    return;
                }
            }
            else
            {
                FEMelee FEMelee = new FEMelee(new Vector2(946, 512), 0, 100);
                GameData.LevelObjects.Add(FEMelee);
                phase = "";
                playerSeq = "";
            }
        }

        if (GameData.GetPlayer.CollidesWith(redPlate) && !touching)
        {
            playerSeq += 1;
            touching = true;
        }
        else if (GameData.GetPlayer.CollidesWith(bluePlate) && !touching)
        {
            playerSeq += 2;
            touching = true;
        }
        else if (GameData.GetPlayer.CollidesWith(greenPlate) && !touching)
        {
            playerSeq += 3;
            touching = true;
        }
        else if (GameData.GetPlayer.CollidesWith(yellowPlate) && !touching)
        {
            playerSeq += 4;
            touching = true;
        }

        if (touching)
            touching = IsTouchingPlate();
    }

    bool IsTouchingPlate()
    {
        foreach (PressurePlate plate in plateList)
        {
            if (GameData.GetPlayer.CollidesWith(plate))
            {
                plate.Flash();
                return true;
            }
            else
                plate.TurnOff();
        }
        return false;
    }

    void TurnOffAll()
    {
        foreach (PressurePlate plate in plateList)
            plate.TurnOff();
    }

    void ShowSequence()
    {
        TurnOffAll();

        if (seqCounter == sequence.Length * 100)
        {
            foreach (PressurePlate plate in plateList)
                plate.TurnOff();
            phase = "do";
            seqCounter = 0;
        }
        else if (seqCounter <= sequence.Length * 100 - 1)
        {
            int currentFlashing = int.Parse(sequence[seqCounter / 100].ToString());
            switch (currentFlashing)
            {
                case 1:
                    currentFlash = redPlate;
                    break;
                case 2:
                    currentFlash = bluePlate;
                    break;
                case 3:
                    currentFlash = greenPlate;
                    break;
                case 4:
                    currentFlash = yellowPlate;
                    break;
                default:
                    break;
            }

            if (seqCounter % 100 < 80 && seqCounter % 100 > 10)
                currentFlash.Flash();
            else
                currentFlash.TurnOff();

            seqCounter++;
        }
    }

    public string BonusRoomDirection(Point point)
    {
        string dir = "";
        if (!FloorBuilder.allRoomsList.Contains(new Point(point.X + 1, point.Y)))
            dir = "east";
        else if (!FloorBuilder.allRoomsList.Contains(new Point(point.X - 1, point.Y)))
            dir = "west";
        else if (!FloorBuilder.allRoomsList.Contains(new Point(point.X, point.Y + 1)))
            dir = "south";
        else if (!FloorBuilder.allRoomsList.Contains(new Point(point.X, point.Y - 1)))
            dir = "north";
        return dir;
    }
}
