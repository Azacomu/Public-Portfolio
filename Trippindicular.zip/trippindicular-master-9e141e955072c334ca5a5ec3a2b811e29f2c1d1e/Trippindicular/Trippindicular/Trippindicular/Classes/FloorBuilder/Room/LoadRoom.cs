﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Text;

public partial class Room : SpriteGameObject
{
    string path = "../../../../../GentleJellyfishGamesLibary/GentleJellyfishGamesLibaryContent/Levels/";

    public string tag;
    string roomNumber;

    public virtual void LoadNewRoom()
    {
        roomNumber = "";

        if (this.point == new Point(5, 5))
        {
            tag = "start";
            roomNumber += "Start";
            if (GameData.CurrentFloor == 0)
            {
                Items sword = new StartingSword();
                sword.Position = new Vector2(928, 736);
                GameData.LevelObjects.Add(sword);
                Items wand = new StartingWand();
                wand.Position = new Vector2(736, 736);
                GameData.LevelObjects.Add(wand);
                Items bow = new WoodenBow();
                bow.Position = new Vector2(1120, 736);
                GameData.LevelObjects.Add(bow);
            }
        }
        else if (this is PuzzleRoomSimon)
        {
            roomNumber += "Start";
            tag = "puzzle";

        }
        else if (roomType == "treasure")
        {
            roomNumber += "Start";
            tag = "treasure";
            Items item = DropTable.DetermineStrongItem();
            item.Position = new Vector2(800, 500);
            GameData.LevelObjects.Add(item);
        }
        else
        {
            roomNumber += R.Dice(3);
            tag = "monster";
        }

        if (roomType == "critical" && !FloorBuilder.bossKey)
        {
            Items bossKey = new Items("bosskey", "key", 0, "bosskey");
            bossKey.Position = new Vector2(400, 400);
            GameData.LevelObjects.Add(bossKey);
            FloorBuilder.bossKey = true;
        }

        string doors = "";
        if (north)
            doors += "N";
        if (east)
            doors += "E";
        if (south)
            doors += "S";
        if (west)
            doors += "W";

        switch (doors)
        {
            case "NESW":
                LoadFourDoors();
                break;
            case "NES":
                LoadThreeDoorsUpDown(true);
                break;
            case "NSW":
                LoadThreeDoorsUpDown(false);
                break;
            case "NEW":
                LoadThreeDoorsLeftRight(false);
                break;
            case "ESW":
                LoadThreeDoorsLeftRight(true);
                break;
            case "NE":
                LoadCorner(false, true);
                break;
            case "ES":
                LoadCorner(true, true);
                break;
            case "SW":
                LoadCorner(true, false);
                break;
            case "NW":
                LoadCorner(false, false);
                break;
            case "NS":
                LoadUpDown();
                break;
            case "EW":
                LoadLeftRight();
                break;
            case "N":
                LoadUp(false);
                break;
            case "E":
                LoadSide(true);
                break;
            case "S":
                LoadUp(true);
                break;
            case "W":
                LoadSide(false);
                break;
            default:
                Console.WriteLine("Level not found! " + doors);
                break;
        }
        //Added: After loading the tileList, replace the old list in the LevelObjects list
        AddToLevelObjects();
        if (FloorBuilder.CurrentRoom is PuzzleRoomSimon)
            loader.MakePuzzleDoor();
    }

    void LoadFourDoors()
    {
        tileList = loader.Loadlevel(path + "FourDoorLevels/Four" + roomNumber + ".txt", false, false, tag);
    }

    void LoadThreeDoorsUpDown(bool mirror)
    {
        tileList = loader.Loadlevel(path + "ThreeDoorLevels/UpDownLeft/UpDownLeft" + roomNumber + ".txt", false, mirror, tag);
    }

    void LoadThreeDoorsLeftRight(bool mirror)
    {
        tileList = loader.Loadlevel(path + "ThreeDoorLevels/LeftRightUp/LeftRightUp" + roomNumber + ".txt", mirror, false, tag);
    }

    void LoadCorner(bool xMirror, bool yMirror)
    {
        tileList = loader.Loadlevel(path + "TwoDoorLevels/Corner/Corner" + roomNumber + ".txt", xMirror, yMirror, tag);
    }

    void LoadUpDown()
    {
        if (roomType == "boss")
            tileList = loader.Loadlevel(path + "OneDoorLevels/BossRoom/BossUp.txt", false, false, tag);
        else
            tileList = loader.Loadlevel(path + "TwoDoorLevels/UpDown/UpDown" + roomNumber + ".txt", false, false, tag);
    }

    void LoadLeftRight()
    {
        tileList = loader.Loadlevel(path + "TwoDoorLevels/LeftRight/LeftRight" + roomNumber + ".txt", false, false, tag);
    }

    void LoadUp(bool mirror)
    {
        switch (roomType)
        {
            case "boss":
                tileList = loader.Loadlevel(path + "OneDoorLevels/BossRoom/BossUp.txt", mirror, false, tag);
                break;
            case "item":
                tileList = loader.Loadlevel(path + "OneDoorLevels/ItemRoom/ItemRoomUp.txt", mirror, false, tag);
                break;
            case "shop":
                tileList = loader.Loadlevel(path + "OneDoorLevels/ShopRoom/ShopUp.txt", mirror, false, tag);
                break;
            default:
                tileList = loader.Loadlevel(path + "OneDoorLevels/Up/Up" + roomNumber + ".txt", mirror, false, tag);
                break;
        }
    }

    void LoadSide(bool mirror)
    {
        if (roomType == "item")
            tileList = loader.Loadlevel(path + "OneDoorLevels/ItemRoom/ItemRoomLeft.txt", false, mirror, tag);
        else if (roomType == "shop")
            tileList = loader.Loadlevel(path + "OneDoorLevels/ShopRoom/ShopLeft.txt", false, mirror, tag);
        else
            tileList = loader.Loadlevel(path + "OneDoorLevels/Left/Left" + roomNumber + ".txt", false, mirror, tag);
    }
}
