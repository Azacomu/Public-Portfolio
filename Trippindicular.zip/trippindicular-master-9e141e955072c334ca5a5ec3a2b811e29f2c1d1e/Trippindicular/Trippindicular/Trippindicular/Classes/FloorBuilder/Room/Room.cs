﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


public partial class Room : SpriteGameObject
{
    public bool north;
    public bool east;
    public bool south;
    public bool west;
    bool monsterDoors;

    int enemies = 0;

    public string roomType;


    public GameObjectList tileList;
    public GameObjectList objectList;

    public Point point;

    LevelLoader loader;

    public Room(bool northD, bool eastD, bool southD, bool westD, string assetName, int sheetIndex, string id = "", int layer = 0) : base("room", 1, id, layer)
    {
        monsterDoors = true;
        north = northD;
        east = eastD;
        south = southD;
        west = westD;
        visible = true;
        loader = new LevelLoader();
        tileList = new GameObjectList(-1, "TileList"); //Added ID to find it in the LevelObject list
        objectList = new GameObjectList();
    }

    public int X
    {
        get { return point.X; }
    }

    public int Y
    {
        get { return point.Y; }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        enemies = CountEnemies();

        if(monsterDoors && enemies == 0)
            DestroyMonsterDoors();

        CheckDoors();
    }

    public void CheckDoors()
    {
        if (GameData.GetPlayer.Inventory.GetKeys > 0 && enemies == 0)
        {
            for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
            {
                if (GameData.LevelObjects.Objects[i].Id == "doortile" && GameData.GetPlayer.CollidesWith(GameData.LevelObjects.Objects[i]))
                {
                    GameData.GetPlayer.Inventory.GetKeys--;
                    GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
                    for (int a = 0; a < GameData.LevelObjects.Objects.Count; a++)
                    {
                        if (GameData.LevelObjects.Objects[a] is KeyDoor)
                        {
                            GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[a]);
                            break;
                        }

                    }
                }
            }
        }
    }

    public void DestroyMonsterDoors()
    {
        monsterDoors = false;
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (GameData.LevelObjects.Objects[i] is MonsterDoor)
                GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
        }
    }

    public int CountEnemies()
    {
        int enemycount = 0;
        for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
        {
            if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
                enemycount++;
        }
        return enemycount;
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        tileList.Draw(gameTime, spriteBatch);
    }

    //Add to GameData.LevelObjects method
    public void AddToLevelObjects()
    {
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (GameData.LevelObjects.Objects[i].ID == "TileList")
                GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
        }
        GameData.LevelObjects.Add(tileList);
    }
}
