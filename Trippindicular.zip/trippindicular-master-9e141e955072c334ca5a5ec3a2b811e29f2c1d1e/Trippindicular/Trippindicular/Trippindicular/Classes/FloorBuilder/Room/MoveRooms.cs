﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

public partial class FloorBuilder
{
    //Used to move between rooms.
    public void MoveRoom(Room oldRoom, string direction)
    {
        SaveOldRoom(oldRoom);

        switch (direction)
        {
            case "south":
                currentRoom = FindRoom(new Point(oldRoom.X, oldRoom.Y + 1));
                GameData.GetPlayer.PositionY = 128;//Gives the player a new position so it spawns on the other side.
                break;
            case "west":
                currentRoom = FindRoom(new Point(oldRoom.X - 1, oldRoom.Y));
                GameData.GetPlayer.PositionX = 1824;
                break;
            case "east":
                currentRoom = FindRoom(new Point(oldRoom.X + 1, oldRoom.Y));
                GameData.GetPlayer.PositionX = 96;
                break;
            case "north":
                currentRoom = FindRoom(new Point(oldRoom.X, oldRoom.Y - 1));
                GameData.GetPlayer.PositionY = 864;
                break;
            default:
                break;
        }
        //Reposition the currentroomindicator:
        currentRoomIndicator.Position = new Vector2(1300 + 40 * currentRoom.point.X, 300 + 25 * currentRoom.point.Y);

        //If the room hasn't been explored yet, load the level freshly
        if (!miniMapList.Objects.Contains(currentRoom))
        {
            AddToMiniMap(currentRoom);
            currentRoom.LoadNewRoom();
        }
        else//If the level is already in the minimap, load what was saved when you left it.
            LoadObjectsInRoom(currentRoom);
    }

    //This adds a room to the minimap.
    public void AddToMiniMap(Room currentRoom)
    {
        SpriteGameObject miniMapRoom = new SpriteGameObject("room", layer: 1, id: "minimap");
        miniMapRoom.Position = new Vector2(1300 + 40 * currentRoom.point.X, 300 + 25 * currentRoom.point.Y);
        miniMapRoom.Visible = true;
        miniMapRoom.Solid = false;
        miniMapList.Add(currentRoom);
        GameData.LevelObjects.Add(miniMapRoom);
    }


    public void SaveOldRoom(Room oldRoom)
    {//Save all items that are located in a room when you leave the room
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (!(GameData.LevelObjects.Objects[i] is Player) && !(GameData.LevelObjects.Objects[i].ID == "minimap"))
            {
                oldRoom.objectList.Add(GameData.LevelObjects.Objects[i]);
                GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
            }
        }
    }

    public void LoadObjectsInRoom(Room room)
    {//Load every item saved in the old room and place it back.
        for (int i = room.objectList.Objects.Count - 1; i >= 0; i--)
        {
            GameData.LevelObjects.Add(room.objectList.Objects[i]);
            room.objectList.Objects.Remove(room.objectList.Objects[i]);
        }
    }

    public static Room FindRoom(Point point)
    {//Try to find a room at a certain point.
        foreach (Room room in roomList.Objects)
        {
            if (room.point == point)
            {
                return room;
            }
        }
        return new Room(false, false, false, false, "room", 0);
    }
}
