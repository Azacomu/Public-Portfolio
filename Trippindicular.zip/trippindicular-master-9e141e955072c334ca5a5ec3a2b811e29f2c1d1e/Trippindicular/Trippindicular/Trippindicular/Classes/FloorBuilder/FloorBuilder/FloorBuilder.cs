﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Floorbuilder builds a floor with rooms, and manages the movement between these rooms.
public partial class FloorBuilder
{
    List<Point> criticalPathList;
    public static List<Point> allRoomsList;

    int critPathLength;
    int branchCount;
    int puzzleCount;
    public const int indicatorWidth = 40;
    public const int indicatorHeight = 25;

    static GameObjectList roomList;
    GameObjectList miniMapList;
    GameObjectList exploredRoomsList;

    //Points that keep track of the special rooms: Boss, shop, start, last room for doors in the bossroom, and the furthestroom
    Point bossRoom;
    Point shopRoom;
    Point startRoom;
    Point lastRoom;
    Point furthestRoom;

    //Position for the currentroomindicator in the minimap
    Vector2 indicatorPosition = new Vector2(110,110);

    string currentMusic;

    static Room currentRoom;

    public static Room CurrentRoom
    {
        get { return currentRoom; }
        set { currentRoom = value; }
    }

    public static GameObjectList RoomList
    {
        get { return roomList; }
    }

    public GameObjectList MinimapList
    {
        get { return miniMapList; }
    }

    public Point StartRoom
    {
        get { return startRoom; }
    }

    //Find the northern, southern, western and eastern points
    public Point NorthPoint(Point currentPoint)
    {
        return new Point(currentPoint.X, currentPoint.Y - 1);
    }

    public Point SouthPoint(Point currentPoint)
    {
        return new Point(currentPoint.X, currentPoint.Y + 1);
    }

    public Point WestPoint(Point currentPoint)
    {
        return new Point(currentPoint.X - 1, currentPoint.Y);
    }

    public Point EastPoint(Point currentPoint)
    {
        return new Point(currentPoint.X + 1, currentPoint.Y);
    }

    //Builds a full floor by first making a pointlist and then assigning rooms to every point.
    public void BuildFloor(int level)
    {
        GameData.CurrentFloor = level;
        GameData.PuzzleSolved = false;
        //Initialize the currentRoom, which is the only room that is updated.
        currentRoom = new Room(false, false, false, false, "room", 1);
        roomList = new GameObjectList();//The final list of all rooms.
        miniMapList = new GameObjectList();//List of rooms already visited.
        exploredRoomsList = new GameObjectList();
        criticalPathList = new List<Point>();//List of all points in the critical path.
        allRoomsList = new List<Point>();//List of all points.

        puzzleCount = 0;
        branchCount = 0;
        critPathLength = 4 + 2 * level;

        //First, build the criticalpath. This is the path between the startroom. It has a length of 5, 7 or 9.
        BuildCriticalPath(critPathLength);
        //Then, build some branches on this criticalpath
        BuildBranches(level);

        foreach (Point point in allRoomsList)
        {
            CreateRoom(point, (shopRoom == point), (point == bossRoom), false, (point == furthestRoom), false);
        }

        currentRoom.LoadNewRoom();//Loads the list of objects of the currentroom, which is the startingroom.
        AddToMiniMap(currentRoom);//adds the startingroom to the list of explored rooms.
        SpriteGameObject currentRoomIndicator = new SpriteGameObject("currentroom", layer: 11, id: "indicator");//Indicates what room you are in in the minimap.
        currentRoomIndicator.Position = indicatorPosition;
        hud.hud.Add(currentRoomIndicator);

        bool bossPresent = false;//Check for a boss. If there isn't one, build a new floor.
        foreach (Room room in roomList.Objects)
        {
            if (room.roomType == "boss")
            {
                bossPresent = true;
            }
        }

        if (!bossPresent)
        {
            roomList.Objects.Clear();
            miniMapList.Objects.Clear();
            criticalPathList.Clear();
            allRoomsList.Clear();
            BuildFloor(level);
        }

        GameData.AllRoomPoints = allRoomsList;
        //Remove all minimapitems that could still be in the hud from the last game
        for (int i = hud.hud.Objects.Count - 1; i >= 0; i--)
        {
            if (hud.hud.Objects[i].ID == "minimap")
                hud.hud.Remove(hud.hud.Objects[i]);
        }

        switch (level)
        {
            case 0:
                GameWorld.AssetLoader.PlayMusic("startingmusic");
                currentMusic = "start";
                break;
            case 1:
                GameWorld.AssetLoader.PlayMusic("floor2music");
                break;
            case 2:
                GameWorld.AssetLoader.PlayMusic("floor3music");
                break;
            default:
                break;
        }
    }

    public void MakePuzzleTreasureRoom(Room puzzleRoom, string dir)
    {//Make a treasure room that is connected to the puzzle room by checking to what direction a free space is situated
        switch (dir)
        {
            case "north":
                CreateRoom(NorthPoint(puzzleRoom.point), false, false, false, false, true);
                break;
            case "south":
                CreateRoom(SouthPoint(puzzleRoom.point), false, false, false, false, true);
                break;
            case "west":
                CreateRoom(WestPoint(puzzleRoom.point), false, false, false, false, true);
                break;
            case "east":
                CreateRoom(EastPoint(puzzleRoom.point), false, false, false, false, true);
                break;
            default:
                break;
        }
    }

    //Counts the amount of neighbouring rooms, so that the path doesn't stay in a small 5x5 place, but spreads.
    int NeighbourRooms(Point thisRoom)
    {
        int neighbours = 0;
        if (criticalPathList.Contains(EastPoint(thisRoom)) || allRoomsList.Contains(EastPoint(thisRoom)))
            neighbours++;
        if (criticalPathList.Contains(WestPoint(thisRoom)) || allRoomsList.Contains(WestPoint(thisRoom)))
            neighbours++;
        if (criticalPathList.Contains(SouthPoint(thisRoom)) || allRoomsList.Contains(SouthPoint(thisRoom)))
            neighbours++;
        if (criticalPathList.Contains(NorthPoint(thisRoom)) || allRoomsList.Contains(NorthPoint(thisRoom)))
            neighbours++;
        return neighbours;
    }

    //Creates a room at the position assigned. Also, check if the room is a shop, an itemroom or the bossroom.

    public void CreateRoom(Point position, bool shop, bool isBoss, bool isFinalBoss, bool isFurthest, bool puzzleTreasure)
    {
        bool north = false, east = false, south = false, west = false;
        //First, check on what sides other rooms can be found, so that there can be build doors to other rooms.
        //There can't be build doors from the side to the bossroom.
        if (isBoss)//if the room is a bossroom, check only for north and south.
        {
            if ((criticalPathList.Contains(SouthPoint(position)) && lastRoom == SouthPoint(position)))
                south = true;
            if ((criticalPathList.Contains(NorthPoint(position)) && lastRoom == NorthPoint(position)))
                north = true;
        }
        else if (isFinalBoss)//If the room is the final boss, only make a door to the normal bossroom
        {
            if (SouthPoint(position) == bossRoom)
                south = true;
            else if (NorthPoint(position) == bossRoom)
                north = true;
            else if (EastPoint(position) == bossRoom)
                east = true;
            else if (WestPoint(position) == bossRoom)
                west = true;
        }
        else if (puzzleTreasure)//If the room is a puzzletreasureroom, check for puzzle rooms
        {
            if (allRoomsList.Contains(EastPoint(position))
                && FindRoom(EastPoint(position)) is PuzzleRoomSimon)
                east = true;
            if (allRoomsList.Contains(WestPoint(position))
                && FindRoom(WestPoint(position)) is PuzzleRoomSimon)
                west = true;
            if (allRoomsList.Contains(SouthPoint(position))
                && FindRoom(SouthPoint(position)) is PuzzleRoomSimon)
                south = true;
            if (allRoomsList.Contains(NorthPoint(position))
                && FindRoom(NorthPoint(position)) is PuzzleRoomSimon)
                north = true;
        }
        else
        {//If it is a normal room, just check for every room
            if (allRoomsList.Contains(EastPoint(position)) && bossRoom != EastPoint(position))
                east = true;
            if (allRoomsList.Contains(WestPoint(position)) && bossRoom != WestPoint(position))
                west = true;
            if (allRoomsList.Contains(SouthPoint(position))) {
                if (bossRoom == SouthPoint(position))
                {//if the southern room is the bossroom, only make a door to it if this room is the last room in the criticalpath
                    if (lastRoom == position)
                        south = true;
                }
                else
                    south = true;
            }
            if (allRoomsList.Contains(NorthPoint(position)))
            {
                if (bossRoom == NorthPoint(position))
                {
                    if (lastRoom == position)
                        north = true;
                }
                else
                    north = true;
            }
        }
        //every non-special room has a chance to become a puzzleroom. However, only one puzzleroom can be made per floor
        if (R.Dice(5) == 1 && !isBoss && !shop && !isFurthest && position != startRoom && !puzzleTreasure && puzzleCount < 1 && !isFinalBoss)
        {
            puzzleCount++;
            PuzzleRoomSimon puzzleroom = new PuzzleRoomSimon(north, east, south, west, "room", 1);
            puzzleroom.point = position;
            roomList.Add(puzzleroom);
            MakePuzzleTreasureRoom(puzzleroom, puzzleroom.BonusRoomDirection(position));
        }
        else
        {
            Room room = new Room(north, east, south, west, "room", 1);
            //set the roomtype and the position of the room.
            if (isBoss)
                room.roomType = "boss";
            else if (isFinalBoss)
                room.roomType = "finalBoss";
            else if (puzzleTreasure)
                room.roomType = "treasure";
            else if (shop)
                room.roomType = "shop";
            else if (position == startRoom)
                room.roomType = "startroom";

            if (isFurthest)//If this is the furthestroom, first check if the room isn't a corner. If it is, make a new room, away from the starting room.
            {
                if (NeighbourRooms(position) > 1)
                {
                    if (position.X > 5)
                        CreateRoom(EastPoint(position), false, false, false, true, false);
                    else
                        CreateRoom(WestPoint(position), false, false, false, true, false);
                }
                else
                    room.roomType = "item";
            }
            room.point = position;
            //If it's the startingroom, set it as the currentroom
            if (position == startRoom)
                currentRoom = room;
            //And finally, add the room to the roomlist.
            roomList.Add(room);
        }
    }

    //Makes a final boss room. First, check where there is a free spot. Then, create a walldestroyer which is placed, destroys all doors,
    //and then is removed itself. Finally, build a new finalbossroom
    public void MakeFinalBossRoom()
    {
        Vector2 pos = new Vector2(0, 0);
        Point finalBossPoint = new Point(0, 0);
        if (!allRoomsList.Contains(NorthPoint(currentRoom.point)))
        {
            finalBossPoint = NorthPoint(currentRoom.point);
            pos = new Vector2(14 * GameSettings.TileWidth + GameSettings.GameFieldOffset, GameSettings.GameFieldOffset);
        }
        else if (!allRoomsList.Contains(SouthPoint(currentRoom.point)))
        {
            finalBossPoint = SouthPoint(currentRoom.point);
            pos = new Vector2(14 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 14 * GameSettings.TileHeight);
        }
        else if (!allRoomsList.Contains(WestPoint(currentRoom.point)))
        {
            finalBossPoint = WestPoint(currentRoom.point);
            pos = new Vector2(GameSettings.GameFieldOffset, 8 * GameSettings.TileHeight);
        }
        else if (!allRoomsList.Contains(EastPoint(currentRoom.point)))
        {
            finalBossPoint = EastPoint(currentRoom.point);
            pos = new Vector2(29 * GameSettings.TileWidth, 8 * GameSettings.TileHeight);
        }

        CreateRoom(finalBossPoint, false, false, true, false, false);

        SpriteGameObject WallDeleter = new SpriteGameObject("placeholder", 0, layer: 10);
        WallDeleter.Position = pos;
        WallDeleter.Solid = true;
        GameData.LevelObjects.Add(WallDeleter);

        for (int i = CurrentRoom.tileList.Objects.Count - 1; i >= 0; i--)
        {
            if (CurrentRoom.tileList.Objects[i] is SpriteGameObject)
            {
                SpriteGameObject obj = CurrentRoom.tileList.Objects[i] as SpriteGameObject;
                if (obj.CollidesWith(WallDeleter) && obj.Solid)
                {
                    CurrentRoom.tileList.Remove(obj);
                }
            }
        }
        GameData.LevelObjects.Remove(WallDeleter);
    }


    /// <summary>
    /// LoadFloor is a not yet working class. It is used to load the savefile from the gamedata. It doesn't work yet and is yet to be fixed.
    /// </summary>
    public void LoadFloor()
    {
        roomList = new GameObjectList();
        exploredRoomsList = new GameObjectList();
        allRoomsList = new List<Point>();
        miniMapList = new GameObjectList();

        List<Point> completedList = GameData.CompletedRooms;
        List<String> pathList = GameData.RoomPaths;
        allRoomsList = GameData.AllRoomPoints;

        for (int i = 0; i < completedList.Count; i++)
        {
            Room room = new Room(false, false, false, false, "", 0);
            room.point = completedList[i];
            RoomList.Add(room);
        }

        for (int i = 0; i < allRoomsList.Count; i++)
        {
            if (!completedList.Contains(allRoomsList[i]))
            {
                CreateRoom(allRoomsList[i], false, false, false, false, false);
            }
        }

        CreateRoom(GameData.CurrentRoom, false, false, false, false, false);
        CurrentRoom = FindRoom(GameData.CurrentRoom);


        for (int i = 0; i < pathList.Count; i++)
        {
            Room room = roomList.Objects[i] as Room;
            room.tileList = room.loader.Loadlevel(pathList[i], GameData.RoomsMirroredX[i], GameData.RoomsMirroredY[i], "");
        }

        foreach (Room room in roomList.Objects)
        {
            if (completedList.Contains(room.point))
            {
                exploredRoomsList.Add(room);
            }
        }
    }
}
