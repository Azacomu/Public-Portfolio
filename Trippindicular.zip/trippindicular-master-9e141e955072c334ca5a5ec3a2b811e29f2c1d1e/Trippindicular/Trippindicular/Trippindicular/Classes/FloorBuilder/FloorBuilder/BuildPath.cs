﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

partial class FloorBuilder
{
    //Builds the critical path.
    public void BuildCriticalPath(int critPathLength)
    {
        startRoom = new Point(5, 5);
        criticalPathList.Add(startRoom);
        FindNewPath(startRoom, criticalPathList, critPathLength);
        //Find a new path from startroom with length critpathlength, and add them to the critpathlist.
        foreach (Point room in criticalPathList)
        {//Add the rooms to the allroomslist as well.
            allRoomsList.Add(room);
        }
    }

    //Used to find a new path from currentRoom, with a certain length.
    public void FindNewPath(Point currentRoom, List<Point> addToList, int length)
    {
        int counter = 0;
        int maxNeighbours = 1;
        int limit = 20;
        Point newRoom = currentRoom;
        Point oldRoom = newRoom;
        for (int i = 0; i < length; i++)
        {
            newRoom = FindNewRoom(oldRoom);//Try to find a new room, which is adjacent to the oldroom.

            while ((allRoomsList.Contains(newRoom) || criticalPathList.Contains(newRoom) || NeighbourRooms(newRoom) > maxNeighbours))
            {//if the room is already in the list, or has too many neighbours, find a new room.
                if (counter > limit)
                {
                    maxNeighbours++;
                    counter = 0;
                }

                if (maxNeighbours > limit)
                {
                    roomList.Objects.Clear();
                    miniMapList.Objects.Clear();
                    criticalPathList.Clear();
                    allRoomsList.Clear();
                    BuildFloor(GameData.CurrentFloor);
                    return;
                }
                newRoom = FindNewRoom(oldRoom);
                counter++;
            }
            //When a good room is found, set the oldroom to be the new room, and add the room to the list.
            oldRoom = newRoom;
            addToList.Add(newRoom);
        }
        if (addToList != criticalPathList)  //set every room not in the critical path as the shop, so the shop is at
            shopRoom = newRoom;             //the end of the last branch.

        if (addToList == criticalPathList)
            MakeBossRoom(addToList, newRoom);
    }


    public Point FindNewRoom(Point currentRoom)
    {
        Point newRoom = currentRoom;
        switch (R.Dice(4))//Randomly build a new room above, beneath or besides the curren room.
        {
            case 1:
                newRoom.X++;
                break;
            case 2:
                newRoom.X--;
                break;
            case 3:
                newRoom.Y++;
                break;
            case 4:
                newRoom.Y--;
                break;
        }
        return newRoom;
    }

    public void MakeBossRoom(List<Point> addToList, Point currentRoom)
    {   //Try to make a bossroom. Since the bossroom only has a door to the north or south, there must be checked
        //if there is a free space above or beneath the current room, then the bossroom must be build there.
        lastRoom = currentRoom;
        if (!addToList.Contains(SouthPoint(currentRoom)))
        {
            currentRoom.Y++;
            bossRoom = currentRoom;
            addToList.Add(currentRoom);
        }
        else if (!addToList.Contains(NorthPoint(currentRoom)))
        {
            currentRoom.Y--;
            bossRoom = currentRoom;
            addToList.Add(currentRoom);
        }
        else
        {
            if (!addToList.Contains(EastPoint(currentRoom)))
            {
                currentRoom.X++;
                addToList.Add(currentRoom);
                MakeBossRoom(addToList, currentRoom);
            }
            else if (!addToList.Contains(WestPoint(currentRoom)))
            {
                currentRoom.X--;
                addToList.Add(currentRoom);
                MakeBossRoom(addToList, currentRoom);
            }
        }
    }

    //This method is used to build branches. There is a chance to spawn one from each room in the critical path,
    //Though there is a maximum. To ensure floor aren't too short, there is a minimum of two branches for each floor.
    //There is also a maximum, which depends on the current floor.
    public void BuildBranches(int floor)
    {
        for (int i = 0; i < criticalPathList.Count - 2; i++)
        {
            if (i == 0)
            {
                branchCount++;
                FindNewPath(criticalPathList[i], allRoomsList, 3 + floor);
            }
            else if (i == 3 && branchCount == 1)
            {
                branchCount++;
                FindNewPath(criticalPathList[i], allRoomsList, 3 + floor);
            }
            else if (R.Dice(3) == 3 && branchCount < 6 + floor)
            {
                FindNewPath(criticalPathList[i], allRoomsList, 3 + floor);
                branchCount++;
            }
        }

        furthestRoom = startRoom;
        //Determine which point is the furthest. Here, the itemroom is situated.
        foreach (Point point in allRoomsList)
        {
            if (!(criticalPathList.Contains(point)) && point != shopRoom)
            {
                if (Math.Pow(point.X - 5, 2) + Math.Pow(point.Y - 5, 2) > Math.Pow(furthestRoom.X - 5, 2) + Math.Pow(furthestRoom.Y - 5, 2))
                    furthestRoom = point;
            }
        }

        if (floor == 2)
        {
            for (int i = 0; i < allRoomsList.Count - 2; i++)
            {
                if (!criticalPathList.Contains(allRoomsList[i]) && NeighbourRooms(allRoomsList[i]) < 3 && allRoomsList[i] != furthestRoom && allRoomsList[i] != shopRoom && R.Dice(5) == 1)
                {
                    FindNewPath(allRoomsList[i], allRoomsList, 3);
                }
            }
        }
    }
}
