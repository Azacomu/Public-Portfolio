﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

public partial class FloorBuilder
{
    HUD hud = GameWorld.GameStateManager.GetGameState("hud") as HUD;

    //Used to move between rooms. This method also uses a string to determine which direction to go to.
    public void MoveRoom(Room oldRoom, string direction)
    {
        SaveOldRoom(oldRoom);

        switch (direction)
        {
            case "south":
                currentRoom = FindRoom(SouthPoint(oldRoom.point));
                GameData.GetPlayer.PositionY = GameSettings.TileHeight * 2 + GameSettings.GameFieldOffset;//Gives the player a new position so it spawns on the other side.
                break;
            case "west":
                currentRoom = FindRoom(WestPoint(oldRoom.point));
                GameData.GetPlayer.PositionX = ((LevelLoader.horTiles - 1) * GameSettings.TileWidth);
                break;
            case "east":
                currentRoom = FindRoom(EastPoint(oldRoom.point));
                GameData.GetPlayer.PositionX = GameSettings.TileWidth * 2;
                break;
            case "north":
                currentRoom = FindRoom(NorthPoint(oldRoom.point));
                GameData.GetPlayer.PositionY = ((LevelLoader.verTiles - 1) * GameSettings.TileHeight);
                break;
            default:
                break;
        }

        GameData.CurrentRoom = currentRoom.point;
        if (currentRoom is PuzzleRoomSimon)//When the room is a puzzleroom, create a hint.
        {
            Notification not = new Notification("Follow the sequence.", "Step on the middle tile to start.", "", 3);
            not.CreateNotification();
        }

        GameData.UpdateSolidList();
        //Reposition the currentroomindicator:

        if (!GameData.CompletedRooms.Contains(currentRoom.point))
            GameData.CompletedRooms.Add(currentRoom.point);


        MoveMiniMap(direction);
        //If the room hasn't been explored yet, load the level freshly
        if (!miniMapList.Objects.Contains(currentRoom))
        {
            AddToMiniMap(currentRoom);
            currentRoom.LoadNewRoom();
            LoadObjectsInRoom(currentRoom);
        }
        else//If the level is already in the minimap, load what was saved when you left it.
            LoadObjectsInRoom(currentRoom);

        if (currentRoom.point != startRoom && currentMusic == "start")
        {
            GameWorld.AssetLoader.PlayMusic("floor1music");
            currentMusic = "floor1";
        }

        if (GameData.GetPlayer.Inventory.GetItem(1) is Boomerang)
            GameData.GetPlayer.Inventory.GetItem(1).CooldownTimer = 15;
    }

    public void MoveMiniMap(string direction)
    {//Move every minimap item so that the currentroom remains in the center
        foreach (GameObject obj in hud.hud.Objects)
        {
            if (obj.ID == "minimap")
            {
                switch (direction)
                {
                    case "north":
                        obj.PositionY += indicatorHeight;
                        break;
                    case "south":
                        obj.PositionY -= indicatorHeight;
                        break;
                    case "west":
                        obj.PositionX += indicatorWidth;
                        break;
                    case "east":
                        obj.PositionX -= indicatorWidth;
                        break;
                    default:
                        break;
                }

                if (InMiniMap(obj))
                    obj.Visible = true;
                else
                    obj.Visible = false;
            }
        }
    }

    public bool InMiniMap(GameObject obj)
    {//Check a rooms position and whether it should be displayed in the minimap
        return (((obj.PositionY < indicatorPosition.Y + 3 * indicatorHeight) && (obj.PositionY > indicatorPosition.Y - 3 * indicatorHeight)) && ((obj.PositionX < indicatorPosition.X + 2 * indicatorWidth) && (obj.PositionX > indicatorPosition.X - 2 * indicatorWidth)));

    }

    //Adds a room to the minimap.
    public void AddToMiniMap(Room currentRoom)
    {
        SpriteGameObject miniMapRoom = new SpriteGameObject("room", layer: 10, id: "minimap");
        miniMapRoom.Position = indicatorPosition;
        miniMapList.Add(currentRoom);
        hud.hud.Add(miniMapRoom);
        GameData.CompletedRooms.Add(currentRoom.point);
        AddToMiniMapGhost();
    }

    //Adds 'Ghost' minimap items, which are see-through rooms on the minimap that show what rooms you have yet to clear.
    public void AddToMiniMapGhost()
    {
        if (currentRoom.north)
        {
            SpriteGameObject mapRoomGhost = new SpriteGameObject("");
            if (FindRoom(NorthPoint(currentRoom.point)).roomType == "boss")
            {
                mapRoomGhost = new SpriteGameObject("bossroom", layer: 10, id: "minimap");
            }
            else
            {
                mapRoomGhost = new SpriteGameObject("ghostroom", layer: 10, id: "minimap");
            }
            mapRoomGhost.Position = indicatorPosition - new Vector2(0, indicatorHeight);
            hud.hud.Add(mapRoomGhost);
        }

        if (currentRoom.south)
        {
            SpriteGameObject mapRoomGhost = new SpriteGameObject("");
            if (FindRoom(SouthPoint(currentRoom.point)).roomType == "boss")
            {
                mapRoomGhost = new SpriteGameObject("bossroom", layer: 10, id: "minimap");
            }
            else
            {
                mapRoomGhost = new SpriteGameObject("ghostroom", layer: 10, id: "minimap");
            }
            mapRoomGhost.Position = indicatorPosition + new Vector2(0, indicatorHeight);
            hud.hud.Add(mapRoomGhost);
        }

        if (currentRoom.east)
        {
            SpriteGameObject mapRoomGhost = new SpriteGameObject("");
            if (FindRoom(EastPoint(currentRoom.point)).roomType == "boss")
            {
                mapRoomGhost = new SpriteGameObject("bossroom", layer: 10, id: "minimap");
            }
            else
            {
                mapRoomGhost = new SpriteGameObject("ghostroom", layer: 10, id: "minimap");
            }
            mapRoomGhost.Position = indicatorPosition + new Vector2(indicatorWidth, 0);
            hud.hud.Add(mapRoomGhost);
        }

        if (currentRoom.west)
        {
            SpriteGameObject mapRoomGhost = new SpriteGameObject("");
            if (FindRoom(WestPoint(currentRoom.point)).roomType == "boss")
            {
                mapRoomGhost = new SpriteGameObject("bossroom", layer: 10, id: "minimap");
            }
            else
            {
                mapRoomGhost = new SpriteGameObject("ghostroom", layer: 10, id: "minimap");
            }
            mapRoomGhost.Position = indicatorPosition - new Vector2(indicatorWidth, 0);
            hud.hud.Add(mapRoomGhost);
        }
    }

    public void SaveOldRoom(Room oldRoom)
    {//Save all items that are located in a room when you leave the room
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (!(GameData.LevelObjects.Objects[i] is Player) && !(GameData.LevelObjects.Objects[i].ID == "minimap") && !(GameData.LevelObjects.Objects[i].ID == "indicator"))
            {
                oldRoom.objectList.Add(GameData.LevelObjects.Objects[i]);
                GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
            }
        }
    }

    public void LoadObjectsInRoom(Room room)
    {//Load every item saved in the old room and place it back.
        for (int i = room.objectList.Objects.Count - 1; i >= 0; i--)
        {
            GameData.LevelObjects.Add(room.objectList.Objects[i]);
            room.objectList.Objects.Remove(room.objectList.Objects[i]);
        }
    }

    public static Room FindRoom(Point point)
    {//Try to find a room at a certain point.
        foreach (Room room in roomList.Objects)
        {
            if (room.point == point)
            {
                return room;
            }
        }
        return new Room(false, false, false, false, "room", 0);
    }

    /// <summary>
    ///This class is used to move to the next floor.It clears all objectlists, then removes all object in the gamedata.levelobjects
    /// except for the player, then repositions the player to the center of the screen, and finally builds a new floor,
    /// that is a bit more difficult than the last floor.
    /// </summary>
    public void MoveFloor()
    {
        GameData.CurrentFloor++;
        int floor = GameData.CurrentFloor;
        roomList.Objects.Clear();
        miniMapList.Objects.Clear();
        criticalPathList.Clear();
        allRoomsList.Clear();
        for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
        {
            if (!(GameData.LevelObjects.Objects[i] is Player))
                GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
        }
        GameData.LevelObjects.Objects[0].Position = new Vector2(15 * GameSettings.TileWidth, 7 * GameSettings.TileHeight);
        BuildFloor(floor);

        PlayingState.SaveGame.InitializeSave();
    }

}
