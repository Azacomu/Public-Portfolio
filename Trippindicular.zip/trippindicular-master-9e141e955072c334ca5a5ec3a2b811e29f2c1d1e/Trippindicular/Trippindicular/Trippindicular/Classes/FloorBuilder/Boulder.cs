﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Boulder that the player can push around
class Boulder : SpriteGameObject
{
    List<Point> taken, water;
    Point left, right, top, bottom;    

    public Boulder() : base("boulder", 0, "boulder", 1)
    {
        SurroundingTiles();
    }

    /*Moves the boulder depending on the side the player pushes from and whether there is a solid object or not
    If the solid object is a watertile the boulder will change the watertile to a watertile with a boulder in it so the player can walk over it*/
    public void Push()
    {
        if (RelativePlayerPosition() == "left")
        {
            if (taken.Contains(right))
            {
                solid = true;
                GameData.UpdateSolidList();
            }

            else if (CollidesWith(GameData.GetPlayer))
            {
                if (water.Contains(right))
                {
                    WaterCollision(right);
                }
                else
                {
                    position = new Vector2(position.X + GameSettings.TileWidth, position.Y);
                    SurroundingTiles();
                }
            }
            else
            {
                solid = false;
                GameData.UpdateSolidList();
            }
        }

        if (RelativePlayerPosition() == "right")
        {
            if (taken.Contains(left))
            {
                solid = true;
                GameData.UpdateSolidList();
            }

            else if (CollidesWith(GameData.GetPlayer))
            {
                if (water.Contains(left))
                {
                    WaterCollision(left);
                }
                else
                {
                    position = new Vector2(position.X - GameSettings.TileWidth, position.Y);
                    SurroundingTiles();
                }
            }
            else
            {
                solid = false;
                GameData.UpdateSolidList();
            }
        }

        if (RelativePlayerPosition() == "top")
        {
            if (taken.Contains(bottom))
            {
                solid = true;
                GameData.UpdateSolidList();
            }

            else if (CollidesWith(GameData.GetPlayer))
            {
                if (water.Contains(bottom))
                {
                    WaterCollision(bottom);
                }
                else
                {
                    position = new Vector2(position.X, position.Y + GameSettings.TileHeight);
                    SurroundingTiles();
                }
            }
            else
            {
                solid = false;
                GameData.UpdateSolidList();
            }
        }

        if (RelativePlayerPosition() == "bottom")
        {
            if (taken.Contains(top))
            {
                solid = true;
                GameData.UpdateSolidList();
            }

            else if (CollidesWith(GameData.GetPlayer))
            {
                if (water.Contains(top))
                {
                    WaterCollision(top);
                }
                else
                {
                    position = new Vector2(position.X, position.Y - GameSettings.TileHeight);
                    SurroundingTiles();
                }
            }
            else
            {
                solid = false;
                GameData.UpdateSolidList();
            }
        }
    }

    //check whether the surrounding tiles are occupied by a solid object or water and store these objects
    public void SurroundingTiles()
    {
        left = new Point(TileIndex.X - 1, TileIndex.Y);
        right = new Point(TileIndex.X + 1, TileIndex.Y);
        top = new Point(TileIndex.X, TileIndex.Y - 1);
        bottom = new Point(TileIndex.X, TileIndex.Y + 1);

        taken = new List<Point>();
        water = new List<Point>();

        List<SpriteGameObject> objects = GameData.FindNearbyTiles(this);
        for (int i = 0; i < objects.Count; i++)
        {
            if (objects[i].Solid == true && objects[i].ID != "water" || objects[i] is Boulder || objects[i] is Items || objects[i] is Door)
            {
                taken.Add(objects[i].TileIndex);
                if (objects[i] is Door)
                    taken.Add(new Point(objects[i].TileIndex.X, objects[i].TileIndex.Y + 1));
            }
            else if (objects[i].ID == "water")
            {
                water.Add(objects[i].TileIndex);
            }
        }
    }

    //Check whether the player is coming from the side you want to move the boulder from
    public string RelativePlayerPosition()
    {
        //left
        if (GameData.GetPlayer.BoundingBox.Center.X < BoundingBox.Center.X && GameData.GetPlayer.Velocity.X > 0)
            return "left";
        //right
        else if (GameData.GetPlayer.BoundingBox.Center.X > BoundingBox.Center.X && GameData.GetPlayer.Velocity.X < 0)
            return "right";
        //top
        if (GameData.GetPlayer.BoundingBox.Bottom < BoundingBox.Center.Y && GameData.GetPlayer.Velocity.Y > 0)
            return "top";
        //bottom
        else if (GameData.GetPlayer.BoundingBox.Top > BoundingBox.Center.Y && GameData.GetPlayer.Velocity.Y < 0)
            return "bottom";
        else
            return "error";

    }

    //switching the boulder with a boulder in water
    public void WaterCollision(Point point)
    {
        List<SpriteGameObject> objects = GameData.LevelObjects.FindTiles(point);
        foreach (SpriteGameObject obj in objects)
        {
            if (obj.ID == "water")
            {
                SpriteGameObject bw = new SpriteGameObject("boulderWater", obj.Sprite.SheetIndex, "boulderWater", 0);
                bw.Position = obj.Position;
                GameData.LevelObjects.Add(bw);
                GameData.LevelObjects.Remove(obj);
                GameData.LevelObjects.Remove(this);
                GameData.UpdateSolidList();
            }
        }        
    } 

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        Push();
    }
}
