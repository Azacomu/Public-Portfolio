﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class PressurePlate : SpriteGameObject
{
    //A PressurePlate is used in the simon says puzzle room. It has two methods, to flash and to turn off, and a constructor
    //to find the right sprites that must be used to solve the puzzle.
    string flashName;
    string idleName;

    public PressurePlate(string assetName, int sheetIndex, string id = "", int layer = 0) : base("redplate", 0, id, layer)
    {
        idleName = assetName;
        sprite = new SpriteSheet(idleName, 0);

        flashName = assetName.Remove(assetName.Length - 5);
        flashName += "flash";
    }

    public void Flash()
    {//Flash the plate. This is simply done by giving the plate a brighter sprite.
        sprite = new SpriteSheet(flashName, 0);
    }

    public void TurnOff()
    {//Turn off the plate by giving it its old sprite.
        sprite = new SpriteSheet(idleName, 0);
    }
}
