﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

public partial class LevelLoader
{
    //Determines what part of the wallsprite should be used.
    //When the wall is on the left, use the left part of the wallsprite, etc.
    public void DetermineWallPosition(int x, int y)
    {
        int sheetIndex;
        if (x == 0)
        {
            if (y == 0)
                sheetIndex = 0;
            else if (y == height - 1)
                sheetIndex = 6;
            else
                sheetIndex = 3;
        }
        else if (x == width - 1)
        {
            if (y == 0)
                sheetIndex = 2;
            else if (y == height - 1)
                sheetIndex = 8;
            else sheetIndex = 5;
        }
        else if (y == 0)
            sheetIndex = 1;
        else
            sheetIndex = 7;

        SpriteGameObject tile = new SpriteGameObject("wall", sheetIndex, "wall");
        tile.Position = new Vector2(GameSettings.GameFieldOffset + GameSettings.TileWidth * x, GameSettings.GameFieldOffset + GameSettings.TileHeight * y);
        tile.Solid = true;
        objectList.Add(tile);
    }
}
