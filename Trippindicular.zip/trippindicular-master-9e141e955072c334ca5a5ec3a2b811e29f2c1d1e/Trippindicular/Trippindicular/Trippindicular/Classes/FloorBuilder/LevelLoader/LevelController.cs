﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

//The LevelController class is used to update the currentroom, and it is accessed from the PlayingState class.
//It takes care of the updating of the currentroom, it takes care of moving between rooms and of the opening of doors.
//Furthermore, it arranges the initialization of the first level.
class LevelController :Controller
{
    LevelLoader levelLoader;
    FloorBuilder builder;

    public LevelController(bool newFloor)
    {
        levelLoader = new LevelLoader();
        builder = new FloorBuilder();
        //Build a new floor, floor 0.
        if (newFloor)
            builder.BuildFloor(0);
        else
            builder.BuildFloor(GameData.CurrentFloor);
    }
    


    public override void Update(GameTime gameTime)
    {
        MoveBetweenRooms(builder);

        FloorBuilder.CurrentRoom.Update(gameTime);

        if (FloorBuilder.CurrentRoom.roomType == "boss" && FloorBuilder.CurrentRoom.CountEnemies() == 0)
        {
            if (GameData.CurrentFloor == 2)
                builder.MakeFinalBossRoom();
            else
                UseTrapDoor();
        }
    }
    
    public void MoveBetweenRooms(FloorBuilder builder)
    {
        //If the player is out of the room, which is build by the solid walls, it moves to the next room.
        if (GameData.GetPlayer.PositionX > (29 * GameSettings.TileWidth))
        {
            builder.MoveRoom(FloorBuilder.CurrentRoom, "east");
            if (GameData.LevelObjects.Find("doorwest") is KeyDoor)
                GameData.LevelObjects.Remove(GameData.LevelObjects.Find("doorwest"));
            //Furthermore, if the door that has been passed is a keydoor, also remove the keydoor on the other side.
        }
        else if (GameData.GetPlayer.PositionX < GameSettings.TileWidth)
        {
            builder.MoveRoom(FloorBuilder.CurrentRoom, "west");
            if (GameData.LevelObjects.Find("dooreast") is KeyDoor)
                GameData.LevelObjects.Remove(GameData.LevelObjects.Find("dooreast"));
        }
        else if (GameData.GetPlayer.PositionY > (14 * GameSettings.TileHeight + GameSettings.GameFieldOffset))
        {
            builder.MoveRoom(FloorBuilder.CurrentRoom, "south");
            if (GameData.LevelObjects.Find("doornorth") is KeyDoor)
                GameData.LevelObjects.Remove(GameData.LevelObjects.Find("doornorth"));
        }
        else if (GameData.GetPlayer.PositionY < GameSettings.TileHeight)
        {
            builder.MoveRoom(FloorBuilder.CurrentRoom, "north");
            if (GameData.LevelObjects.Find("doorsouth") is KeyDoor)
                GameData.LevelObjects.Remove(GameData.LevelObjects.Find("doorsouth"));
        }
    }

    //When there is a trapdoor in the room, and the boss is dead, open the trapdoor
    public void UseTrapDoor()
    {
        for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
        {
            if (GameData.LevelObjects.Objects[i] is TrapDoor)
            {
                TrapDoor trapDoor = GameData.LevelObjects.Objects[i] as TrapDoor;
                if (!trapDoor.opened)
                    trapDoor.Open();
                if (GameData.GetPlayer.CollidesWith(GameData.LevelObjects.Objects[i]))
                {
                    builder.MoveFloor();
                }
            }
        }
    }
}
