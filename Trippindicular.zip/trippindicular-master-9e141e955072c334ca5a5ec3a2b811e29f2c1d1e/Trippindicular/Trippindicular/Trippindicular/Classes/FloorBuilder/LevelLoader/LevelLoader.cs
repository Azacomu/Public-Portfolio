﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

//The LevelLoader class reads the files that must be read and creates the level correctly.
public partial class LevelLoader
{
    const int tileHeight = GameSettings.TileHeight;
    const int tileWidth = GameSettings.TileWidth;
    const int offset = GameSettings.GameFieldOffset;
    public const int verTiles = 14;
    public const int horTiles = 29;

    static int width;
    static int height;

    GameObjectList objectList;
    GameObjectList backgroundList;

    List<String> stringList;
    List<String> floortileList;


    //Reads the file and builds the level by adding tiles to the objectList and returning the list.
    public GameObjectList Loadlevel(string filepath, bool xMirror, bool yMirror, string tag)
    {
        objectList = new GameObjectList();
        backgroundList = new GameObjectList();
        BuildGround(objectList);
        StreamReader reader = new StreamReader(filepath);
        string line = reader.ReadLine();
        width = line.Length;
        stringList = new List<string>();
        while (line != null)
        {
            stringList.Add(line);
            line = reader.ReadLine();
        }
        height = stringList.Count;
        //Now that there is a stringlist, use all elements in the stringlist and build the level.
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                //If the level is mirrored, the order of the tiles should be different.
                if (xMirror && yMirror)
                    AddTile(stringList[y][x], width - 1 - x, height - 1 - y, xMirror, yMirror, tag);
                else if (xMirror)
                    AddTile(stringList[y][x], x, height - 1 - y, xMirror, yMirror, tag);
                else if (yMirror)
                    AddTile(stringList[y][x], width - 1 - x, y, xMirror, yMirror, tag);
                else
                    AddTile(stringList[y][x], x, y, xMirror, yMirror, tag);
            }
        }

        return objectList;//the objectlist is returned, which is now a list of every single thing in a room.
    }

    //Using the character that has been read, determine what should be placed at this position.
    public void AddTile(char character, int x, int y, bool xMirror, bool yMirror, string tag)
    {
        Items itemDrop;
        //First, make a normal grasstile, since every other tile can be made over a grasstile.

        switch (character)
        {
            case 'W': //Wall
                DetermineWallPosition(x, y);
                break;
            case 'D'://Door
                DetermineDoor(x, y, tag, xMirror);
                break;
            case 'S'://Spiketrap
                SpikeTrap spikeTrap = new SpikeTrap(TilePosition(x, y));
                spikeTrap.Position += spikeTrap.Origin;
                objectList.Add(spikeTrap);
                break;
            case 's'://ShopKeeper
                Shop shop = new Shop(TilePosition(x, y), "placeholder", 0);
                objectList.Add(shop);
                break;
            case 'T'://Tree
                if (GameData.CurrentFloor < 1)
                {
                    SpriteGameObject tileBeneath = objectList.Objects[verTiles * x + y] as SpriteGameObject;
                    SpriteGameObject solidTile = new SpriteGameObject(tileBeneath.ID, tileBeneath.Sprite.SheetIndex);

                    solidTile.Solid = true;
                    solidTile.Position = TilePosition(x, y);
                    objectList.Add(solidTile);
                    SpriteGameObject tree = new SpriteGameObject("tree");
                    tree.Position = TilePosition(x, y);
                    tree.Solid = true;
                    objectList.Add(tree);
                }
                else if (GameData.CurrentFloor == 1)
                {
                    SpriteGameObject tileBeneath = objectList.Objects[verTiles * x + y] as SpriteGameObject;
                    SpriteGameObject solidTile = new SpriteGameObject(tileBeneath.ID, tileBeneath.Sprite.SheetIndex);

                    solidTile.Solid = true;
                    solidTile.Position = TilePosition(x, y);
                    objectList.Add(solidTile);
                    SpriteGameObject rock = new SpriteGameObject("mossrock");
                    rock.Position = TilePosition(x, y);
                    rock.Solid = true;
                    objectList.Add(rock);
                }
                else
                {
                    SpriteGameObject tileBeneath = objectList.Objects[verTiles * x + y] as SpriteGameObject;
                    SpriteGameObject solidTile = new SpriteGameObject(tileBeneath.ID, tileBeneath.Sprite.SheetIndex);

                    solidTile.Solid = true;
                    solidTile.Position = TilePosition(x, y);
                    objectList.Add(solidTile);
                    SpriteGameObject rock = new SpriteGameObject("rock");
                    rock.Position = TilePosition(x, y);
                    rock.Solid = true;
                    objectList.Add(rock);
                }
                break;
            case '~'://Water
                DetermineWaterTile(x, y, xMirror, yMirror);
                break;
            case '1'://Simple melee enemy
                if (GameData.CurrentFloor == 0)
                {
                    SEMelee SEMelee = new SEMelee(TilePosition(x, y), 100, 0);
                    GameData.LevelObjects.Add(SEMelee);
                }
                else
                {
                    Digger Digger = new Digger(TilePosition(x, y), 100, 0);
                    GameData.LevelObjects.Add(Digger);
                }
                break;
            case '2'://Simple ranged enemy
                if (GameData.CurrentFloor == 0)
                {
                    SERanged SERanged = new SERanged(TilePosition(x, y), 100, 0);
                    GameData.LevelObjects.Add(SERanged);
                }
                else
                {
                    RangedDigger RangedDigger = new RangedDigger(TilePosition(x, y), 100, 0);
                    GameData.LevelObjects.Add(RangedDigger);
                }
                break;
            case '3'://Following ranged enemy
                FERanged Enemy = new FERanged(TilePosition(x, y), 100, 0);
                GameData.LevelObjects.Add(Enemy);
                break;
            case '4'://Following melee enemy
                FEMelee FEMelee = new FEMelee(TilePosition(x, y), 0, 100);
                GameData.LevelObjects.Add(FEMelee);
                break;
            case '5'://ExplodingEnemy
                if (GameData.CurrentFloor > 0)
                {
                    ExplodingEnemy Exploding = new ExplodingEnemy(TilePosition(x, y), 100, 0);
                    GameData.LevelObjects.Add(Exploding);
                }
                break;
            case '6'://SplitEnemy
                if (GameData.CurrentFloor > 0)
                {
                    SplitEnemy splitenemy = new SplitEnemy(TilePosition(x, y), 0, 100);
                    GameData.LevelObjects.Add(splitenemy);
                }
                break;
            //case '7'://Crippler
                //if (GameData.CurrentFloor == 2)
                //{
                //    Crippler crippler = new Crippler(TilePosition(x, y), 100, 0);
                //    GameData.LevelObjects.Add(crippler);
                //}
                //break;
            case 'i'://Weak item drop
                itemDrop = DropTable.DetermineWeakItem();
                if (itemDrop != null)
                {
                    itemDrop.Position = TilePosition(x, y) + itemDrop.Origin;
                    GameData.LevelObjects.Add(itemDrop);
                }
                break;
            case 'I'://Strong item drop
                itemDrop = DropTable.DetermineStrongItem();
                if (itemDrop != null)
                {
                    itemDrop.Position = TilePosition(x, y) + itemDrop.Origin;
                    GameData.LevelObjects.Add(itemDrop);
                }
                break;
            case 'B'://Miniboss, depends on the floor you are on 
                switch (GameData.CurrentFloor)
                {
                    case 0:
                        MiniBossEnemy miniBoss = new MiniBossEnemy(TilePosition(x, y));
                        GameData.LevelObjects.Add(miniBoss);
                        break;
                    case 1:
                        MiniBossEnemy2 miniBoss2 = new MiniBossEnemy2(TilePosition(x, y), 0, 200);
                        GameData.LevelObjects.Add(miniBoss2);
                        break;
                    case 2:
                        MiniBossEnemy3 miniBoss3 = new MiniBossEnemy3(TilePosition(x, y), 0, 200);
                        GameData.LevelObjects.Add(miniBoss3);
                        break;
                    default:
                        break;
                }
                break;
            case 'b'://Boulder
                Boulder boulder = new Boulder();
                boulder.Position = TilePosition(x, y);
                GameData.LevelObjects.Add(boulder);
                break;
            case 't'://Trapdoor
                if (GameData.CurrentFloor != 2)
                {
                    TrapDoor trapDoor = new TrapDoor("trapdoor", 0, "trapdoor", 1);
                    trapDoor.Position = TilePosition(x, y);
                    GameData.LevelObjects.Add(trapDoor);
                }
                break;
            case 'C'://Treasure Chest
                TreasureChest chest = new TreasureChest();
                chest.Position = TilePosition(x, y);
                GameData.LevelObjects.Add(chest);
                break;
            default:
                break;
        }
    }

    public Vector2 TilePosition(int x, int y)//Determine the position of a tile using the x and y coordinate
    {
        return new Vector2(GameSettings.TileWidth * x + offset, GameSettings.TileHeight * y + offset);
    }
    
    //Since monsters have their origin at another point, this method determines at what point an enemy should be spawned
    public Vector2 MonsterPosition(int x, int y)
    {
        return new Vector2(GameSettings.TileWidth * (x + 1), GameSettings.TileHeight * (y + 1));
    }
}