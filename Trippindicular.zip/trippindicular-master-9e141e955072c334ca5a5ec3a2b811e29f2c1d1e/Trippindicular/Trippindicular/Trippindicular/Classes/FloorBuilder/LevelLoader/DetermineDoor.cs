﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

public partial class LevelLoader
{
    //Determines what door should be build at the position it gets by using the tag.
    //In the method, a tile is initialized that is used to detect if the player is close enough
    //to a keydoor to open it.


    void DetermineDoor(int x, int y, string tag, bool xMirror)
    {
        SpriteGameObject tile = new SpriteGameObject("grass", 4, "doortile");
        Vector2 pos = new Vector2(offset + tileWidth * x, offset + tileHeight * y);
        MakeMonsterDoor(x, y, xMirror, tile, pos);
    }

    public void MakeMonsterDoor(int x, int y, bool xMirror, SpriteGameObject tile, Vector2 pos)
    {
        Door door;
        string id;
        //this string is used to determine whether the door is east, north, south or west.
        Room leftRoom = FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X - 1, FloorBuilder.CurrentRoom.Y));
        Room rightRoom = FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X + 1, FloorBuilder.CurrentRoom.Y));
        Room upRoom = FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X, FloorBuilder.CurrentRoom.Y - 1));
        Room downRoom = FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X, FloorBuilder.CurrentRoom.Y + 1));
        if (x == 0)
        {
            id = "doorwest";
            if (xMirror)//If the room is mirrored on the x-axis, the door should be moved up one tile since
                pos.Y -= tileHeight;//the door is two tiles high, and always build downwards.
            tile.Position = pos;//the detection tile is placed at the same position as the door.

            Door openDoor = new Door("doorleft", 0, "", 1);
            openDoor.Position = pos;
            GameData.LevelObjects.Add(openDoor);
            if ((leftRoom.roomType == "shop" || 
                leftRoom.roomType == "item") && Neighbours(leftRoom) == 1)
            {
                tile.Position = pos + new Vector2(0, offset);
                GameData.LevelObjects.Add(tile);
                door = new KeyDoor("doorleft", 1, id, 2);
            }
            else
            {
                door = new MonsterDoor("doorleft", 3, id, 2);//Monsterdoors open when all enemies are gone.
            }
            door.Position = pos;
        }
        else if (y == 0)
        {
            id = "doornorth";
            tile.Position = pos;

            Door openDoor = new Door("doorup", 0, "", 1);
            openDoor.Position = pos;
            GameData.LevelObjects.Add(openDoor);

            if (upRoom.roomType == "shop" ||
                upRoom.roomType == "item" && Neighbours(upRoom) == 1)
            {
                tile.Position = pos + new Vector2(offset, 0);
                GameData.LevelObjects.Add(tile);
                door = new KeyDoor("doorup", 1, id, 2);

            }
            else if (upRoom.roomType == "boss")
            {
                door = new MonsterDoor("doorup", 4, id, 2);
                tile.Position = pos;
                GameData.LevelObjects.Add(tile);
            }
            else
            {
                door = new MonsterDoor("doorup", 3, id, 0);
            }
            door.Position = pos;
        }
        else if (y > verTiles - 3)
        {
            id = "doorsouth";
            tile.Position = pos;
            tile.PositionY -= offset;//Because this door is 32 pixels high, it should be moved slightly

            Door openDoor = new Door("doordown", 0, "", 1);
            openDoor.Position = pos;
            GameData.LevelObjects.Add(openDoor);

            if (downRoom.roomType == "shop" ||
                downRoom.roomType == "item" && Neighbours(downRoom) == 1)
            {

                tile.Position = pos - new Vector2(0, tileHeight);
                GameData.LevelObjects.Add(tile);
                door = new KeyDoor("doordown", 1, id, 2);

            }
            else if (downRoom.roomType == "boss")
            {
                door = new MonsterDoor("doordown", 4, id, 2);
                tile.Position = pos;
                GameData.LevelObjects.Add(tile);
            }
            else
            {
                door = new MonsterDoor("doordown", 3, id, 2);
            }
            door.Position = pos;
        }
        else
        {
            id = "dooreast";
            if (xMirror)
                pos.Y -= tileHeight;
            tile.Position = pos;
            tile.PositionX -= offset;//The detection tile is placed to the left of the door so it isn't located out of the screen

            Door openDoor = new Door("doorright", 0, "", 1);
            openDoor.Position = pos;
            GameData.LevelObjects.Add(openDoor);

            if (rightRoom.roomType == "shop" ||
                rightRoom.roomType == "item" && Neighbours(rightRoom) == 1)
            {
                tile.Position = pos - new Vector2(tileWidth, 0);
                GameData.LevelObjects.Add(tile);
                door = new KeyDoor("doorright", 1, id, 2);
            }
            else
            {
                door = new MonsterDoor("doorright", 3, id, 2);
            }
            door.Position = pos;
        }
        door.Solid = true;
        GameData.LevelObjects.Objects.Add(door);
    }

    //Every puzzleroom has a secret entrance to a treasure room. The door to this treasure room looks like an ordinary wall,
    //but it is removed when the puzzle is solved.
    public void MakePuzzleDoor()
    {
        Door door;
        door = new PuzzleDoor("wall", 1, "", 1);

        if (FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X, FloorBuilder.CurrentRoom.Y - 1)).roomType == "treasure")
        {
            door = new PuzzleDoor("wall", 1, "", 1);
            door.Position = new Vector2(verTiles * tileWidth + offset, offset);
            door.Solid = true;
            GameData.LevelObjects.Objects.Add(door);
            DestroyWall(door);
        }
        else if (FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X, FloorBuilder.CurrentRoom.Y + 1)).roomType == "treasure")
        {
            door = new PuzzleDoor("wall", 7, "",1);
            door.Position = new Vector2((horTiles - 1) / 2 * tileWidth + offset, (verTiles - 1) * tileHeight + offset);
            door.Solid = true;
            GameData.LevelObjects.Objects.Add(door);
            DestroyWall(door);
        }
        else if (FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X - 1, FloorBuilder.CurrentRoom.Y)).roomType == "treasure")
        {
            door = new PuzzleDoor("wall", 3, "", 1);
            door.Position = new Vector2(offset, offset + 6 * tileHeight);
            door.Solid = true;
            GameData.LevelObjects.Objects.Add(door);
            DestroyWall(door);
            door = new PuzzleDoor("wall", 3, "", 1);//Since a left or right door is two tiles high, two puzzledoors should be made.
            door.Position = new Vector2(offset, offset + 7 * tileHeight);
            GameData.LevelObjects.Objects.Add(door);
            DestroyWall(door);
        }
        else if (FloorBuilder.FindRoom(new Point(FloorBuilder.CurrentRoom.X + 1, FloorBuilder.CurrentRoom.Y)).roomType == "treasure")
        {
            door = new PuzzleDoor("wall", 5, "", 1);
            door.Position = new Vector2(GameSettings.GameWidth - offset - tileWidth, 6 * tileHeight + offset);
            door.Solid = true;
            GameData.LevelObjects.Objects.Add(door);
            DestroyWall(door);
            door = new PuzzleDoor("wall", 5, "", 1);
            door.Position = new Vector2(GameSettings.GameWidth - offset - tileWidth, 7 * tileHeight + offset);
            GameData.LevelObjects.Objects.Add(door);
            DestroyWall(door);
        }
    }

    //Destroy the wall that might be situated beneath a door to another room so the door isn't solid.
    public void DestroyWall(Door door)
    {
        for (int i = FloorBuilder.CurrentRoom.tileList.Objects.Count - 1; i >= 0; i--)
        {
            if (FloorBuilder.CurrentRoom.tileList.Objects[i].ID == "wall" && door.CollidesWith(FloorBuilder.CurrentRoom.tileList.Objects[i]))
            {
                FloorBuilder.CurrentRoom.tileList.Remove(FloorBuilder.CurrentRoom.tileList.Objects[i]);
            }
        }
    }

    //Count the amount of neighbouring rooms
    public int Neighbours(Room room)
    {
        int neighbours = 0;
        if (room.north)
            neighbours++;
        if (room.east)
            neighbours++;
        if (room.west)
            neighbours++;
        if (room.south)
            neighbours++;
        return neighbours;
    }
}
