﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

public partial class LevelLoader
{
    //This method determines the spritesheetnumber of a watertile by checking the tiles adjacent to it.
    //However, when the level is mirrored, it should check other tiles. This is different for all four cases.
    //By detecting adjacent tiles, the method builds a string, which is later used to determine the sheetindex.
    public void DetermineWaterTile(int x, int y, bool xMirror, bool yMirror)
    {
        SpriteGameObject waterTile;
        int index = 0;
        string surroundingWater = "";
        if (!xMirror && !yMirror)
        {
            if (stringList[y - 1][x] == '~' || stringList[y - 1][x] == 'W')
                surroundingWater += "N";
            if (stringList[y][x + 1] == '~' || stringList[y][x + 1] == 'W')
                surroundingWater += "E";
            if (stringList[y + 1][x] == '~' || stringList[y + 1][x] == 'W')
                surroundingWater += "S";
            if (stringList[y][x - 1] == '~' || stringList[y][x - 1] == 'W')
                surroundingWater += "W";
        }
        else if (xMirror && yMirror)
        {
            if (stringList[14 - y][28 - x] == '~' || stringList[14 - y][28 - x] == 'W')
                surroundingWater += "N";
            if (stringList[13 - y][27 - x] == '~' || stringList[13 - y][27 - x] == 'W')
                surroundingWater += "E";
            if (stringList[12 - y][28 - x] == '~' || stringList[12 - y][28 - x] == 'W')
                surroundingWater += "S";
            if (stringList[13 - y][29 - x] == '~' || stringList[13 - y][29 - x] == 'W')
                surroundingWater += "W";
        }
        else if (xMirror)
        {
            if (stringList[14 - y][x] == '~' || stringList[14 - y][x] == 'W')
                surroundingWater += "N";
            if (stringList[13 - y][x + 1] == '~' || stringList[13 - y][x + 1] == 'W')
                surroundingWater += "E";
            if (stringList[12 - y][x] == '~' || stringList[12 - y][x] == 'W')
                surroundingWater += "S";
            if (stringList[13 - y][x - 1] == '~' || stringList[13 - y][x - 1] == 'W')
                surroundingWater += "W";
        }
        else if (yMirror)
        {
            if (stringList[y - 1][28 - x] == '~' || stringList[y - 1][28 - x] == 'W')
                surroundingWater += "N";
            if (stringList[y][27 - x] == '~' || stringList[y][27 - x] == 'W')
                surroundingWater += "E";
            if (stringList[y + 1][28 - x] == '~' || stringList[y + 1][28 - x] == 'W')
                surroundingWater += "S";
            if (stringList[y][29 - x] == '~' || stringList[y][29 - x] == 'W')
                surroundingWater += "W";
        }

        switch (surroundingWater)
        {//Assigns a sheetindex to every single possible case.
            case "NESW":
                index = 4;
                break;
            case "NES":
                index = 3;
                break;
            case "NEW":
                index = 7;
                break;
            case "NSW":
                index = 5;
                break;
            case "ESW":
                index = 1;
                break;
            case "NE":
                index = 6;
                break;
            case "ES":
                index = 0;
                break;
            case "SW":
                index = 2;
                break;
            case "NW":
                index = 8;
                break;
            case "NS":
                index = 10;
                break;
            case "EW":
                index = 9;
                break;
            case "E":
                index = 13;
                break;
            case "W":
                index = 11;
                break;
            case "N":
                index = 14;
                break;
            case "S":
                index = 12;
                break;
              
        }
        //Initializes the water tile and adds it to the objectlist.
        waterTile = new SpriteGameObject("water", index, "water");
        waterTile.Position = new Vector2(32 + 64 * x, 32 + 64 * y);
        waterTile.Solid = true;
        objectList.Add(waterTile);
    }
}
