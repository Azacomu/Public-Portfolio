﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

partial class LevelLoader
{
    //Since every room should have another floortile set, add the floortiles to the level.
    //Floortiles are nonsolid objects and only used for visual effects.
    public void BuildGround(GameObjectList ObjectList)
    {
        int groundNr = R.Dice(10);
        string filepath = "Content/Levels/Floors/Floor" + groundNr + ".txt";
        StreamReader reader = new StreamReader(filepath);
        string line = reader.ReadLine();
        width = line.Length;
        stringList = new List<string>();
        while (line != null)
        {
            stringList.Add(line);
            line = reader.ReadLine();
        }
        height = stringList.Count;
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                SpriteGameObject tile = DetermineGroundIndex(stringList, x, y);
                tile.Position = TilePosition(x, y);
                ObjectList.Add(tile);
            }
        }
    }

    //Determine the tiletype and the sheetindex of the underlying tile by checking the surrounding tiles.
    public SpriteGameObject DetermineGroundIndex(List<string> stringList, int x, int y)
    {
        floortileList = stringList;
        SpriteGameObject tile;
        bool north = false;
        bool east = false;
        bool south = false;
        bool west = false;
        bool nw = false;
        bool sw = false;
        bool se = false;
        bool ne = false;
        int index = 4;

        if (y != 0)
            north = (stringList[y][x] != stringList[y - 1][x]);
        if (y != verTiles - 1)
            south = (stringList[y][x] != stringList[y + 1][x]);
        if (x != horTiles - 1)
            east = (stringList[y][x] != stringList[y][x + 1]);
        if (x != 0)
            west = (stringList[y][x] != stringList[y][x - 1]);
        if (y != 0 && x != 0)
            nw = (stringList[y][x] != stringList[y - 1][x - 1]);
        if (y != verTiles - 1 && x != 0)
            sw = (stringList[y][x] != stringList[y + 1][x - 1]);
        if (y != verTiles - 1 && x != horTiles - 1)
            se = (stringList[y][x] != stringList[y + 1][x + 1]);
        if (y != 0 && x != horTiles - 1)
            ne = (stringList[y][x] != stringList[y - 1][x + 1]);

        string tileType;
        //TODO: string van maken
        if (stringList[y][x] == '.')
        {
            switch (GameData.CurrentFloor)
            {
                case 0:
                default:
                    tileType = "grass";
                    break;
                case 1:
                    tileType = "dirt";
                    break;
                case 2:
                    tileType = "stone";
                    break;
            }
            if (south && east)
                index = 8;
            else if (north && east)
                index = 2;
            else if (north && west)
                index = 0;
            else if (south && west)
                index = 6;
            else if (east)
                index = 5;
            else if (west)
                index = 3;
            else if (north)
                index = 1;
            else if (south)
                index = 7;
            else if (nw || ne || sw || se)
            {
                switch (GameData.CurrentFloor)
                {
                    case 0:
                    default:
                        tileType = "grassc";
                        break;
                    case 1:
                        tileType = "dirtc";
                        break;
                    case 2:
                        tileType = "stone";
                        break;
                }
                if (nw)
                    index = 3;
                else if (sw)
                    index = 1;
                else if (ne)
                    index = 2;
                else if (se)
                    index = 0;
            }
        }
        else
        {
            switch (GameData.CurrentFloor)
            {
                case 0:
                default:
                    tileType = "dirt";
                    break;
                case 1:
                    tileType = "stone";
                    break;
                case 2:
                    tileType = "infected";
                    break;
            }
            index = 4;
        }
        tile = new SpriteGameObject(tileType, index);
        return tile;
    }
}
