﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

class PuzzleRoomSimon : Room
{
    PressurePlate redPlate;
    PressurePlate bluePlate;
    PressurePlate greenPlate;
    PressurePlate yellowPlate;

    PressurePlate currentFlash;

    PressurePlate startPlate;

    List<PressurePlate> plateList;

    string sequence;
    string playerSeq;
    string phase;

    int seqCounter;
    int seqLength = 6;

    bool touching;

    //A PuzzleRoomSimon is a regular, empty room. However, it contains a puzzle, namely simon says, that must be completed
    //To unlock a special treasure room.
    //Simon says works as follows: A sequence is determined by the game, which is shown by flashing some plates. The player must reproduce
    //This sequence in order to finish the puzzle.
    public PuzzleRoomSimon(bool northD, bool eastD, bool southD, bool westD, string assetName, int sheetIndex, string id = "", int layer = 0)
        : base(true, true, true, true, "puzzleroom", 1, id, layer)
    {
        north = northD;
        east = eastD;
        south = southD;
        west = westD;
        sequence = "";
        seqCounter = 0;
        for (int i = 0; i < 4; i++)//Build a sequence that the player must follow.
        {
            sequence += R.Dice(4);
        }
        
        currentFlash = new PressurePlate("redplate", 0);

        plateList = new List<PressurePlate>();
        playerSeq = "";


    }

    public override void LoadNewRoom()
    {
        base.LoadNewRoom();
        //Add the pressureplates to the room, a red one, a blue one, a yellow one and a green one. Furthermore, add a startingplate,
        //which must be touched to start the puzzle.
        startPlate = new PressurePlate("redplate", 1, layer: 0, id: "pressureplate");
        startPlate.Position = new Vector2(14 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 7 * GameSettings.TileHeight);
        GameData.LevelObjects.Add(startPlate);
        redPlate = new PressurePlate("redplate", 1, layer:0, id: "pressureplate");
        redPlate.Position = new Vector2(11 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 4 * GameSettings.TileHeight);
        GameData.LevelObjects.Add(redPlate);
        bluePlate = new PressurePlate("blueplate", 1, layer: 0, id: "pressureplate");
        bluePlate.Position = new Vector2(17 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 4 * GameSettings.TileHeight);
        GameData.LevelObjects.Add(bluePlate);
        greenPlate = new PressurePlate("greenplate", 1, layer: 0, id: "pressureplate");
        greenPlate.Position = new Vector2(11 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 10 * GameSettings.TileHeight);
        GameData.LevelObjects.Add(greenPlate);
        yellowPlate = new PressurePlate("yellowplate", 1, layer: 0, id: "pressureplate");
        yellowPlate.Position = new Vector2(17 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 10 * GameSettings.TileHeight);
        GameData.LevelObjects.Add(yellowPlate);

        //Also add the pressureplates to the plateList, for further updating.
        plateList.Add(redPlate);
        plateList.Add(bluePlate);
        plateList.Add(greenPlate);
        plateList.Add(yellowPlate);
    }


    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        //If the player touches the startingplate before the puzzle starts, start the puzzle.
        if (GameData.GetPlayer.CollidesWith(startPlate) && phase != "do" && phase != "clear")
        {
            bool clear = true;
            foreach (GameObject obj in GameData.LevelObjects.Objects)
            {//The puzzle can't be started if there are enemies in the room. Thus, if there are enemies, don't start the puzzle
                if (obj is GeneralEnemy)
                    clear = false;
            }
            if (clear)
                phase = "show";
        }

        switch (phase)
        {
            case "show"://The phase where the predetermined sequence is shown to the player
                ShowSequence();
                break;
            case "do":
                MakePlayerSequence();//The phase where the player makes his or her own sequence
                break;
            case "clear":
                foreach (PressurePlate plate in plateList)
                    plate.Flash();//If the puzzle is cleared, flash all plates and remove the puzzledoors.
                for (int i = GameData.LevelObjects.Objects.Count - 1; i >= 0; i--)
                {
                    if (GameData.LevelObjects.Objects[i] is PuzzleDoor)
                        GameData.LevelObjects.Remove(GameData.LevelObjects.Objects[i]);
                }
                GameData.PuzzleSolved = true;
                break;
            default:
                break;
        }
    }

    void MakePlayerSequence()
    {
        if (playerSeq.Length == sequence.Length)
        {//if the length of the playersequence equals the length of the set sequence, check if it is correct.
            TurnOffAll();
            if (playerSeq == sequence)//if it is, and the sequence is not yet at maximum length, add a plate, and show again.
            {
                if (sequence.Length < seqLength)
                {
                    playerSeq = "";
                    sequence += R.Dice(4);
                    phase = "show";
                }
                else//if the sequence is at max length, set the phase to clear, so show that the puzzle is finished.
                {
                    foreach (PressurePlate plate in plateList)
                        plate.Flash();
                    phase = "clear";
                    return;
                }
            }
            else//if the sequence does not equal the player made sequence, spawn an enemy that must be killed first.
            {
                FEMelee FEMelee = new FEMelee(new Vector2(14 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 8 * GameSettings.TileHeight), 0, 100);
                GameData.LevelObjects.Add(FEMelee);
                phase = "";
                playerSeq = "";
            }
        }

        if (GameData.GetPlayer.CollidesWith(redPlate) && !touching)
        {//If the player touches one of the plates, a number is added to the playersequence.
            playerSeq += 1;
            touching = true;//This bool is used so that when a plate is touched, the number is only added once.
        }
        else if (GameData.GetPlayer.CollidesWith(bluePlate) && !touching)
        {
            playerSeq += 2;
            touching = true;
        }
        else if (GameData.GetPlayer.CollidesWith(greenPlate) && !touching)
        {
            playerSeq += 3;
            touching = true;
        }
        else if (GameData.GetPlayer.CollidesWith(yellowPlate) && !touching)
        {
            playerSeq += 4;
            touching = true;
        }

        if (touching)
            touching = IsTouchingPlate();//Check if the player is touching the plate. If he isn't, set touching to false.

        if (playerSeq != sequence.Substring(0, playerSeq.Length))
        {
            FEMelee FEMelee = new FEMelee(new Vector2(14 * GameSettings.TileWidth + GameSettings.GameFieldOffset, 8 * GameSettings.TileHeight), 0, 100);
            GameData.LevelObjects.Add(FEMelee);
            phase = "";
            playerSeq = "";
        }

    }

    bool IsTouchingPlate()
    {
        foreach (PressurePlate plate in plateList)
        {
            if (GameData.GetPlayer.CollidesWith(plate))
            {
                plate.Flash();
                return true;
            }
            else
                plate.TurnOff();
        }
        return false;
    }

    void TurnOffAll()
    {//set all plates to their off state.
        foreach (PressurePlate plate in plateList)
            plate.TurnOff();
    }

    void ShowSequence()
    {
        TurnOffAll();//First, turn off all plates.

        if (seqCounter == sequence.Length * 100)
        {//if the sequence is done with showing, set the phase to 'do', so let the player make the sequence.
            foreach (PressurePlate plate in plateList)
                plate.TurnOff();
            phase = "do";
            seqCounter = 0;
        }
        else if (seqCounter <= sequence.Length * 100 - 1)
        {
            int currentFlashing = int.Parse(sequence[seqCounter / 100].ToString());//Determine what plate should be flashing.
            switch (currentFlashing)
            {
                case 1:
                    currentFlash = redPlate;
                    break;
                case 2:
                    currentFlash = bluePlate;
                    break;
                case 3:
                    currentFlash = greenPlate;
                    break;
                case 4:
                    currentFlash = yellowPlate;
                    break;
                default:
                    break;
            }

            if (seqCounter % 100 < 80 && seqCounter % 100 > 10)
                currentFlash.Flash();//the plate should wait 10 tics until flashing, then flash 70 tics, then be off again for 20 tics.
            else
                currentFlash.TurnOff();

            seqCounter++;
        }
    }

    public string BonusRoomDirection(Point point)
    {//Determines what side the treasureroom should be made by checking if there are rooms available at any side.
        string dir = "";
        if (!FloorBuilder.allRoomsList.Contains(new Point(point.X + 1, point.Y)))
            dir = "east";
        else if (!FloorBuilder.allRoomsList.Contains(new Point(point.X - 1, point.Y)))
            dir = "west";
        else if (!FloorBuilder.allRoomsList.Contains(new Point(point.X, point.Y + 1)))
            dir = "south";
        else if (!FloorBuilder.allRoomsList.Contains(new Point(point.X, point.Y - 1)))
            dir = "north";
        return dir;
    }
}
