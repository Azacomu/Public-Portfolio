﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;

//Chest that the player can open by using a key to get a random weak item
class TreasureChest : SpriteGameObject
{
    bool opened = false;
    List<Point> taken;

    public TreasureChest() : base("treasureChest", 0, "treasureChest", 1)
    {
        taken = new List<Point>();
    }
    //Open the chest and put the items around the treasure chest.
    public void Open()
    {
        if (GameData.GetPlayer.Inventory.GetKeys >= 1)
        {
            CheckTakenPositions();
            int i = 0;
            List<Items> contains = DropTable.Treasure();
            for (int x = TileIndex.X - 1; (x <= TileIndex.X + 1 && i < contains.Count); x++)
            {
                for (int y = TileIndex.Y - 1; (y <= TileIndex.Y + 1 && i < contains.Count); y++)
                {
                    if (x == TileIndex.X && y == TileIndex.Y)
                        continue;
                    if (!taken.Contains(new Point(x, y)))
                    {
                        contains[i].Position = new Vector2(x * GameSettings.TileWidth + GameSettings.GameFieldOffset, y * GameSettings.TileHeight + GameSettings.GameFieldOffset);
                        GameData.LevelObjects.Add(contains[i]);
                        i++;
                    }
                }
            }
            opened = true;
            Sprite.SheetIndex = 1;
        }
        else
        {
            Notification description = new Notification("You have no keys!");
            description.CreateNotification();
        }
    }
    //Method to check the taken positions around the treasure chest.
    public void CheckTakenPositions()
    {
        taken = new List<Point>();
        List<SpriteGameObject> objects = GameData.FindNearbyTiles(this);
        for (int i = 0; i < objects.Count; i++)
        {
            if (objects[i].Solid == true || objects[i] is Player || objects[i] is Items)
                taken.Add(objects[i].TileIndex);
        }
    }
    //Update the item and open the chest if the player collides with it.
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        if (CollidesWith(GameData.GetPlayer) && !opened)
            Open();
    }
}
