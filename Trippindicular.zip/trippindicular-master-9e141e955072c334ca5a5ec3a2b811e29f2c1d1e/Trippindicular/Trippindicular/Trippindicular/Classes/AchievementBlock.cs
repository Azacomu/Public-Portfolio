﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

/// <summary>
/// This creates an achievement, this consists of a sprite with a title and description next to it.
/// </summary>
public class AchievementBlock : GUIGameObject
{
    protected SpriteGameObject icon;
    protected TextGameObject title, description;

    //Read and write variables
    public TextGameObject Title
    {
        get { return title; }
        set { title = value; }
    }

    public TextGameObject Description
    {
        get { return description; }
        set { description = value; }
    }

    public AchievementBlock(string assetName, int sheetIndex, string font, string font2, string id = "", int layer = 0) : base (assetName, sheetIndex)
    {
        //Achievement block starting values
        icon = new SpriteGameObject(assetName);

        title = new TextGameObject(font);
        title.Text = "";
        description = new TextGameObject(font2);
        description.Text = "";

        icon.Position = this.GlobalPosition;
        title.Position = this.GlobalPosition + new Vector2(icon.Width + 10, 2);
        description.Position = this.GlobalPosition + new Vector2(icon.Width + 10, 32);
    }

    public override void HandleInput(InputHelper ih)
    {
        base.HandleInput(ih);

        title.HandleInput(ih);
        description.HandleInput(ih);
    }

    //Reset positions
    public override void Reset()
    {
        base.Reset();

        title.Position = new Vector2(-1000, -1000);
        description.Position = new Vector2(-1000, -1000);
    }

    //Update positions
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        title.Position = this.GlobalPosition + new Vector2(icon.Width + 10, 2);
        description.Position = this.GlobalPosition + new Vector2(icon.Width + 10, 32);

        title.Update(gameTime);
        description.Update(gameTime);
    }

    //Draw text and sprite
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);

        title.Draw(gameTime, spriteBatch);
        description.Draw(gameTime, spriteBatch);
    }
}
