﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

/// <summary>
/// This class creates a dropdown with a specified background
/// </summary>
public class DropDown : GUIGameObject
{
    protected bool hover, drop;
    protected Vector2 startPos;
    protected int targetY, speed;

    //Read and write variables
    public bool Hover
    {
        get { return hover; }
        set { hover = value; }
    }

    public bool Drop
    {
        get { return drop; }
        set { drop = value; }
    }

    public int TargetY
    {
        get { return targetY; }
        set { targetY = value; }
    }

    public int Speed
    {
        get { return speed; }
        set { speed = value; }
    }


    public DropDown(string assetName, Vector2 startPosition, int sheetIndex = 0, string id = "", int layer = 0) : base(assetName, sheetIndex, id, layer)
    {
        //Starting values
        hover = false;
        targetY = 0;
        speed = 300;

        this.Position = startPosition;
        this.startPos = startPosition;
    }

    //Handle input
    public override void HandleInput(InputHelper inputHelper)
    {
        //Base
        base.HandleInput(inputHelper);

        //Handle input for dropdown
        if ((inputHelper.MouseInBox(this.BoundingBox) && inputHelper.MousePosition.Y > 0 || drop))
        {
            if (this.Position.Y < targetY)
            {
                this.Velocity = new Vector2(0, speed);
            }
            else
            {
                this.Velocity = Vector2.Zero;
            }
        }
        else
        {
            if (this.Position.Y > startPos.Y)
            {
                this.Velocity = new Vector2(0, -speed);
            }
            else
            {
                this.Velocity = Vector2.Zero;
            }
        }
    }

    //Reset position and state
    public override void Reset()
    {
        base.Reset();

        this.hover = false;
        this.Position = startPos;
    }

    //Update dropdown position
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        if (this.Position.Y > targetY)
        {
            this.Position = new Vector2(this.Position.X, targetY);
        }
    }

    //Draw dropdown
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
    }

    //Set start position
    public void Start()
    {
        this.Position = startPos;
    }
}