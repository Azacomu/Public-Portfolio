﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;

//This is the class of the player object, all actions and animations important for the player are here.
class Player : AnimatedGameObject
{
    //Constants, base values for multipliers and other stats.
    protected const float baseSpeed = 350;
    protected const int baseHealth = 6;
    protected const float baseDmgMult = 1.0f;
    protected const float baseAtckSpeedMult = 1.0f;
    protected const float baseMoveMult = 1.0f;

    protected string direction;
    protected Inventory inventory;
    protected Vector2 oldPos;
    protected SpriteSheet solidHitBox;
    protected SpriteSheet shieldSprite;
    protected float invincibleTime;
    protected bool attacking;
    protected bool frozen;
    protected bool moveSolid;

    //Player stats:
    protected int maxHealth;
    protected int curHealth;
    protected float damage;
    protected float movementSpeed;
    protected float attackSpeed;
    protected bool shielded;

    public string Direction
    {
        get { return direction; }
        set { direction = value; }
    }
    public Inventory Inventory
    {
        get { return inventory; }
        set { inventory = value; }
    }
    public bool Frozen
    {
        get { return frozen; }
        set { frozen = value; velocity = Vector2.Zero; }
    }
    public int MaxHealth
    {
        get { return maxHealth; }
        set { maxHealth = value; }
    }
    public bool MoveSolid
    {
        get { return moveSolid; }
        set { moveSolid = value; }
    }

    //Properties to get the player stats.
    public float Damage
    {
        get { return damage; }
        set { damage = value; }
    }
    public float MovementSpeed
    {
        get { return movementSpeed; }
        set { movementSpeed = value; }
    }
    public float AttackSpeed
    {
        get { return attackSpeed; }
        set { attackSpeed = value; }
    }
    public int CurHealth
    {
        get { return curHealth; }
        set { curHealth = value; }
    }

    //Initialization and loading all the animations.
    public Player() : base("Soren", 10)
    {
        position = new Vector2(15 * GameSettings.TileWidth, 7 * GameSettings.TileHeight);
        direction = "none";
        inventory = new Inventory();
        maxHealth = baseHealth;
        curHealth = maxHealth;
        invincibleTime = 0;

        damage = baseDmgMult;
        movementSpeed = baseSpeed * baseMoveMult;
        attackSpeed = baseAtckSpeedMult;

        LoadAnimation("playerNorth", "WalkUp", true, 0.15f);
        LoadAnimation("playerSouth", "WalkDown", true, 0.15f);
        LoadAnimation("playerSide", "WalkSide", true, 0.15f);
        LoadAnimation("idleUp", "IdleUp", false);
        LoadAnimation("idleDown", "IdleDown", false);
        LoadAnimation("idleSide", "IdleSide", false);
        LoadAnimation("playerStabNorth", "StabUp", false);
        LoadAnimation("playerStabSouth", "StabDown", false);
        LoadAnimation("playerStabSide", "StabSide", false);
        
        solidHitBox = new SpriteSheet("hitboxVert");
        shieldSprite = new SpriteSheet("shieldCircle");

        PlayAnimation("IdleDown");
    }    
    
    //Methods for powerups.
    public void HealthUp(){ maxHealth += 2; curHealth += 2; } //One more hearth health (1 hearth = 2 hp)
    public void SpeedUp() { movementSpeed *= 1.25f; }
    public void SpeedDown() { movementSpeed *= 0.85f; }
    public void DamageUp() { damage += 0.2f; }
    public void DamageDown() { damage -= 0.2f; }
    public void AttSpeedUp() { attackSpeed += 0.2f; }
    public void AttSpeedDown() { attackSpeed -= 0.15f; }

    //Powerdown 1 less hearth (-2hp).
    public void HealthDown()
    {
        maxHealth -= 2;
        if (curHealth > maxHealth)
            curHealth = maxHealth;
    }

    //Deals damage to the player.
    public void DealDamage(int value)
    {
        if (shielded)
        {
            shielded = false;
            return;
        }
        if (invincibleTime <= 0)
        {
            curHealth -= value;
            Invincible(0.5f);
        }
    }

    //Give the player a shield.
    public void Shield()
    {
        shielded = true;
    }

    //HandleInput does all the movement for the player and everything that belongs to that.
    public override void HandleInput(InputHelper ih)
    {
        if (!frozen && !attacking)
        {
            if (ih.IsKeyDown(Keys.Up, Keys.W))
            {
                velocity.Y = -movementSpeed;
                direction = "up";
                Mirror = false;
                PlayAnimation("WalkUp");
            }
            else if (ih.IsKeyDown(Keys.Down, Keys.S))
            {
                velocity.Y = movementSpeed;
                direction = "down";
                Mirror = false;
                PlayAnimation("WalkDown");
            }
            else
                velocity.Y = 0;

            if (ih.IsKeyDown(Keys.Left, Keys.A))
            {
                velocity.X = -movementSpeed;
                direction = "left";
                Mirror = true;
                PlayAnimation("WalkSide");
            }
            else if (ih.IsKeyDown(Keys.Right, Keys.D))
            {
                velocity.X = movementSpeed;
                direction = "right";
                Mirror = false;
                PlayAnimation("WalkSide");
            }
            else
                velocity.X = 0;
        }
        inventory.HandleInput(ih);

        //Change animation based on walking direction.
        if (velocity == Vector2.Zero && !attacking)
        {
            switch (direction)
            {
                case "up":
                    PlayAnimation("IdleUp");
                    break;
                case "down":
                    PlayAnimation("IdleDown");
                    break;
                case "left":
                case "right":
                    PlayAnimation("IdleSide");
                    break;
                default:
                    PlayAnimation("IdleDown");
                    break;
            }
        }
        
    }

    //Update method looks for collisions between the player and other objects and handles accordingly.
    public override void Update(GameTime gameTime)
    {
        if (curHealth <= 0)
            Die();

        if (sprite != null)
            Current.Update(gameTime);

        inventory.Update(gameTime);

        oldPos = position;

        //Check each velocity type alone.
        if (velocity.X != 0 && velocity.Y != 0)
        {
            Vector2 temp = velocity;
            velocity = new Vector2(temp.X, 0);
            base.Update(gameTime);
            if (solidCollision && !moveSolid)
                position = oldPosition;
            velocity = new Vector2(0, temp.Y);
            base.Update(gameTime);
            if (solidCollision && !moveSolid)
                position = oldPosition;
        }
        else
        {
            base.Update(gameTime);
            if (solidCollision && !moveSolid)
                position = oldPosition;
        }
        invincibleTime -= (float)gameTime.ElapsedGameTime.TotalSeconds;
        
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        if (shielded)
            shieldSprite.Draw(spriteBatch, Position, origin);

        inventory.Draw(gameTime, spriteBatch);

        DrawTesting.DrawHitbox(spriteBatch, BoundingBox, Color.Blue);
    }

    //Player can't be hit for x seconds.
    public void Invincible(float timeInSeconds)
    {
        invincibleTime = timeInSeconds;
    }

    //Resets the save file and switches the state to game over.
    public void Die()
    {
        Console.WriteLine("You died!");
        position = new Vector2(GameSettings.GameWidth / 2, GameSettings.GameHeight / 2);
        frozen = true;
        PlayingState.SaveGame.DeleteSave();
        GameWorld.AssetLoader.PlayMusic("gameovermusic");
        MediaPlayer.IsRepeating = false;
        GameWorld.GameStateManager.SwitchTo("gameOver");
        MainGame.AchievementController.FinishAchievement("First of Many");
    }

    //Method used to play the attack animation when attacking.
    public void Attack()
    {
        velocity = Vector2.Zero;
        attacking = true;
        switch(direction)
        {
            case "up":
                PlayAnimation("StabUp");
                break;
            case "down":
                PlayAnimation("StabDown");
                break;
            case "left":
            case "right":
                PlayAnimation("StabSide");
                break;
            default:
                PlayAnimation("StabDown");
                break;
        }
        
    }
    //Method to stop the attack.
    public void StopAttack()
    {
        attacking = false;
    }
}

