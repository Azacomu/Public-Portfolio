﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.IO;

//Struct used for passing achievements for drawing (Menu's, overlays).
public struct Achievement
{
    public string Name;
    public string Info;
    public bool Finished;
}
//Class used for getting and loading achievements.
public class Achievements : FileLoader
{
    protected List<string[]> achievementList;
    protected string path;

    public Achievements(string path) : base(path)
    {
        this.path = path;
        achievementList = new List<string[]>();
        
        foreach (string s in text)
            achievementList.Add(s.Split('-'));
    }
    //Returns the full array of all parts of the achievement that is search for.
    public string[] Find(string achievement)
    {
        foreach (string[] s in achievementList)
        {
            if (s[0] == achievement)
                return s;
        }
        Log.Write(LogType.WARNING, "Warning, the requested achievement doesn't exist. " + achievement);
        return null;
    }
    //Returns the info of the achievment with the name 'achievement'.
    public string GetInfo(string achievement)
    {
        string[] s = Find(achievement);
        if (s == null)
            return "";
        return s[1];
    }
    //Returns if the given achievement had been finished yet.
    public bool GetFinished(string achievement)
    {
        string[] s = Find(achievement);
        if (s == null)
            return false;
        return bool.Parse(s[2]);
    }
    //Makes a list of all achievements and their status.
    public List<Achievement> GetAchievementList()
    {
        List<Achievement> achList= new List<Achievement>();
        for (int i = 0; i < achievementList.Count; i++)
        {
            achList.Add(new Achievement {Name = achievementList[i][0], Info = achievementList[i][1], Finished = bool.Parse(achievementList[i][2]) });
        }
        return achList;
    }
    //Gives you a certain achievement and then saves it to the file.
    public void FinishAchievement(string achievement)
    {
        //If you already have the achievement, or the achievement doesn't exist, return.
        if (GetFinished(achievement) || GetInfo(achievement) == "")
            return;
        for(int i = 0; i < achievementList.Count; i++)
        {
            if (achievementList[i][0] == achievement)
            {
                achievementList[i][2] = true.ToString();
                SpriteSheet dummy = new SpriteSheet("achievementGet");
                AchievementGet ach = new AchievementGet("achievementGet", new Vector2(GameSettings.GameWidth - 1.2f * dummy.Width,  -dummy.Height), i);
                HUD hud = GameWorld.GameStateManager.GetGameState("hud") as HUD;
                hud.hud.Add(ach);
            }
        }
        SaveAchievements();
    }
    //Saves achievement to the file.
    public void SaveAchievements()
    {
        try
        {
            StreamWriter writer = new StreamWriter(path, false);
            for (int i = 0; i < achievementList.Count; i++)
            {
                string line = achievementList[i][0] + "-" + achievementList[i][1] + "-" + achievementList[i][2];
                writer.WriteLine(line);
            }
            writer.Close();
        }
        catch (Exception e)
        {
            Log.Write(LogType.ERROR, "Error saving achievements to file: " + e.Message);
        }
    }
}

