﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

class ShopItem : SpriteGameObject
{
    public int price;
    public Items item;

    public ShopItem(Vector2 position, Items item, int price, string assetName = "", int sheetIndex = 0, string id = "", int layer = 3) : base(assetName, sheetIndex, id, layer)
    {
        this.price = price;
        this.item = item;
        sprite = new SpriteSheet(item.AssetName, 0);
        this.position = position;

        TextGameObject priceText = new TextGameObject("font", 5);
        priceText.Text = price.ToString();
        priceText.Position = position + new Vector2(GameSettings.GameFieldOffset - (priceText.Size.X/2), 64);
        GameData.LevelObjects.Add(priceText);
    }

    public void BuyItem()
    {
        GameData.GetPlayer.Inventory.GetCoins -= price;
        item.Position = position + new Vector2(GameSettings.GameFieldOffset, GameSettings.GameFieldOffset);
        GameData.LevelObjects.Add(item);
        GameData.LevelObjects.Remove(this);
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        if (GameData.GetPlayer.CollidesWith(this) && GameData.GetPlayer.Inventory.GetCoins >= price)
        {
            BuyItem();
        }
    }
}
