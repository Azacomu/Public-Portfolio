﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

class Shop : SpriteGameObject
{
     
    public Shop(Vector2 position, string assetName, int sheetIndex, string id = "", int layer = 0) : base("shop", 1, id, layer)
    {
        this.position = position;
        DetermineStock();
    }

    void DetermineStock()
    {
        for (int i = 0; i < 4; i++)
        {
            AddItemToStock(i);
        }
    }

    void AddItemToStock(int i)
    {
        ShopItem item;
        Vector2 pos = this.position;
        switch (i)
        {
            case 0:
            default:
                pos.X -= 3 * GameSettings.TileWidth;
                break;
            case 1:
                pos.X += 3 * GameSettings.TileWidth;
                break;
            case 2:
                pos.Y += 3 * GameSettings.TileHeight;
                break;
            case 3:
                pos.Y -= 3 * GameSettings.TileHeight;
                break;
        }

        switch (R.Dice(12))
        {
            case 1:
            default:
                item = new ShopItem(pos, new KnockBackScroll(), 2);
                break;
            case 2:
                item = new ShopItem(pos, new PetSkunk(), 10);
                break;
            case 3:
                item = new ShopItem(pos, new CircleOfFire(), 4);
                break;
            case 4:
                item = new ShopItem(pos, new MysteryPotion(), 2);
                break;
            case 5:
                item = new ShopItem(pos, new CrystalArrow(), 10);
                break;
            case 6:
                item = new ShopItem(pos, new TheDoubleTeam(), 10);
                break;
            case 7:
                item = new ShopItem(pos, new Boomerang(), 5);
                break;
            case 8:
                item = new ShopItem(pos, new Bomb(), 1);
                break;
            case 9:
                item = new ShopItem(pos, new Key(), 1);
                break;
            case 10:
                item = new ShopItem(pos, new Laginator(), 10);
                break;
            case 11:
                item = new ShopItem(pos, new NinjaHeadband(), 5);
                break;
            case 12:
                item = new ShopItem(pos, new SecondWand(), 10);
                break;
        }
        GameData.LevelObjects.Add(item);
    }
}
