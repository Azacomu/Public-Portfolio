﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Class for the Coin item, adds a coin to the inventory when picked up.
class Coin : Items
{

    public Coin(string itemtype = "Stackable", int layer = 0, string id = "coin") : base(itemtype, "coin", 0, id)
    {
        this.sprite.Scale = 0.6f;
        ItemDescription = "   Coins +1";
        itemName = "";
    }
    public override void PickUp()
    {
        if (GameData.GetPlayer.Inventory.GetCoins < 99)
        {
            GameWorld.AssetLoader.PlaySound("coinPickup");
            GameData.AddCoin();
            base.PickUp();
        }
    }
}