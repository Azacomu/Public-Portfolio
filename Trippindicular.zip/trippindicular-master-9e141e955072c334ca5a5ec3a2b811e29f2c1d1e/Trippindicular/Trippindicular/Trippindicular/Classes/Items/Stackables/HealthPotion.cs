﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Class for HealthPotion item, when used increases the player's currenthealth
class HealthPotion : Items
{

    public HealthPotion(string itemtype = "Stackable", int layer = 0, string id = "healthPotion") : base(itemtype, "healthPotion", 0, id)
    {
        ItemDescription = "Health Potions +1";
        itemName = "";
    }
    public override void UseItem()
    {
        if (GameData.GetPlayer.Inventory.GetHealthPotions > 0)
        {
            base.UseItem();
            if (GameData.GetPlayer.CurHealth == GameData.GetPlayer.MaxHealth)
                return;
            else if (GameData.GetPlayer.CurHealth <= GameData.GetPlayer.MaxHealth - 2)
            {
                GameData.GetPlayer.CurHealth += 2;
            }
            else
            {
                GameData.GetPlayer.CurHealth += 1;
            }
            GameWorld.AssetLoader.PlaySound("usePotion");
            GameData.GetPlayer.Inventory.GetHealthPotions -= 1;
        }
        else
        {
            Notification noHealthPots = new Notification("You have 0 health potions","","",1.5f);
            noHealthPots.CreateNotification();
        }
    }
    public override void PickUp()
    {
        if (GameData.GetPlayer.Inventory.GetHealthPotions < 99)
        {
            base.PickUp();
            //play sound 
        }
    }

}