﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the Bomb item, which creates a BombSpr gameobject when used.
class Bomb : Items
{

    public Bomb(string itemtype = "Stackable", int layer = 0, string id = "bomb") : base(itemtype, "bomb", 0, id)
    {
        ItemDescription = "Bombs +1";
        itemName = "";
    }
    public override void UseItem()
    {
        base.UseItem();
        BombSpr bomb = new BombSpr();
        bomb.Position = GameData.GetPlayer.GlobalPosition - new Vector2(0, GameData.GetPlayer.Sprite.Center.Y);
        GameData.LevelObjects.Add(bomb);
        GameData.GetPlayer.Inventory.GetBombs -= 1;
    }
    public override void PickUp()
    {
        if (GameData.GetPlayer.Inventory.GetBombs < 99)
        {
            base.PickUp();
        }
    }
} 