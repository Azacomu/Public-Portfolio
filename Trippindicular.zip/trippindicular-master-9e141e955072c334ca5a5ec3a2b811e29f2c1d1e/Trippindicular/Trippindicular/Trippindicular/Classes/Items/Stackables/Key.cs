﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Class for the Key item, adds a Key to the inventory.
class Key : Items
{

    public Key(string itemtype = "Stackable", int layer = 0, string id = "key") : base(itemtype, "key", 0, id)
    {
        ItemDescription = "Keys +1";
        itemName = "";
    }

    public override void PickUp()
    {
        if (GameData.GetPlayer.Inventory.GetKeys < 99)
        {
            base.PickUp();
        }
    }
}
