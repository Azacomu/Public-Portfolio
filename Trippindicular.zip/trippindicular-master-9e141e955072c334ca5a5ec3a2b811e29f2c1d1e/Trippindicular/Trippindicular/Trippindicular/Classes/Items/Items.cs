﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

// General class for items, all items inherit from this class, manages things like moving it to the inventory and introduces properties for the items
// Also displays an item description upon pickup
class Items : SpriteGameObject
{
    protected const float dropTimerTime = 0.75f;
    protected string itemtype;
    protected string assetName;
    protected bool equipped;
    protected bool equippable;
    protected bool hasbeenused;
    protected double cooldown;
    protected double cooldowntimer;
    protected double droptimer;
    protected float bounce;
    protected bool isBouncing;
    protected string itemDescription;
    protected string itemDescription2;
    protected string itemName;
    protected Timer dropDownTimer;

    //Item description line 1
    public string ItemDescription
    {
        get { return itemDescription; }
        set { itemDescription = value; }
    }
    //Item description line 2
    public string ItemDescription2
    {
        get { return itemDescription2; }
        set { itemDescription2 = value; }
    }
    //string used for the item description
    public string ItemName => itemName;
    //Cooldown after which the item can be used again
    protected double Cooldown
    {
        get { return cooldown; }
        set { cooldown = value; }
    }
    //Used to set equippable to true after a while
    public double DropTimer
    {
        get { return droptimer; }
        set { droptimer = value; }
    }
    //Used for the cooldown
    public double CooldownTimer
    {
        get { return cooldowntimer; }
        set { cooldowntimer = value; }
    }

    //string to determine the itemtype, used for adding an item to the inventory
    public string ItemType => itemtype;

    //bool to see if the item is equipped or on the floor
    public bool Equipped
    {
        get { return equipped; }
        set { equipped = value; }
    }
    //bool for the item moving up and down or not
    public bool IsBouncing
    {
        get { return isBouncing; }
        set { isBouncing = value; }
    }
    //bool if the item can be picked up or not
    public bool Equippable
    {
        get { return equippable; }
        set { equippable = value; }
    }
    //bool to see if the item is off cooldown
    public bool IsOffCooldown => (this.CooldownTimer > (this.Cooldown / GameData.GetPlayer.AttackSpeed));

    // bool for consumables since they can only be used once.   
    public bool HasBeenUsed
    {
        get { return hasbeenused; }
        set { hasbeenused = value; }
    }
    //Assetname
    public string AssetName => assetName;

    public Items(string itemtype, string assetName, int sheetIndex = 0, string id = "", int layer = 1) : base(assetName, sheetIndex, id, layer)
    {
        this.itemtype = itemtype;
        this.assetName = assetName;
        itemDescription = "";
        itemDescription2 = "";
        itemName = "";
        equipped = false;
        equippable = true;
        hasbeenused = false;
        isBouncing = true;
        cooldown = 0;
        cooldowntimer = 0;
        droptimer = 0;
        this.Origin = this.sprite.Center;
        dropDownTimer = new Timer(1f);
        dropDownTimer.Pause();
    }

    //Sets equippable to true after a delay if an item has just been dropped(else it would instantly get picked up again) and handles collision
    // Also takes care of moving the item bar back up after a while
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        if (isBouncing)
        {
            Bounce(gameTime);
        }
        dropDownTimer.Update(gameTime);
        if (dropDownTimer.Ended)
        {
            IGameLoopObject temp = GameWorld.GameStateManager.GetGameState("hud");
            HUD hud = temp as HUD;
            hud.Down = false;
            dropDownTimer.Reset();
            dropDownTimer.Pause();
        }
        this.CooldownTimer += gameTime.ElapsedGameTime.TotalSeconds;
        if (!this.Equipped)
        {
            if (!this.Equippable)
            {
                this.DropTimer += gameTime.ElapsedGameTime.TotalSeconds;
                if (this.DropTimer > dropTimerTime)
                {
                    this.Equippable = true;
                }
                if ((this.DropTimer % 0.25) < 0.05)
                {
                    this.Visible = false;
                }
                else this.Visible = true;
            }
            else
            {
                if (this.CollidesWith(GameData.GetPlayer) && this.Visible && this.Equippable && !Equipped)
                {
                    this.PickUp();
                }
                this.Visible = true;
            }
        }
    }

    //Virtual method for using an item
    public virtual void UseItem()
    {
        this.CooldownTimer = 0;
    }

    //Pick up item, create a notification with the item description on screen, drop down the item bar to see your picked up item. 
    //Sets cooldowntimer to cooldown so that it can be used instantly on pickup
    public virtual void PickUp()
    {
        CooldownTimer = Cooldown;
        GameData.GetPlayer.Inventory.AddItem(this);
        Notification description = new Notification(ItemName, ItemDescription, ItemDescription2);
        description.CreateNotification();
        this.MoveToHUD(1);
        if (!(this is Coin || this is HealthPotion || this is Key || this is Bomb||this is MysteryPotion))
        {
            dropDownTimer.Reset();
            IGameLoopObject temp = GameWorld.GameStateManager.GetGameState("hud");
            HUD hud = temp as HUD;
            hud.Down = true;
        }
        GameData.LevelObjects.Remove(this);
    }

    // Method for moving the item sprite into the correct inventory slot(used in AddItem method in Inventory.cs)
    public void MoveToHUD(int slot)
    {
        this.position = new Vector2(-5000, 64 + 74 * slot);
    }
    //Method for bouncing items up and down animation
    protected void Bounce(GameTime gameTime)
    {
        double t = gameTime.TotalGameTime.TotalSeconds * 3.0f + Position.X;
        bounce = (float)Math.Sin(t) * 0.2f;
        this.position.Y += bounce;
    }
}


