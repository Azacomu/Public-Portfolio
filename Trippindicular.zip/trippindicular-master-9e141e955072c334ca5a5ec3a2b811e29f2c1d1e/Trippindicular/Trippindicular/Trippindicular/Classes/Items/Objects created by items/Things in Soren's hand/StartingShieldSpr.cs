﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the Shield sprite near the player, this just draws a shield on the player.
class StartingShieldSpr : SpriteGameObject
{

    public StartingShieldSpr(string id = "startingshieldspr") : base("woodenShield", 0, id)
    {
        this.sprite.Scale = 0.4f;
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        UpdatePosition();
    }
    //Position and visibility changes depending on the direction the player is facing.
    //Is currently not visible in any other direction than down because rotating the shield so that it is viewed from the side or back is impossible.
    protected void UpdatePosition()
    {

        if (GameData.GetPlayer.Direction == "left")
        {
            this.Visible = false;
        }

        else if (GameData.GetPlayer.Direction == "right")
        {
            this.Visible = false;
        }
        else if (GameData.GetPlayer.Direction == "up")

        {
            this.Visible = false;
        }
        else if (GameData.GetPlayer.Direction == "down")
        {
            this.Visible = true;
            this.Position = GameData.GetPlayer.Position - new Vector2(5, 40);
        }

    }
}


