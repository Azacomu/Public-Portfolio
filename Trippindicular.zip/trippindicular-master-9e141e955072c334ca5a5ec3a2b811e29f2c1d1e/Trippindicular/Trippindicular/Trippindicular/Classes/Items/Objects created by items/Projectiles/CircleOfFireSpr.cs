﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the Fire sprite created by the CircleOfFire spellscroll, very basic projectile, wont be slowed down near end of range.
class CircleOfFireSpr : Projectile
{
    public CircleOfFireSpr() : base("fire", 0, "circleoffirespr")
    {
        this.Damage = 10;
        this.Speed = 300f;
        this.Range = 500;
        this.Sprite.Scale = 0.6f;
        this.CanBeSlowed = false;      
    }
    //Basic projectile update.
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
    }
}

