﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the StartingBow sprite near the player, this just gives the assetName of the correct sprite to WeaponsInHand and sets 
//the correct rotationOffset.
class StartingBowSpr : WeaponsInHand
{


    public StartingBowSpr(string id = "startingbowspr") : base("bow", id)
    {
        this.sprite.Scale = 0.55f;
        this.rotationOffset = -0.25;
        this.positionOffset = new Vector2(10, 12);
    }

}