﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for WoodArrow sprite created by WoodArrow.cs, basic projectile
class WoodArrowSpr : Projectile
{
    protected Bow bow;
    public WoodArrowSpr() : base("arrow")
    {
        this.Speed = 500f;
        GameWorld.AssetLoader.PlaySound("arrowFire");
        bow = GameData.GetPlayer.Inventory.GetItem(0) as Bow;
        this.Damage = 1 + bow.Damage;
        this.sprite.Scale = 0.8f;
    }
}

