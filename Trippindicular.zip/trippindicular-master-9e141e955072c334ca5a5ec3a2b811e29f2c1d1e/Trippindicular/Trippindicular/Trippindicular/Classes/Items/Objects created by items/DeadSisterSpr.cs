﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
// class for the DeadSister sprite that is created by the Azalea item, has a method for following the player, checking to see if an enemy
//is within the shootRadius, and for shooting a projectile in that enemy's direction
class DeadSisterSpr : Items
{
    protected double followRadius;
    protected double walkingSpeed;
    protected double shootRadius;
    protected bool isFollowingPlayer;
    Vector2 ppos;
    WoodenBow weaponForRange;
    InputHelper ih;
    Vector2 previousPlayerPosition;
    Vector2 currentPlayerPosition;

    public DeadSisterSpr(string ItemType = "PowerUp", string assetname = "azalea", string id = "azalea", int layer = 0) : base(ItemType, assetname, 0, id, layer)
    {
        followRadius = 200;
        walkingSpeed = 300;
        shootRadius = 400;
        isFollowingPlayer = true;
        this.Cooldown = 3.0;
        isBouncing = false;
        ih = new InputHelper();
        weaponForRange = new WoodenBow();
        previousPlayerPosition = GameData.GetPlayer.GlobalPosition;
        //player GlobalPosition
        ppos = GameData.GetPlayer.GlobalPosition;
    }

    //Follows player, checks for targets, checks if the enemy moves to the next room, bounces when standing still
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        StartFollowingPlayer();
        CheckForTargets();
        CheckForNextRoom();
        Bouncing();
    }

    //Method for following the player.
    protected void StartFollowingPlayer()
    {
        ppos = GameData.GetPlayer.GlobalPosition;
        if (Math.Sqrt(Math.Pow((ppos.X - this.GlobalPosition.X), 2) + Math.Pow((ppos.Y - this.GlobalPosition.Y), 2)) >= this.followRadius && isFollowingPlayer == false)
        {
            float differenceXPos = Math.Abs(GameData.GetPlayer.GlobalPosition.X - this.GlobalPosition.X);
            float differenceYPos = Math.Abs(GameData.GetPlayer.GlobalPosition.Y - this.GlobalPosition.Y);
            float xvelocity = 0;
            float yvelocity = 0;
            double angle = 0;
            angle = Math.Atan((differenceXPos / differenceYPos));
            xvelocity = (float)(Math.Sin(angle) * walkingSpeed);
            yvelocity = (float)(Math.Cos(angle) * walkingSpeed);
            if (GameData.GetPlayer.GlobalPosition.X + GameData.GetPlayer.Width / 2 > this.GlobalPosition.X + this.Width / 2)
            {
                if (GameData.GetPlayer.GlobalPosition.Y < this.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(xvelocity, -yvelocity);
                }
                else if (GameData.GetPlayer.GlobalPosition.Y > this.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(xvelocity, yvelocity);
                }
            }
            else if (GameData.GetPlayer.GlobalPosition.X + GameData.GetPlayer.Width / 2 < this.GlobalPosition.X + this.Width / 2)
            {
                if (GameData.GetPlayer.GlobalPosition.Y < this.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(-xvelocity, -yvelocity);
                }
                else if (GameData.GetPlayer.GlobalPosition.Y > this.GlobalPosition.Y)
                {
                    this.Velocity = new Vector2(-xvelocity, yvelocity);
                }

            }
        }
        else
        {
            isFollowingPlayer = false;
            this.Velocity = Vector2.Zero;
        }
    }

    //For all enemies, sees if they are within the shootRadius, if so, shoots a projectile in their direction
    protected void CheckForTargets()
    {
        for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
            if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
            {
                GeneralEnemy enemy = GameData.LevelObjects.Objects[i] as GeneralEnemy;
                if ((Math.Sqrt(Math.Pow((this.GlobalPosition.X - enemy.Position.X), 2) + Math.Pow((this.GlobalPosition.Y - enemy.Position.Y), 2)) < this.shootRadius) && IsOffCooldown)
                {
                    ShootProjectile(enemy);
                    CooldownTimer = 0;
                }
            }
    }
    //Method for shooting a projectile towards an enemy, slightly predicting their movement
    protected void ShootProjectile(GeneralEnemy enemy)
    {
        DeadSisterProjectile projectile = new DeadSisterProjectile();
        projectile.Position = this.GlobalPosition;
        projectile.StartingPosition = this.GlobalPosition;
        projectile.AddToList(projectile);
        float differenceXPos = Math.Abs(enemy.GlobalPosition.X+enemy.Velocity.X*0.3f - this.GlobalPosition.X);
        float differenceYPos = Math.Abs(enemy.GlobalPosition.Y+enemy.Velocity.Y*0.3f - this.GlobalPosition.Y);
        float xvelocity = 0;
        float yvelocity = 0;
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        xvelocity = (float)(Math.Sin(angle) * projectile.Speed);
        yvelocity = (float)(Math.Cos(angle) * projectile.Speed);
        if (enemy.GlobalPosition.X + enemy.Width / 2 > this.GlobalPosition.X + this.Width / 2)
        {
            if (enemy.GlobalPosition.Y < this.GlobalPosition.Y)
            {
                projectile.Velocity = new Vector2(xvelocity, -yvelocity);
            }
            else if (enemy.GlobalPosition.Y > this.GlobalPosition.Y)
            {
                projectile.Velocity = new Vector2(xvelocity, yvelocity);
            }
        }
        else if (enemy.GlobalPosition.X + enemy.Width / 2 < this.GlobalPosition.X + this.Width / 2)
        {
            if (enemy.GlobalPosition.Y - 30 < this.GlobalPosition.Y)
            {
                projectile.Velocity = new Vector2(-xvelocity, -yvelocity);
            }
            else if (enemy.GlobalPosition.Y > this.GlobalPosition.Y)
            {
                projectile.Velocity = new Vector2(-xvelocity, yvelocity);
            }
        }
    }

    //If the player moves to the next room this returns to the player position again
    protected void CheckForNextRoom()
    {
        currentPlayerPosition = GameData.GetPlayer.GlobalPosition;
        if (previousPlayerPosition.X - currentPlayerPosition.X > 400 || previousPlayerPosition.X - currentPlayerPosition.X < -400
             || previousPlayerPosition.Y - currentPlayerPosition.Y < -400 || previousPlayerPosition.Y - currentPlayerPosition.Y > 400)
        {
            this.Position = GameData.GetPlayer.GlobalPosition;
        }
        previousPlayerPosition = GameData.GetPlayer.GlobalPosition;
    }
    //When this is standing still, move it up and down
    protected void Bouncing()
    {
        if (Velocity == Vector2.Zero)
        {
            isBouncing = true;
        }
        else isBouncing = false;
    }
}

