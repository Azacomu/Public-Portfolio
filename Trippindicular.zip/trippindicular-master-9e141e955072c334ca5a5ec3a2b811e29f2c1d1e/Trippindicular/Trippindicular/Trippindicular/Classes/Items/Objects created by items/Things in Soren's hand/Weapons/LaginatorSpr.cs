﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the Laginator sprite near the player, this just gives the assetName of the correct sprite to WeaponsInHand
class LaginatorSpr : WeaponsInHand
{

    public LaginatorSpr(string id = "laginatorspr") : base("laginator", id)
    {
    }

}


