﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for SecondWandProjectile created by SecondWand, seeks out an enemy and homes towards it
class SecondWandProjectile : Projectile
{
    protected double homingRadius;
    protected int counter;
    GeneralEnemy targetedEnemy;
    public SecondWandProjectile() : base("blueFire", 0, "secondwandprojectile")
    {
        this.Speed = 500f;
        Weapon wand = GameData.GetPlayer.Inventory.GetItem(0) as Weapon;
        this.Damage = wand.Damage;
        this.sprite.Scale = 1.5f;
        this.homingRadius = 170;
        this.counter = 0;
        this.CanBeSlowed = false;
    }

    //Homes towards an enemy once a target is found
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        SearchOutEnemy();
        if (counter == 1)
            HomeTowardsEnemy(targetedEnemy);       
    }
    //Searches out an enemy to home towards, once an enemy is targeted it stops searching and will move towards that enemy
    protected void SearchOutEnemy()
    {
        if (counter == 0)
        {
            for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
            {
                if (counter == 1)
                    return;
                if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
                {
                    GeneralEnemy enemy = GameData.LevelObjects.Objects[i] as GeneralEnemy;
                    if (Math.Sqrt(Math.Pow((this.GlobalPosition.X - enemy.Position.X), 2) + Math.Pow((this.GlobalPosition.Y - enemy.Position.Y), 2)) < this.homingRadius)
                    {
                        this.Range += 100;
                        targetedEnemy = enemy;
                        this.counter = 1;
                    }
                }
            }
        }
        else if (targetedEnemy == null || targetedEnemy.EnemyHealth <= 0 || !targetedEnemy.Visible)
        {
            counter = 0;
        }
    }
    //Home towards the given enemy
    protected void HomeTowardsEnemy(GeneralEnemy enemy)
    {
        float differenceXPos = Math.Abs(enemy.GlobalPosition.X - this.GlobalPosition.X);
        float differenceYPos = Math.Abs(enemy.GlobalPosition.Y - this.GlobalPosition.Y);
        float xvelocity = 0;
        float yvelocity = 0;
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        xvelocity = (float)(Math.Sin(angle) * this.Speed);
        yvelocity = (float)(Math.Cos(angle) * this.Speed);
        if (enemy.GlobalPosition.X > this.GlobalPosition.X )
        {
            if (enemy.GlobalPosition.Y < this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(xvelocity, -yvelocity);
            }
            else if (enemy.GlobalPosition.Y > this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(xvelocity, yvelocity);
            }
        }
        else if (enemy.GlobalPosition.X < this.GlobalPosition.X)
        {
            if (enemy.GlobalPosition.Y < this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(-xvelocity, -yvelocity);
            }
            else if (enemy.GlobalPosition.Y > this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(-xvelocity, yvelocity);
            }

        }
    }
    //Adjusts the rotation based on velocity
    protected override void AdjustRotation()
    {
        float differenceXPos = Math.Abs(this.Velocity.X);
        float differenceYPos = Math.Abs(this.Velocity.Y);
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        if (this.Velocity.X == 0)
        {
            if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = 0;
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)Math.PI;
            }
        }
        else if (this.Velocity.X > 0)
        {
            if (this.Velocity.Y == 0)
            {
                this.sprite.Rotation = (float)(Math.PI * -0.5);
            }
            else if (this.Velocity.Y > 0)
            {
               this.sprite.Rotation = (float)((Math.PI * 1.5) + angle);
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)(angle + (Math.PI));
            }
        }
        else if (this.Velocity.X < 0)
        {
            if (this.Velocity.Y == 0)
            {
                this.sprite.Rotation = (float)(Math.PI * 0.5);
            }
            else if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)(angle);
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)((-angle) + (Math.PI));
            }
        }
    }
}

