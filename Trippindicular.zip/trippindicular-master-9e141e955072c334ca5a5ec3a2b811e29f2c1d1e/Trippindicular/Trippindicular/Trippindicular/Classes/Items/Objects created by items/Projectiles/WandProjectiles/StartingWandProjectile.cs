﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for StartingWandProjectile sprite created by StartingWand.cs, basic projectile.
class StartingWandProjectile : Projectile
{

    public StartingWandProjectile() : base("redFlame", 0, "startingwandprojectile")
    {
        this.Speed = 500f;
        Weapon wand = GameData.GetPlayer.Inventory.GetItem(0) as Weapon;
        this.Damage = wand.Damage;
        this.sprite.Scale = 1.5f;
    }
    protected override void AdjustRotation()
    {
        float differenceXPos = Math.Abs(this.Velocity.X);
        float differenceYPos = Math.Abs(this.Velocity.Y);
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        if (this.Velocity.X == 0)
        {
            if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = 0;
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)Math.PI;
            }
        }
        else if (this.Velocity.X > 0)
        {
                this.sprite.Rotation = (float)(Math.PI * -0.5);
        }
        else if (this.Velocity.X < 0)
        {
                this.sprite.Rotation = (float)(Math.PI * 0.5);
        }
    }
}

