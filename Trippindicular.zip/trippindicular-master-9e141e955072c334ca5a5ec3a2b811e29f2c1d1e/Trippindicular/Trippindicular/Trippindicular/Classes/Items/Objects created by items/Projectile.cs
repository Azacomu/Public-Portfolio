﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//General Projectile class of which all projectiles from the player  inherit from, has methods for slowing down the projectile, adjusting rotation
//based on velocity, general enemy collision, itemeffect upon hitting an enemy, shooting one or two projectiles, getting a random direction
//and detecting collision with solid objects.
class Projectile : AnimatedGameObject
{
    protected const float knockbackTimer = 0.15f;
    protected double range;
    protected bool canBeSlowed;
    protected float xSlow;
    protected float ySlow;
    protected float damage;
    protected string animationId;
    protected float speed;
    protected Vector2 startingposition;
    protected GameObjectList projectileList;
    Vector2 pPos;
    public float Speed
    {
        get { return speed; }
        set { speed = value; }
    }
    public float Damage
    {
        get { return damage * GameData.GetPlayer.Damage; }
        set { damage = value; }
    }
    public double Range
    {
        get { return range; }
        set { range = value; }
    }
    //Two properties to be able to adjust for each projectile how much they should be slowed near the end of their range
    public float xSlowAmount
    {
        get { return xSlow; }
        set { xSlow = value; }
    }
    public float ySlowAmount
    {
        get { return ySlow; }
        set { ySlow = value; }
    }
    //StartingPosition to determine when the projectile is at the end of its Range
    public Vector2 StartingPosition
    {
        get { return startingposition; }
        set { startingposition = value; }
    }
    //Bool so that u can set it to true or false wether or not a projectile will be slowed
    public bool CanBeSlowed
    {
        get { return canBeSlowed; }
        set { canBeSlowed = value; }
    }
    public string AnimationID => animationId;

    //Get the distance the projectile has travelled  
    protected double DistanceTravelled
    {
        get
        {
            Vector2 distanceTravelled = new Vector2(Math.Abs(this.GlobalPosition.X - this.StartingPosition.X), Math.Abs(this.GlobalPosition.Y - this.StartingPosition.Y));
            double absDistanceTravelled = Math.Sqrt(Math.Pow(distanceTravelled.X, 2) + Math.Pow(distanceTravelled.Y, 2));
            return absDistanceTravelled;
        }
    }

    public Projectile(string assetName, int sheetindex = 0, string id = "", int layer = 1) : base(assetName, layer)
    {
        projectileList = new GameObjectList(1, "playerprojectileList");
        animationId = assetName;
        LoadAnimation(assetName, assetName, true, 0.08f);
        PlayAnimation(assetName);
        //Range for arrows ultimately only decided by the currently equipped bow, this is just for preemptive bug prevention
        this.Range = 100;
        GameData.LevelObjects.Add(projectileList);
        this.Origin = this.sprite.Center;
        this.xSlow = 65f;
        this.ySlow = 0f;
        this.canBeSlowed = true;
        pPos = GameData.GetPlayer.Position;
    }
    //Plays the projectile's animation, checks for nearby solidobjects, adjusts rotation based on velocity, checks for collision with enemies,
    //checks if the projectile has moved more than its range
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        PlayAnimation(AnimationID);
        pPos = GameData.GetPlayer.Position;
        CheckNearbySolidObjects();
        AdjustRotation();
        GeneralEnemyCollision();
        // If distancetravelled+100>Range slow down the projectile in a way that hopefully creates some depth in the game and then make it disappear.
        if (DistanceTravelled + 100 > this.Range)
        {
            if (CanBeSlowed)
            {
                SlowDownProjectile(gameTime, this.xSlowAmount, this.ySlowAmount);
            }
            if (DistanceTravelled > this.Range)
            {
                projectileList.Remove(this);
            }
        }
    }
    //Method for adding a projectile to the projectilelist
    public void AddToList(Projectile projectile)
    {
        projectileList.Add(projectile);
    }

    //Shoots a projectile
    public void ShootOneProjectile(Projectile projectile, Weapon weapon, float positionoffset)
    {
        projectile.Range = weapon.Range;
        projectile.StartingPosition = pPos;
        if (GameData.GetPlayer.Direction == "right")
        {
            this.sprite.Rotation = (float)(Math.PI * 0.5);
            projectile.Position = GameData.GetPlayer.GlobalPosition - new Vector2(-GameData.GetPlayer.Sprite.Center.X, GameData.GetPlayer.Height - positionoffset);
            projectile.Velocity = new Vector2(projectile.Speed, 0);
        }
        else if (GameData.GetPlayer.Direction == "left")
        {
            this.sprite.Rotation = (float)(Math.PI * -0.5);
            projectile.Position = GameData.GetPlayer.GlobalPosition - new Vector2(40, 0 + positionoffset);
            projectile.Velocity = new Vector2(-projectile.Speed, 0);
        }
        else if (GameData.GetPlayer.Direction == "up")
        {
            projectile.Position = GameData.GetPlayer.GlobalPosition - new Vector2(positionoffset, GameData.GetPlayer.Height);
            projectile.Velocity = new Vector2(0, -projectile.Speed);
        }
        else if (GameData.GetPlayer.Direction == "down")
        {
            sprite.Rotation = (float)Math.PI;
            projectile.Position = GameData.GetPlayer.GlobalPosition + new Vector2(positionoffset, 0);
            projectile.Velocity = new Vector2(0, projectile.Speed);
        }

        projectile.AddToList(projectile);
    }

    //Shoots two projectiles
    public void ShootTwoProjectiles(Projectile projectile, Projectile projectile2, Weapon weapon, float positionoffset1, float positionoffset2)
    {
        ShootOneProjectile(projectile, weapon, positionoffset1);
        ShootOneProjectile(projectile2, weapon, positionoffset2);
    }

    //Slows down the projectile (used near the end of its range) before it disappearing
    protected virtual void SlowDownProjectile(GameTime gameTime, float xSlow, float ySlow)
    {
        Vector2 amountOfSlow;
        if (this.Velocity.X > 0)
        {
            amountOfSlow = new Vector2(this.Speed / xSlow, -ySlow) * (float)gameTime.ElapsedGameTime.TotalMilliseconds;
            if (amountOfSlow.X < this.Speed)
                this.Velocity = new Vector2(this.Speed, 0) - amountOfSlow;
        }
        else if (this.Velocity.X < 0)
        {
            amountOfSlow = new Vector2(this.Speed / -xSlow, -ySlow) * (float)gameTime.ElapsedGameTime.TotalMilliseconds;
            if (amountOfSlow.X > -this.Speed)
                this.Velocity = new Vector2(-this.Speed, 0) - amountOfSlow;
        }
        else if (this.Velocity.X == 0)
        {
            if (this.Velocity.Y < 0)
            {
                amountOfSlow = new Vector2(0, this.Speed / -xSlow) * (float)gameTime.ElapsedGameTime.TotalMilliseconds;
                if (amountOfSlow.Y > -this.Speed)
                    this.Velocity = new Vector2(0, -this.Speed) - amountOfSlow;
            }
            else if (this.Velocity.Y > 0)
            {
                amountOfSlow = new Vector2(0, this.Speed / xSlow) * (float)gameTime.ElapsedGameTime.TotalMilliseconds;
                if (amountOfSlow.Y < this.Speed)
                    this.Velocity = new Vector2(0, this.Speed) - amountOfSlow;
            }
        }
    }
    //Changes rotationangle based on velocity
    protected virtual void AdjustRotation()
    {
        float differenceXPos = Math.Abs(this.Velocity.X);
        float differenceYPos = Math.Abs(this.Velocity.Y);
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        if (this.Velocity.X == 0)
        {
            if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)Math.PI;
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = 0;
            }
        }
        else if (this.Velocity.X > 0)
        {
            if (this.Velocity.Y == 0)
            {
                this.sprite.Rotation = (float)(Math.PI * 0.5);
            }
            else if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)((Math.PI * 0.5) + angle);
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)(angle);
            }
        }
        else if (this.Velocity.X < 0)
        {
            if (this.Velocity.Y == 0)
            {
                this.sprite.Rotation = (float)(Math.PI * -0.5);
            }
            else if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)(angle + (Math.PI));
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)(-angle);
            }
        }
    }

    //Method to give a projectile a velocity in a random direction
    protected Vector2 RandomDirection()
    {
        double maxSpeed = this.Speed;
        double ylaunch = (R.NextDouble() * maxSpeed);
        double xlaunch = Math.Sqrt(Math.Pow(maxSpeed, 2) * 2 - Math.Pow(ylaunch, 2));
        switch (R.Dice(4))
        {
            case 1:
                // x and y coord negative
                xlaunch = -xlaunch;
                ylaunch = -ylaunch;
                break;
            case 2:
                // x coord negative
                xlaunch = -xlaunch;
                break;
            case 3:
                // y coord negative
                ylaunch = -ylaunch;
                break;
            case 4:
                //unchanged
                break;
            default:
                break;
        }
        return new Vector2((float)xlaunch, (float)ylaunch);
    }

    //Looks for nearby solid objects to see if the projectile collides with it
    protected virtual void CheckNearbySolidObjects()
    {
        foreach (SpriteGameObject obj in GameWorld.SolidObjects)
        {
            if (CollidesWith(obj) && obj.ID != "water")
            {
                SolidCollisionEffect();
            }
        }
    }
    //Method for basic collision with enemies
    protected void GeneralEnemyCollision()
    {
        for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
        {
            if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
            {
                GeneralEnemy enemy = GameData.LevelObjects.Objects[i] as GeneralEnemy;
                if (this.CollidesWith(enemy))
                {
                    ItemEffect(enemy);
                    return;
                }
            }
        }
    }
    //Method for potential extra item effects when colliding with enemies.
    protected virtual void ItemEffect(GeneralEnemy enemy)
    {
        enemy.EnemyHealth -= this.Damage * GameData.GetPlayer.Damage;
        enemy.KnockBackTimer = knockbackTimer;
        enemy.KnockBacked = true;
        projectileList.Remove(this);
    }
    protected virtual void SolidCollisionEffect()
    {
        projectileList.Remove(this);
    }
}

