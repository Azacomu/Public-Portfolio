﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for CrystalArrow sprite created by CrystalArrow.cs, creates CrystalShard projectiles in the adjusted ItemEffect method upon collision with enemy.
class CrystalArrowSpr : Projectile
{
    protected Bow bow;
    protected int amountOfShards;
    protected int counter;
    public CrystalArrowSpr() : base("crystalarrow",0,"crystalarrow")
    {
        this.Speed = 600f;
        bow = GameData.GetPlayer.Inventory.GetItem(0) as Bow;
        this.Damage = 1 + bow.Damage;
        amountOfShards = 4;
        counter = 0;
        this.sprite.Scale = 0.8f;
    }

    //Checks for collision with enemies.
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        if (DistanceTravelled >= this.Range)
        {
            CreateShards();
            projectileList.Remove(this);
        }
    }

    //Create crystal shards near the hit enemy, crystal shards damage nearby enemies
    protected override void ItemEffect(GeneralEnemy enemy)
    {
        if (counter < 4)
        {
            CreateShards();
            base.ItemEffect(enemy);
        }
        else counter = 0;
    }
    protected void CreateShards()
    {
        for (int i = 0; i < 4; i++)
        {
            counter += 1;
            CrystalShard cshard = new CrystalShard(this.GlobalPosition);
            cshard.StartingPosition = this.GlobalPosition;
            if (i < 2)
            {
                cshard.Velocity = new Vector2(0, (float)(cshard.Speed - i * 2 * cshard.Speed));
            }
            else if(i==2)
            {
                cshard.Velocity = new Vector2((float)cshard.Speed , 0);
            }
            else if (i==3)
            {
                cshard.Velocity = new Vector2((float)-cshard.Speed, 0);
            }
            cshard.AddToList(cshard);
        }
    }
    protected override void SolidCollisionEffect()
    {
        CreateShards();
        base.SolidCollisionEffect();
    }
}


