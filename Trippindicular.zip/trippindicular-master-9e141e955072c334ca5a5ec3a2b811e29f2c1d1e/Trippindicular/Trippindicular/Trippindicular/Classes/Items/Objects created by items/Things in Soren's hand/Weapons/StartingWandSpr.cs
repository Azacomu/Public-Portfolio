﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the StartingWand sprite near the player, this just gives the assetName of the correct sprite to WeaponsInHand and 
//sets the correct rotationOffset.
class StartingWandSpr : WeaponsInHand
{


    public StartingWandSpr(string id = "startingwandspr") : base("wand", id)
    {
        this.rotationOffset = 0.25;
    }

}


