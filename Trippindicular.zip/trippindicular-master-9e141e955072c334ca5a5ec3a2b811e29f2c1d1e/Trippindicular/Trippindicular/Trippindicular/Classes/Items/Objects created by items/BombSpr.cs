﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the bombsprite that is created by using the Bomb item, explodes after a delay, damaging nearby enemies and destroying
//certain nearby solid objects
class BombSpr : AnimatedGameObject
{
    protected double blastRadius;
    Vector2 pPos;
    protected float damage;
    int explodeCounter;

    public BombSpr() : base("bomb", 1)
    {
        LoadAnimation("bomb", "shortenFuse", false, 0.25f);
        LoadAnimation("explosion", "explode", false, 0.04f);
        PlayAnimation("shortenFuse");
        damage = 5;
        blastRadius = 220;
        Origin = sprite.Center;
        explodeCounter = 0;
    }
    //Updates a list of nearby GameObjects called nearlist and from this list creates a list with all the solid GameObjects.
    //also sets a timer after which the Explode method is called.
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        pPos = GameData.GetPlayer.GlobalPosition;
        if (animations["shortenFuse"].AnimationEnded)
        {
            Explode();
            animations["explode"].Scale = 6f;
            PlayAnimation("explode");
            if (animations["explode"].AnimationEnded)
            {
                GameData.LevelObjects.Remove(this);
            }
        }
        else PlayAnimation("shortenFuse");
    }
    //Checks for each enemy if they are within the radius, if so it knocks them back slightly and deals damage.
    //Also destroys specific nearby solid objects(not keydoors, water, walls).
    protected void Explode()
    {
        if (explodeCounter < 1)
        {
            GameWorld.AssetLoader.PlaySound("explosionSFX");
            //Check if enemies are within the blastradius
            for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
                if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
                {
                    GeneralEnemy enemy = GameData.LevelObjects.Objects[i] as GeneralEnemy;
                    if (Math.Sqrt(Math.Pow((this.GlobalPosition.X - enemy.Position.X), 2) + Math.Pow((this.GlobalPosition.Y - enemy.Position.Y), 2)) < this.blastRadius)
                    {
                        enemy.EnemyHealth -= damage;
                        enemy.KnockBackTimer = 0.25f;
                        enemy.KnockBacked = true;
                    }
                }
            //Check if the player is in the blastradius
            if (Math.Sqrt(Math.Pow((this.GlobalPosition.X - pPos.X), 2) + Math.Pow((this.GlobalPosition.Y - pPos.Y), 2)) < this.blastRadius)
            {
                GameData.GetPlayer.DealDamage(1);
            }
            //Check if destructable solid objects are in the blastradius
            foreach (GameObject obj in GameWorld.SolidObjects)
            {
                if (obj.ID != "wall" && obj.ID != "water" && obj.ID != "singleWall")
                {
                    if (Math.Sqrt(Math.Pow((this.GlobalPosition.X - obj.Position.X), 2) + Math.Pow((this.GlobalPosition.Y - obj.Position.Y), 2)) < this.blastRadius)
                    {
                        if (obj is Door)
                        {
                            if(!(obj is KeyDoor)&&!(obj is TrapDoor)&&!(obj is PuzzleDoor))
                            {
                                GameData.LevelObjects.Remove(obj);
                            }
                        }
                        else
                        {
                            GameData.LevelObjects.Remove(obj);
                        }
                    }
                }
            }
            explodeCounter += 1;
            Position += new Vector2(0,animations["explode"].Height*2.75f);
        }
    }
}

