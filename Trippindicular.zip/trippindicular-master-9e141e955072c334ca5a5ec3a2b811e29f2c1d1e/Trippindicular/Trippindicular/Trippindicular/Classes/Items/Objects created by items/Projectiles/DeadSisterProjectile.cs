﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for deadsisterprojecilte created by Azalea, very basic projectile other than that it slightly predicts the direction the enemy is moving

class DeadSisterProjectile : Projectile
{
    public DeadSisterProjectile() : base("redFlame", 0, "deadsisterprojectile")
    {
        this.Damage = 2;
        this.Speed = 700f;
        this.Range = 300;
        this.CanBeSlowed = false;
        this.sprite.Scale = 1.3f;
    }

    //Damage enemy
    protected override void ItemEffect(GeneralEnemy enemy)
    {
        enemy.EnemyHealth -= this.Damage;
        projectileList.Remove(this);
    }
    //Adjust rotation based on velocity
    protected override void AdjustRotation()
    {
        float differenceXPos = Math.Abs(this.Velocity.X);
        float differenceYPos = Math.Abs(this.Velocity.Y);
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        if (this.Velocity.X == 0)
        {
            if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = 0;
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)Math.PI;
            }
        }
        else if (this.Velocity.X > 0)
        {
            if (this.Velocity.Y == 0)
            {
                this.sprite.Rotation = (float)(Math.PI * -0.5);
            }
            else if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)((Math.PI * 1.5) + angle);
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)(angle + (Math.PI));
            }
        }
        else if (this.Velocity.X < 0)
        {
            if (this.Velocity.Y == 0)
            {
                this.sprite.Rotation = (float)(Math.PI * 0.5);
            }
            else if (this.Velocity.Y > 0)
            {
                this.sprite.Rotation = (float)(angle);
            }
            else if (this.Velocity.Y < 0)
            {
                this.sprite.Rotation = (float)((-angle) + (Math.PI));
            }
        }
    }
}

