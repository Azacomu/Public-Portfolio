﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for crystal shard sprite created by CrystalArrowSpr.cs if it collides with an enemy, very basic projectile, other than that it checks
//to see if it is created within a solidobject, if so it places the projectile back again

class CrystalShard : Projectile
{
    public CrystalShard(Vector2 position) : base("crystalshard", 0, "crystalshard")
    {
        this.Damage = 1;
        this.Speed = 300f;
        this.Range = 200;
        this.Position = position;
        this.sprite.Scale = 0.6f;
        //Check if it is created within the walls
        if (this.Position.Y > tileHeight * 13.25)
        {
            this.Position -= new Vector2(0, (this.Position.Y - (float)(tileHeight * 13.25)));
        }
        else if (this.Position.Y < tileHeight * 1.75)
        {
            this.Position += new Vector2(0, ((tileHeight * 1.75f) - this.Position.Y));
        }
        if (this.Position.X > tileWidth * 28.25)
        {
            this.Position -= new Vector2((this.Position.X - (float)(tileWidth * 28.25)), 0);
        }
        else if (this.Position.X < tileWidth * 1.75)
        {
            this.Position += new Vector2(((tileWidth * 1.75f) - this.Position.X), 0);
        }
        //Check if it is created within other solid objects like trees
        CheckForInstantCollision();
    }

    protected override void ItemEffect(GeneralEnemy enemy)
    {
        enemy.EnemyHealth -= this.Damage;
        projectileList.Remove(this);
    }
    //Check if it is created within solid objects, move the projectile if so, repeat a few times
    protected void CheckForInstantCollision()
    {
        foreach (GameObject obj in GameWorld.SolidObjects)
        {
            if (CollidesWith(obj) && obj.ID != "water")
            {
                this.Position -= new Vector2(20, 0);
            }
            if (CollidesWith(obj) && obj.ID != "water")
            {
                this.Position -= new Vector2(-40, 0);
            }
            if (CollidesWith(obj) && obj.ID != "water")
            {
                this.Position -= new Vector2(20, 20);
            }
            if (CollidesWith(obj) && obj.ID != "water")
            {
                this.Position -= new Vector2(0, -40);
            }
        }
    }
}

