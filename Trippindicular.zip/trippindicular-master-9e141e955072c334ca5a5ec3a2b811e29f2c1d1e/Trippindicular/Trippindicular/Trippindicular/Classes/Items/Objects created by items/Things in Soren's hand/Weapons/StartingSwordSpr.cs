﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the StartingSword sprite near the player, this just gives the assetName of the correct sprite to WeaponsInHand
class StartingSwordSpr : WeaponsInHand
{

    public StartingSwordSpr(string id = "startingswordspr") : base("startingsword", id)
    {
    }

}


