﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the DoubleTeam sprite near the player, this just gives the assetName of the correct sprite to WeaponsInHand and sets the 
//correct rotationOffset.
class TheDoubleTeamSpr : WeaponsInHand
{


    public TheDoubleTeamSpr(string id = "doubleteamspr") : base("doubleteam", id)
    {
        this.sprite.Scale = 0.55f;
        this.rotationOffset = -0.25;
        this.positionOffset = new Vector2(10, 12);
    }

}