﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for Boomerang sprite created by Boomerang.cs, has a method for returning to the player,  and an adjusted ItemEffect upon hit
//(stuns the enemy and deals some dmg)
class BoomerangSpr : Projectile
{
    protected bool startReturning;
    protected float rotationSpeed;
    public BoomerangSpr() : base("boomerang", 0, "boomerangspr")
    {
        this.Speed = 600;
        startReturning = false;
        this.sprite.Scale = 0.4f;
        this.xSlowAmount = 50f;
        rotationSpeed = 0.3f;
        this.Damage = 2;
    }

    //Checks for collision with enemies, updates distancetravelled and makes it return to player when needed
    public override void Update(GameTime gameTime)
    {
        this.Position += this.Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
        GeneralEnemyCollision();
        CheckNearbySolidObjects();
        this.sprite.Rotation += rotationSpeed;
        if (startReturning)
        {
            ReturnToPlayer();

            if (this.CollidesWith(GameData.GetPlayer) && startReturning)
            {
                GameData.GetPlayer.Inventory.GetItem(1).CooldownTimer = 15.1;
                projectileList.Remove(this);
            }
        }
        else if (this.DistanceTravelled + 100 >= this.Range)
        {
            SlowDownProjectile(gameTime, xSlowAmount, ySlowAmount);
            if (this.DistanceTravelled >= this.Range)
            {
                startReturning = true;
            }
        }
    }
    // Return boomerang to player
    protected void ReturnToPlayer()
    {
        float differenceXPos = Math.Abs(GameData.GetPlayer.GlobalPosition.X - this.GlobalPosition.X);
        float differenceYPos = Math.Abs(GameData.GetPlayer.GlobalPosition.Y - this.GlobalPosition.Y);
        float xvelocity = 0;
        float yvelocity = 0;
        double angle = 0;
        angle = Math.Atan((differenceXPos / differenceYPos));
        xvelocity = (float)(Math.Sin(angle) * this.Speed);
        yvelocity = (float)(Math.Cos(angle) * this.Speed);
        if (GameData.GetPlayer.GlobalPosition.X+GameData.GetPlayer.Width/2 >= this.GlobalPosition.X+this.Width/2)
        {
            if (GameData.GetPlayer.GlobalPosition.Y+GameData.GetPlayer.Origin.Y < this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(xvelocity, -yvelocity);
            }
            else if (GameData.GetPlayer.GlobalPosition.Y > this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(xvelocity, yvelocity);
            }
        }
        else if (GameData.GetPlayer.GlobalPosition.X+ GameData.GetPlayer.Width/2 <= this.GlobalPosition.X+this.Width/2)
        {
            if (GameData.GetPlayer.GlobalPosition.Y+GameData.GetPlayer.Origin.Y < this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(-xvelocity, -yvelocity);
            }
            else if (GameData.GetPlayer.GlobalPosition.Y > this.GlobalPosition.Y)
            {
                this.Velocity = new Vector2(-xvelocity, yvelocity);
            }

        }
    }
    protected override void ItemEffect(GeneralEnemy enemy)
    {
        enemy.EnemyHealth -= this.Damage;
        enemy.StunTimer = 0.3f;
        enemy.Stunned = true;
        startReturning = true;
    }
    protected override void SolidCollisionEffect()
    {
        startReturning = true;
    }
}


