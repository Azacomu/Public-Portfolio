﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class to update, draw and play an animation for the weapons in Soren's hand.
class WeaponsInHand : SpriteGameObject
{
    protected const float timeStandingStill = 0.2f;
    protected const float animationSpeed = 80f;
    protected double animationTimer;
    protected double rotationOffset;
    protected Vector2 positionOffset;
    protected string attackDirection;
    Weapon weapon;
    Vector2 animationVelocity;
    
    public WeaponsInHand(string assetName, string id) : base(assetName, 0, id)
    {
        this.sprite.Scale = 0.6f;
        animationTimer = 0;
        this.rotationOffset = 0;
        this.positionOffset = Vector2.Zero;
        this.Origin = this.sprite.Center;
    }
    //If attacking, updates the velocity, animationtimer and plays the animation. Else updates the position and rotation based on player position and direction if not attacking.
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        weapon = GameData.GetPlayer.Inventory.GetItem(0) as Weapon;
        if (weapon.UsedWeapon)
        {
            this.Velocity = GameData.GetPlayer.Velocity + animationVelocity;
            animationTimer += gameTime.ElapsedGameTime.TotalSeconds;
            AttackAnimation();
            GameData.GetPlayer.Attack();
        }
        else
        {
            UpdatePosition(positionOffset);
            UpdateRotation(this.rotationOffset);
            animationVelocity = Vector2.Zero;
            GameData.GetPlayer.StopAttack();
        }
    }
    //Updates the position to the player's right hand
    protected virtual void UpdatePosition(Vector2 positionOffset)
    {
        if (GameData.GetPlayer.Direction == "left")
        {
            this.Position = GameData.GetPlayer.GlobalPosition - new Vector2(25-positionOffset.X, 27);
        }

        else if (GameData.GetPlayer.Direction == "right")
        {
            this.Position = GameData.GetPlayer.GlobalPosition - new Vector2(-10 +positionOffset.X, 20);
        }
        else if (GameData.GetPlayer.Direction == "up")

        {
            this.Position = GameData.GetPlayer.GlobalPosition - new Vector2(-12, 40-positionOffset.Y);
        }
        else if (GameData.GetPlayer.Direction == "down")
        {
            this.Position = GameData.GetPlayer.GlobalPosition - new Vector2(10, 5+positionOffset.Y);
        }
    }
    //Updates the rotation based on the direction the player is facing
    protected virtual void UpdateRotation(double rotationOffset)
    {
        if (GameData.GetPlayer.Direction == "left")
        {
            this.sprite.Rotation = (float)-(Math.PI * (0.5 + this.rotationOffset));
        }

        else if (GameData.GetPlayer.Direction == "right")
        {
            this.sprite.Rotation = (float)(Math.PI * (0.5 -this.rotationOffset));
        }
        else if (GameData.GetPlayer.Direction == "up")

        {
            this.sprite.Rotation = (float)-(Math.PI * rotationOffset);
        }
        else if (GameData.GetPlayer.Direction == "down")
        {
            this.sprite.Rotation = (float)-(Math.PI * (1+this.rotationOffset));
        }
    }
    //Plays the attack animation(a very simple increase in velocity in a direction);
    protected void AttackAnimation()
    {
        if (animationTimer > timeStandingStill)
        {
            weapon.UsedWeapon = false;
            animationTimer = 0;
        }
        this.attackDirection = GameData.GetPlayer.Direction;
        if (attackDirection == "left")
        {
            animationVelocity = new Vector2(-animationSpeed, 0);
        }

        else if (attackDirection == "right")
        {
            animationVelocity = new Vector2(animationSpeed, 0);
        }
        else if (attackDirection == "up")
        {
            animationVelocity = new Vector2(0, -animationSpeed);
        }
        else if (attackDirection == "down")
        {
            animationVelocity = new Vector2(0, animationSpeed);
        }
    }
}

