﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//General class for Arrows, which all arrows inherit from, makes instances of all Bow items for arrows to use.
class Arrow : Items
{
    protected TheDoubleTeam tbow;
    protected WoodenBow wbow;
    public Arrow(string itemtype = "LeftHand", string assetName = "", int sheetIndex = 0, string id = "") : base(itemtype, assetName, sheetIndex, id)
    {
        //bows
        tbow = new TheDoubleTeam();
        wbow = new WoodenBow();
    }
}

