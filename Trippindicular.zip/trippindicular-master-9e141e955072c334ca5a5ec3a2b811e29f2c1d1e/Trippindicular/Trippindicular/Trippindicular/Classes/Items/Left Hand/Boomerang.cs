﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the Boomerang item, creates a BoomerangSpr SpriteGameObject and fires it
class Boomerang : Weapon
{

    public Boomerang(string itemtype = "LeftHand", string assetName = "boomerang", int sheetIndex = 0, string id = "boomerang") : base(itemtype, assetName, sheetIndex, id)
    {
        this.Range = 300;
        this.Cooldown = 15;
        this.CooldownTimer = 15.1;
        ItemDescription = "Use to stun enemies and deal some damage";
        itemName = "Boomerang";
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
    }
    //Sets the cooldownTimer to 15.1 when picked up so that it can be used instantly
    public override void PickUp()
    {
        base.PickUp();
        this.CooldownTimer = 15.1;
    }
    //Shoot a BoomerangSpr projectile if CooldownTimer>Cooldown, BoomerangSpr projectile sets this CooldownTimer to 15.1 when the boomerang returns to the player, so that u won't have 2 boomerangs
    //in the air at the same time.
    public override void UseItem()
    {
        if (this.CooldownTimer > this.Cooldown)
        {
            this.CooldownTimer = 0;
            BoomerangSpr boomerang = new BoomerangSpr();
            if (GameData.GetPlayer.Direction == "up" || GameData.GetPlayer.Direction == "down")
            {
                boomerang.ShootOneProjectile(boomerang, this, 0);
            }
            else { boomerang.ShootOneProjectile(boomerang, this, GameData.GetPlayer.Height / 2); }
        }
    }
}
