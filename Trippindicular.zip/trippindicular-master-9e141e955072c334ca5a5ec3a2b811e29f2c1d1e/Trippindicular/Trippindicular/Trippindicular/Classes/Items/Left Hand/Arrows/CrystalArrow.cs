﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
//Class for the crystal arrow item, which uses one of the shoot methods from Projectile.cs depending on the current bow
class CrystalArrow : Arrow
{

    public CrystalArrow(string id = "crystalarrow", int layer = 0, string itemtype = "LeftHand") : base(itemtype, "crystalarrow", 0, id)
    {
        this.ItemDescription = "You obtained Crystal Arrows! Try them out with a bow!";
        itemName = "Crystal Arrows";
    }
    //Sets HasCrystalArrows property of inventory to true
    public override void PickUp()
    {
        base.PickUp();
        GameData.GetPlayer.Inventory.HasCrystalArrows = true;
    }

    //Shoots one or two CrystalArrowSpr projectiles depending on the current bow
    public override void UseItem()
    {
        base.UseItem();
        CrystalArrowSpr arrow = new CrystalArrowSpr();

        if (GameData.GetPlayer.Inventory.HasDoubleTeamer)
        {
            if (GameData.GetPlayer.Direction == "up" || GameData.GetPlayer.Direction == "down")
            {
                CrystalArrowSpr arrow2 = new CrystalArrowSpr();
                arrow.ShootTwoProjectiles(arrow, arrow2, tbow, 10, -10);
            }
            else
            {
                CrystalArrowSpr arrow2 = new CrystalArrowSpr();
                arrow.ShootTwoProjectiles(arrow, arrow2, tbow, 40, 20);
            }
        }
        else if (GameData.GetPlayer.Direction == "up" || GameData.GetPlayer.Direction == "down")
        {
            arrow.ShootOneProjectile(arrow, wbow, 0);
        }
        else { arrow.ShootOneProjectile(arrow, wbow, GameData.GetPlayer.Height / 2); } 
    }
}