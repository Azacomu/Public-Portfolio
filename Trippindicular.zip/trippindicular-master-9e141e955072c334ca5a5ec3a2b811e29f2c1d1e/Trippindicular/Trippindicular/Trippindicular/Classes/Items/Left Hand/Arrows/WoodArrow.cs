﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for WoodArrow item, which uses one of the shoot methods from Projectile.cs depending on the current bow
class WoodArrow : Arrow
{

    public WoodArrow(string id = "woodarrow", int layer = 0, string itemtype = "LeftHand") : base(itemtype, "arrow", 0, id)
    {

    }

    //Shoots one or two WoodArrowSpr projectiles depending on the current bow
    public override void UseItem()
    {
        base.UseItem();
        WoodArrowSpr arrow = new WoodArrowSpr();
        if (GameData.GetPlayer.Inventory.HasDoubleTeamer)
        {
            if (GameData.GetPlayer.Direction == "up" || GameData.GetPlayer.Direction == "down")
            {
                WoodArrowSpr arrow2 = new WoodArrowSpr();
                arrow.ShootTwoProjectiles(arrow, arrow2, tbow,10,-10);
            }
            else
            {
                WoodArrowSpr arrow2 = new WoodArrowSpr();
                arrow.ShootTwoProjectiles(arrow, arrow2, tbow, 40,20);
            }
        }
        else if (GameData.GetPlayer.Direction == "up" || GameData.GetPlayer.Direction == "down")
        {
            arrow.ShootOneProjectile(arrow, wbow, 0);
        }
        else { arrow.ShootOneProjectile(arrow, wbow, GameData.GetPlayer.Height / 2); }
    }
}

