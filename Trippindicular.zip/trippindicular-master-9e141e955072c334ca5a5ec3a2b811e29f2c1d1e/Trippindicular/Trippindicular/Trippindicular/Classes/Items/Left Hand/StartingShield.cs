﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

//Class for the startingshield item which updates a hitbox and draws a shield sprite on the player
class StartingShield : Items
{
    protected double shieldwidth;
    protected bool usingShield;
    protected Rectangle hitBox;
    StartingShieldSpr shieldspr;

    //Property to see if the player is using the shield
    public bool IsUsingShield => usingShield;
    //Property for the HitBox
    public Rectangle HitBox => this.hitBox;

    public StartingShield(string id = "startingshield", int layer = 0) : base("LeftHand", "woodenShield", 0, id, 0)
    {
        shieldwidth = 10;
        hitBox = new Rectangle();
        shieldspr = new StartingShieldSpr();
        usingShield = false;
        ItemDescription = "Press the shield button to block projectiles";
        itemName = "Shield";
    }
    //Updates the StartingShieldSpr position and the shield hitbox
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        if (this.Equipped)
        {
            shieldspr.Update(gameTime);
            UpdateHitBox();
        }
    }
    //Draws a StartingShieldSpr on the player
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        if (this.Equipped)
            shieldspr.Draw(gameTime, spriteBatch);
    }
    //If the shield button is pressed, usingShield property is set to true
    public override void HandleInput(InputHelper ih)
    {
        if (ih.IsKeyDown(Keys.R)&&this.Equipped)
        {
            usingShield = true;
            GameData.GetPlayer.Attack();
        }
        else
        {
            usingShield = false;
            GameData.GetPlayer.StopAttack();
        }
    }
    //Only pick up shield if you don't have a bow equipped, else create a notification saying its not possible
    public override void PickUp()
    {
        if (!(GameData.GetPlayer.Inventory.GetItem(0) is Bow))
            base.PickUp();
        else 
        {
            Notification notPossible = new Notification("", "Can't use a shield together with a bow", "",1f);
            notPossible.CreateNotification();
        }
    }
    //Updates the hitbox based on player position and the direction the player is facing
    protected void UpdateHitBox()
    {
        
        {
            if (GameData.GetPlayer.Direction == "left")
            {
                int left = ((int)(GameData.GetPlayer.BoundingBox.Left - shieldwidth));
                int top = (int)GameData.GetPlayer.BoundingBox.Top;
                hitBox = new Rectangle(left, top, (int)shieldwidth, GameData.GetPlayer.Height);
            }

            else if (GameData.GetPlayer.Direction == "right")
            {
                int left = ((int)(GameData.GetPlayer.BoundingBox.Right));
                int top = ((int)GameData.GetPlayer.BoundingBox.Top);
                hitBox = new Rectangle(left, top, (int)shieldwidth, GameData.GetPlayer.Height);
            }
            else if (GameData.GetPlayer.Direction == "up")

            {
                int left = ((int)GameData.GetPlayer.BoundingBox.Left);
                int top = (int)(GameData.GetPlayer.BoundingBox.Top - shieldwidth);
                hitBox = new Rectangle(left, top, GameData.GetPlayer.Width, (int)shieldwidth);
            }
            else
            {
                int left = (int)GameData.GetPlayer.BoundingBox.Left;
                int top = (int)(GameData.GetPlayer.BoundingBox.Bottom);
                hitBox = new Rectangle(left, top, GameData.GetPlayer.Width, (int)shieldwidth);
            }
        }
    }
}





