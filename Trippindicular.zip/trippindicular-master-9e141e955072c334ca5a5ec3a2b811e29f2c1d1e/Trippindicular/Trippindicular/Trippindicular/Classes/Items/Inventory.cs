﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;


//Class that manages the inventory of the player (picked up items and powerups), checks for input by the player and Adds/Drops items when needed.
class Inventory : GameObjectList
{
    Items[] inventory;
    List<Items> powerups;
    protected int healthPotions;
    protected int bombs;
    protected int coins;
    protected int keys;
    protected bool hasCrystalArrows;
    protected bool hasShieldUpgrade;
    protected bool hasDoubleTeamer;
    protected Timer dropDownTimer;


    //Returns the item in an inventoryslot
    public Items GetItem(int slot)
    {
        return inventory[slot];
    }
    // The Stackables
    public int GetKeys
    {
        get { return keys; }
        set { keys = value; }
    }
    public int GetHealthPotions
    {
        get { return healthPotions; }
        set { healthPotions = value; }
    }
    public int GetBombs
    {
        get { return bombs; }
        set { bombs = value; }
    }
    public int GetCoins
    {
        get { return coins; }
        set { coins = value; }
    }
    //Bool to see if the enemy has picked up crystal arrows at any point
    public bool HasCrystalArrows
    {
        get { return hasCrystalArrows; }
        set { hasCrystalArrows = value; }
    }
    //Bool to see if the player has thedoubleteamer equipped
    public bool HasDoubleTeamer
    {
        get { return hasDoubleTeamer; }
        set { hasDoubleTeamer = value; }
    }
    //Bool to see if the player has the shield upgrade
    public bool HasShieldUpgrade
    {
        get { return hasShieldUpgrade; }
        set { hasShieldUpgrade = value; }
    }
    //Property to access the powerups list
    public List<Items> PowerUps
    {
        get { return powerups; }
        set { powerups = value; }
    }


    public Inventory()
    {
        inventory = new Items[6];
        powerups = new List<Items>();
        healthPotions = 0;
        bombs = 1;
        coins = 0;
        keys = 1;
        hasCrystalArrows = false;
        hasShieldUpgrade = false;
        hasDoubleTeamer = false;
        inventory[0] = new BareHands();
        inventory[5] = new HealthPotion();
        dropDownTimer = new Timer(1f);
        dropDownTimer.Pause();
    }



    //Updates the dropdownbar upon switching a consumable, updates item in inventory list and powerups list
    public override void Update(GameTime gameTime)
    {
        dropDownTimer.Update(gameTime);
        if (dropDownTimer.Ended)
        {
            IGameLoopObject temp = GameWorld.GameStateManager.GetGameState("hud");
            HUD hud = temp as HUD;
            hud.Down = false;
            dropDownTimer.Reset();
            dropDownTimer.Pause();
        }
        for (int j = 0; j < inventory.Length; j++)
        {
            inventory[j]?.Update(gameTime);
        }
        for (int i = 0; i < powerups.Count; i++)
        {
            powerups[i]?.Update(gameTime);
        }
    }
    //Draws items in inventory list and powerups list
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        for (int j = 0; j < inventory.Length; j++)
        {
            inventory[j]?.Draw(gameTime, spriteBatch);
        }
        for (int i = 0; i < powerups.Count; i++)
        {
            powerups[i]?.Draw(gameTime, spriteBatch);
        }
    }
    //Handles input for using and switching items out in the inventory and for the powerups list
    public override void HandleInput(InputHelper ih)
    {
        // use right hand weapon
        if (ih.KeyPressed(Keys.E))
        {
            inventory[0]?.UseItem();
        }
        // use left hand item
        else if (ih.KeyPressed(Keys.R))
        {
            if (inventory[1] != null)
            {
                if (inventory[1] is Arrow)
                {
                    return;
                }
                else
                {
                    inventory[1].UseItem();
                }
            }
        }
        //use consumable
        else if (ih.KeyPressed(Keys.T))
        {
            UseConsumable();
        }
        //switch out consumables with active one using 5th item slot
        else if (ih.KeyPressed(Keys.Y))
        {
            SwitchConsumables();
        }
        //switch out consumables with active one using 5th item slot, but the other way around
        else if (ih.KeyPressed(Keys.U))
        {
            SwitchConsumablesUP();
        }
        //use bomb
        if (ih.KeyPressed(Keys.B))
        {
            if (GetBombs != 0)
            {
                Bomb bomb = new Bomb();
                bomb.UseItem();
            }
        }
        //Handle input for items in inventory
        for (int j = 0; j < inventory.Length; j++)
        {
            inventory[j]?.HandleInput(ih);
        }
        //Handle input for powerups
        for (int i = 0; i < powerups.Count; i++)
        {
            powerups[i]?.HandleInput(ih);
        }
    }

    /*
    Inventory slot 0 is for RightHand Weapon
    Inventory slot 1 is for LeftHand items, if nothing is in it then startingshield, can also put arrows in it, empty if holding a staff
    Inventory slot 2 is for Consumables like special potions, one time use spell tomes
    Inventory slot 3 is for Extra Consumables like special potions, one time use spell tomes
    Inventory slot 4 is used for swapping out items
    inventory slot 5 is also for extra consumables(added healthpotions)
    */
    public void AddItem(Items item)
    {
        {
            item.Equipped = true;
            item.Equippable = false;
            item.Visible = true;
            item.IsBouncing = false;
            switch (item.ItemType)
            {
                case "RightHand":
                    AddRightHand(item);
                    break;
                case "LeftHand":
                    AddLeftHand(item);
                    break;
                case "Consumable":
                    AddConsumable(item);
                    break;
                case "Stackable":
                    AddStackable(item);
                    break;
                case "PowerUp":
                    AddPowerUp(item);
                    break;
                default:
                    break;
            }
        }
    }
    //Method that drops an item from the inventory onto the floor
    public void DropItem(int inventoryslot, Items item, Vector2 position)
    {
        if (inventory[inventoryslot] != null)
        {
            if (item is BareHands)
                return;
            // Wont drop a used consumable
            if (item.ItemType == "Consumable" && item.HasBeenUsed == true)
            {
                inventory[inventoryslot] = null;
                return;
            }
            // Remove arrows from left hand slot if a bow is dropped
            if (item is Bow)
            {
                if (inventory[1] is Arrow)
                {
                    inventory[1] = null;
                }
            }
            item.DropTimer = 0;
            item.Equipped = false;
            item.Equippable = false;
            item.IsBouncing = true;
            item.Position = position;
            item.Layer = 1;
            GameData.LevelObjects.Add(item);
            inventory[inventoryslot] = null;
        }
    }
    //Methods for adding items to the inventory
    protected void AddRightHand(Items item)
    {
        if (item is Bow && inventory[1] is StartingShield)
            if (item.Position.X + 50 < 1600)
                DropItem(1, inventory[1], item.Position + new Vector2(50, 0));
            else DropItem(1, inventory[1], item.Position + new Vector2(-50, 0));
        DropItem(0, inventory[0], item.Position);
        inventory[0] = item;
    }

    protected void AddLeftHand(Items item)
    {
        if (item is CrystalArrow)
        {
            if (!(inventory[0] is Bow))
            {
                return;
            }
        }
        DropItem(1, inventory[1], item.Position);
        inventory[1] = item;
    }
    protected void AddConsumable(Items item)
    {
        if ((inventory[2] == null || inventory[2].HasBeenUsed))
        {
            inventory[2] = item;
        }
        else if ((inventory[3] == null || inventory[3].HasBeenUsed) && (!(inventory[3] is HealthPotion)))
        {
            inventory[3] = item;
        }
        else if ((inventory[5] == null || inventory[5].HasBeenUsed) && (!(inventory[5] is HealthPotion)))
        {
            inventory[5] = item;
        }
        else if ((!(inventory[3] is HealthPotion)))
        {
            DropItem(3, inventory[3], item.Position);
            inventory[3] = item;
        }
        else
        {
            DropItem(5, inventory[5], item.Position);
            inventory[5] = item;
        }
    }
    protected void AddStackable(Items item)
    {
        if (item.ID == "healthPotion" && healthPotions < 99)
        { healthPotions += 1; }
        else if (item.ID == "bomb" && bombs < 99)
        { bombs += 1; }
        else if (item.ID == "coin" && coins < 99)
        { coins += 1; }
        else if (item.ID == "key" && keys < 99)
        { keys += 1; }
    }
    protected void AddPowerUp(Items item)
    {
        powerups.Add(item);
    }
    //Method for switching out the active and passive consumables
    protected void SwitchConsumables()
    {
        if (inventory[3] != null)
            if (inventory[3].HasBeenUsed)
            {
                inventory[3] = null;
            }
        inventory[4] = inventory[2];
        inventory[2] = inventory[3];
        inventory[3] = inventory[4];

        inventory[4] = inventory[3];
        inventory[3] = inventory[5];
        inventory[5] = inventory[4];

        dropDownTimer.Reset();
        IGameLoopObject temp = GameWorld.GameStateManager.GetGameState("hud");
        HUD hud = temp as HUD;
        hud.Down = true;
    }

    //Method for switching out the active and passive consumables the other way around
    protected void SwitchConsumablesUP()
    {
        inventory[4] = inventory[2];
        inventory[2] = inventory[5];
        inventory[5] = inventory[4];

        inventory[4] = inventory[3];
        inventory[3] = inventory[5];
        inventory[5] = inventory[4];

        dropDownTimer.Reset();
        IGameLoopObject temp = GameWorld.GameStateManager.GetGameState("hud");
        HUD hud = temp as HUD;
        hud.Down = true;
    }

    //Method for using the active consumable
    protected void UseConsumable()
    {
        if (inventory[2] is HealthPotion)
        {
            inventory[2].UseItem();
        }
        else if (inventory[2] != null && inventory[2].HasBeenUsed == false)
        {
            inventory[2].UseItem();
            inventory[2].HasBeenUsed = true;
            inventory[2].Visible = false;
            inventory[2] = null;
        }
    }
}
