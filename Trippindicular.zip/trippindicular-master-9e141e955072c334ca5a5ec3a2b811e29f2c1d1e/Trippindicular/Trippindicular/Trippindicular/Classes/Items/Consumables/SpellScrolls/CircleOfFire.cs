﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
//Class for the circleoffire spellscroll, which shoots 8 fireballs with CreateFireCircle() when used, damaging enemies in the way
class CircleOfFire : Items
{
    public CircleOfFire() : base("Consumable", "spellScroll", 0, "circleoffire")
    {
        ItemDescription = "Shoots fire in all directions";
        itemName = "Circle of fire spell";
    }
    public override void UseItem()
    {
        base.UseItem();
        CreateFireCircle();
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
    }

    //Creates a total of 8 fires and adds them to projectilelist to be updated.
    protected void CreateFireCircle()
    {
        GameWorld.AssetLoader.PlaySound("fireball");
        //create fires that move up and down
        for (int i = 0; i < 2; i++)
        {
            CircleOfFireSpr fire = new CircleOfFireSpr();
            fire.Position = GameData.GetPlayer.GlobalPosition;
            fire.Velocity = new Vector2(0, (float)(fire.Speed - i * 2 * fire.Speed));
            fire.StartingPosition = fire.GlobalPosition;
            fire.AddToList(fire);
        }
        // create fires that move left and right
        for (int i = 0; i < 2; i++)
        {
            CircleOfFireSpr fire = new CircleOfFireSpr();
            fire.Position = GameData.GetPlayer.GlobalPosition;
            fire.Velocity = new Vector2((float)(fire.Speed - i * 2 * fire.Speed), 0);
            fire.StartingPosition = fire.GlobalPosition;
            fire.AddToList(fire);
        }
        //Create fires that move to different places
        for (int i = 0; i < 4; i++)
        {
            CircleOfFireSpr fire = new CircleOfFireSpr();
            fire.Position = GameData.GetPlayer.GlobalPosition;
            if (i == 0)
                fire.Velocity = new Vector2((float)Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)), (float)Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)));
            if (i == 1)
                fire.Velocity = new Vector2((float)-Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)), (float)Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)));
            if (i == 2)
                fire.Velocity = new Vector2((float)-Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)), (float)-Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)));
            if (i == 3)
                fire.Velocity = new Vector2((float)Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)), (float)-Math.Sqrt((Math.Pow(fire.Speed, 2) / 2)));
            fire.StartingPosition = fire.GlobalPosition;
            fire.AddToList(fire);
        }
    }
}