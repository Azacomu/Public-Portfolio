﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;



//Class for the knockbackcircle animation
class KnockBackCircle : AnimatedGameObject
{
    public KnockBackCircle() : base("knockback", 1)
    {
        LoadAnimation("knockback", "knockback", false, 0.055f);
        PlayAnimation("knockback");
        Origin = sprite.Center;
        this.sprite.Scale = 7f;
    }
    //Plays the explosion animation and removes this after the animation ended
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        PlayAnimation("knockback");
        if (animations["knockback"].AnimationEnded)
        {
            GameData.LevelObjects.Remove(this);
        }
    }
}


