﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the sugary substance item which increases player movement speed for 2 minutes
class SugarySubstance : Items
{
    protected double sugartimer;
    protected bool tooksugar;
    protected double duration;
    public SugarySubstance(string itemtype = "Consumable", string assetName = "sugar", string id = "sugarysubstance") : base(itemtype, assetName, 0, id)
    {
        sugartimer = 0;
        tooksugar = false;
        duration = 120;
        ItemDescription = "ENERGY!!!!!";
        itemName = "Sugar";
    }
    //Use the item and add it to the powerups list in Inventory.cs, ups the player movement speed 
    public override void UseItem()
    {
        base.UseItem();
        GameData.GetPlayer.MovementSpeed += 150;
        tooksugar = true;
        GameData.GetPlayer.Inventory.PowerUps.Add(this);
    }
    //Sets a timer after which the effects wears off and remove this item from powerups list in Inventory.cs
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        if (tooksugar)
        {
            sugartimer += gameTime.ElapsedGameTime.TotalSeconds;
            if (sugartimer >= duration)
            {
                GameData.GetPlayer.MovementSpeed -= 200;
                sugartimer = 0;
                Notification noMoreSugar = new Notification("No more sugar:", "Your sugar high ran out", "", 2);
                noMoreSugar.CreateNotification();
                GameData.GetPlayer.Inventory.PowerUps.Remove(this);
            }
        }
    }
}

