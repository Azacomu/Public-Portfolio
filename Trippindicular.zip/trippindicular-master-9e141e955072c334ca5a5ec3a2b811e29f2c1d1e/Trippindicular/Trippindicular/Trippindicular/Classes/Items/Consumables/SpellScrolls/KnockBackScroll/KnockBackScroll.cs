﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the KnockBackScroll spellscroll, which knockbacks enemies within its radius and creates a little animation
class KnockBackScroll : Items
{
    protected double radius;
    //Position of the player
    Vector2 ppos;

    public KnockBackScroll() : base("Consumable", "spellScroll", 0, "knockbackscroll")
    {
        radius = 300;
        ppos = GameData.GetPlayer.GlobalPosition;
        ItemDescription = "Consume to knock back nearby enemies";
        itemName = "Knock back spell";
    }
    public override void UseItem()
    {
        base.UseItem();
        GameWorld.AssetLoader.PlaySound("knockbackscroll");
        KnockBackEnemies();
        KnockBackCircle animation = new KnockBackCircle();
        animation.Position = GameData.GetPlayer.GlobalPosition;
        GameData.LevelObjects.Add(animation);
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        ppos = GameData.GetPlayer.GlobalPosition;
    }
    //Checks for each enemy if it is within the radius of the player, if so it knocks it back
    protected void KnockBackEnemies()
    {
        GameWorld.AssetLoader.PlaySound("knockbackscroll");
        for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
            if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
            {
                GeneralEnemy enemy = GameData.LevelObjects.Objects[i] as GeneralEnemy;
                if (Math.Sqrt(Math.Pow((ppos.X - enemy.GlobalPosition.X),2) + Math.Pow((ppos.Y - enemy.GlobalPosition.Y),2)) < this.radius)
                {
                    enemy.KnockBackTimer = 1.3f;
                    enemy.KnockBacked = true;
                }
        }
    }
}