﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class MysteryPotion : Items
{
    int droprate = R.Dice(100), index;

    public MysteryPotion(string itemtype = "Consumable", int layer = 0, string id = "mysteryPotion") : base(itemtype, "potions", 0, "mysteryPotion")
    {
        //setting the sheetindex so we can use the right sprite for each potion from a sheet 
        if (droprate <= 5)
        {
            Sprite.SheetIndex = 1;
            Log.Write(LogType.INFO, "1");
        }
        else if (droprate <= 15)
        {
            Sprite.SheetIndex = 2;
            Log.Write(LogType.INFO, "2");
        }
        else if (droprate <= 20)
        {
            Sprite.SheetIndex = 3;
            Log.Write(LogType.INFO, "3");
        }
        else if (droprate <= 33)
        {
            Sprite.SheetIndex = 4;
            Log.Write(LogType.INFO, "4");
        }
        else if (droprate <= 40)
        {
            Sprite.SheetIndex = 5;
            Log.Write(LogType.INFO, "5");
        }
        else if (droprate <= 60)
        {
            Sprite.SheetIndex = 6;
            Log.Write(LogType.INFO, "6");
        }
        else if (droprate <= 70)
        {
            Sprite.SheetIndex = 7;
            Log.Write(LogType.INFO, "7");
        }
        else if (droprate <= 90)
        {
            Sprite.SheetIndex = 8;
            Log.Write(LogType.INFO, "8");
        }
        else if (droprate <= 100)
        {
            Sprite.SheetIndex = 9;
            Log.Write(LogType.INFO, "9");
        }

        index = sprite.SheetIndex;
        Log.Write(LogType.INFO, "droprate" + droprate.ToString());
        Log.Write(LogType.INFO, "index" + sprite.SheetIndex.ToString());
        itemName = "Mystery Potion";
    }

    public override void UseItem()
    {
        base.UseItem();
        switch (index)
        {
            //depending on what potion was picked earlier on its decided which effect should be applied when its used
            //effects are defined down below
            case 1:                
                Shield();
                break;
            case 2:
                MaxHealthUp();
                break;
            case 3:
                MaxHealthDown();
                break;
            case 4:
                DamageUp();
                break;
            case 5:
                DamageDown();
                break;
            case 6:
                AttackSpeedUp();
                break;
            case 7:
                AttackSpeedDown();
                break;
            case 8:
                MovSpeedUp();
                break;
            case 9:
                MovSpeedDown();
                break; 
        }
        Notification description = new Notification(itemName, ItemDescription);
        description.CreateNotification();                    
    }

    //Methods for each powerup
    public void MovSpeedUp()
    {
        GameData.GetPlayer.SpeedUp();
        GameWorld.AssetLoader.PlaySound("usePotion3");
        Log.Write(LogType.INFO, "movspeedup");
        ItemDescription = "Movement speed up!";
    }

    public void AttackSpeedUp()
    {
        GameData.GetPlayer.AttSpeedUp();
        GameWorld.AssetLoader.PlaySound("usePotion3");
        Log.Write(LogType.INFO, "atkspdup");
        ItemDescription = "Attack speed up!";
    }

    public void DamageUp()
    {
        GameData.GetPlayer.DamageUp();
        GameWorld.AssetLoader.PlaySound("usePotion4");
        Log.Write(LogType.INFO, "dmgup");
        ItemDescription = "Damage up!";
    }

    public void MaxHealthUp()
    {
        GameData.GetPlayer.HealthUp();
        GameWorld.AssetLoader.PlaySound("usePotion2");
        Log.Write(LogType.INFO, "mxhlthup");
        ItemDescription = "Maximum health up!";
    }

    public void Shield()
    {
        GameData.GetPlayer.Shield();
        GameWorld.AssetLoader.PlaySound("usePotion5");
        Log.Write(LogType.INFO, "invinc");
        ItemDescription = "Shield!";
    }

    public void MovSpeedDown()
    {
        GameData.GetPlayer.SpeedDown();
        GameWorld.AssetLoader.PlaySound("usePotion9");
        Log.Write(LogType.INFO, "mvspddwn");
        ItemDescription = "Movement speed down!";
    }

    public void AttackSpeedDown()
    {
        GameData.GetPlayer.AttSpeedDown();
        GameWorld.AssetLoader.PlaySound("usePotion11");
        Log.Write(LogType.INFO, "atkspeeddwn");
        ItemDescription = "Attack speed down!";
    }

    public void DamageDown()
    {
        GameData.GetPlayer.DamageDown();
        GameWorld.AssetLoader.PlaySound("usePotion10");
        Log.Write(LogType.INFO, "damagedown");
        ItemDescription = "Damage down!";
    }

    public void MaxHealthDown()
    {
        GameData.GetPlayer.HealthDown();
        GameWorld.AssetLoader.PlaySound("usePotion7");
        Log.Write(LogType.INFO, "maxhealthdown");
        ItemDescription = "Maximum health down!";
    }
}

