﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Class for the StartingWand weapon, shoots a projectile when used.
class StartingWand : Weapon
{
    public StartingWand(string itemtype = "RightHand", string assetName = "wand", string id = "startingwand") : base(itemtype, assetName, 0, id)
    {
        this.Damage = 2.5f;
        this.Range = 400;
        this.Cooldown = 0.9;
        this.weaponSprite = new StartingWandSpr();
        ItemDescription = "Use the attack button to fire magic";
        itemName = "Magic Wand:";
    }

    //Can only be used after the item is off cooldown, shoots a startingwandprojectile
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            base.UseItem();
            GameWorld.AssetLoader.PlaySound("fireball");
            StartingWandProjectile wandprojectile = new StartingWandProjectile();
            if (GameData.GetPlayer.Direction == "up" || GameData.GetPlayer.Direction == "down")
            {
                wandprojectile.ShootOneProjectile(wandprojectile, this, 0);
            }
            else { wandprojectile.ShootOneProjectile(wandprojectile, this, GameData.GetPlayer.Sprite.Center.Y); }
        }
    }
}

