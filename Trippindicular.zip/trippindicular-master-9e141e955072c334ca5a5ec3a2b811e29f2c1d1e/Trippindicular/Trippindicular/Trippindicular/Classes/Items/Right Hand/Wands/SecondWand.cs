﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Class for the Second weapon, shoots a homing projectile when used.
class SecondWand : Weapon
{
    public SecondWand(string itemtype = "RightHand", string assetName = "secondwand", string id = "secondwand") : base(itemtype, assetName, 0, id)
    {
        this.Damage = 3.5f;
        this.Range = 400;
        this.Cooldown = 0.9;
        this.weaponSprite = new SecondWandSpr();
        ItemDescription = "Target seeking magic";
        itemName = "Homing Wand";
    }

    //Can only be used after the item is off cooldown, shoots a wand projectile
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            base.UseItem();
            GameWorld.AssetLoader.PlaySound("fireball");
            SecondWandProjectile wandprojectile = new SecondWandProjectile();
            if (GameData.GetPlayer.Direction == "up" || GameData.GetPlayer.Direction == "down")
            {
                wandprojectile.ShootOneProjectile(wandprojectile, this, 0);
            }
            else { wandprojectile.ShootOneProjectile(wandprojectile, this, GameData.GetPlayer.Sprite.Center.Y); }
        }
    }
}

