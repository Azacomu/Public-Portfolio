﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//General class all swords inherit from, creates a hitbox depending on the sword's range and position and updates it.
class Sword : Weapon
{
    protected Rectangle hitBox;

    public Rectangle HitBox => this.hitBox;

    public Sword(string itemtype = "RightHand", string assetName = "", int sheetIndex = 0, string id = "") : base(itemtype, assetName, sheetIndex, id)
    {
        this.Range = 80;
    }

    //Updates hitbox
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        UpdateHitBox();
    }
    //Checks if any enemies are hit
    public override void UseItem()
    {
        base.UseItem();
        CheckForEnemiesHit();
    }
    //Creates a hitbox depending on where the player is facing, the player position and the sword's range
    public void UpdateHitBox()
    {
        {
            if (GameData.GetPlayer.Direction == "left")
            {
                int left = ((int)(GameData.GetPlayer.BoundingBox.Left - Range+GameData.GetPlayer.Sprite.Center.X));
                int top = (int)GameData.GetPlayer.BoundingBox.Top;
                hitBox = new Rectangle(left, top, (int)Range, GameData.GetPlayer.Height);
            }

            else if (GameData.GetPlayer.Direction == "right")
            {
                int left = ((int)(GameData.GetPlayer.BoundingBox.Right- GameData.GetPlayer.Sprite.Center.X));
                int top = ((int)GameData.GetPlayer.BoundingBox.Top);
                hitBox = new Rectangle(left, top, (int)Range, GameData.GetPlayer.Height);
            }
            else if (GameData.GetPlayer.Direction == "up")

            {
                int left = ((int)GameData.GetPlayer.BoundingBox.Left);
                int top = (int)(GameData.GetPlayer.BoundingBox.Top - Range + GameData.GetPlayer.Sprite.Center.Y);
                hitBox = new Rectangle(left, top, GameData.GetPlayer.Width, (int)(Range+GameData.GetPlayer.Sprite.Center.Y));
            }
            else
            {
                int left = (int)GameData.GetPlayer.BoundingBox.Left;
                int top = (int)(GameData.GetPlayer.BoundingBox.Bottom-GameData.GetPlayer.Sprite.Center.Y);
                hitBox = new Rectangle(left, top, GameData.GetPlayer.Width, (int)Range);
            }
        }

    }
    //Method that checks if there are enemies in the hitbox and if so, the itemeffect method is used.
    protected void CheckForEnemiesHit()
    {
        for (int i = 0; i < GameData.LevelObjects.Objects.Count; i++)
        {
            if (GameData.LevelObjects.Objects[i] is GeneralEnemy)
            {
                GeneralEnemy enemy = GameData.LevelObjects.Objects[i] as GeneralEnemy;
                if (hitBox.Intersects(enemy.BoundingBox))
                {
                    ItemEffect(enemy);
                }
            }

        }
    }
    //Method for the itemeffect of the sword upon hitting enemies.
    protected virtual void ItemEffect(GeneralEnemy enemy)
    {

    }
}

