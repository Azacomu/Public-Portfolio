﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the BareHands weapon, this is the weapon you start with, acts like a basic sword with lower damage
class BareHands : Sword
{
    protected Timer stopMoveTimer;
    protected const float stopMoveTime = 0.2f;
    public BareHands() : base("RightHand", "fist", 0, "bareHands")
    {
        this.Range = 50;
        this.Cooldown = 0.7;
        this.Damage = 1.5f;
        this.Visible = false;
        stopMoveTimer = new Timer(stopMoveTime);
    }

    //Updates the timer for stopping the player from moving when attacking
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        stopMoveTimer.Update(gameTime);
        if(stopMoveTimer.Ended)
        GameData.GetPlayer.StopAttack();
    }
    //Can only be used when it is off cooldown, player stops moving for some time
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            base.UseItem();
            GameData.GetPlayer.Attack();
            stopMoveTimer.Reset();
        }
    }
    //Damages enemies, knocks them back a small bit, plays hit sound.
    protected override void ItemEffect(GeneralEnemy enemy)
    {
        enemy.EnemyHealth -= this.Damage;
        enemy.KnockBackTimer = 0.3f;
        enemy.KnockBacked = true;
    }
}
    

