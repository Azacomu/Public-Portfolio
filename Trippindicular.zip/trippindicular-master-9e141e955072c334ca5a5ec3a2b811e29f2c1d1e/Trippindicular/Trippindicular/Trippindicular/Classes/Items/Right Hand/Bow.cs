﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//General class where each bow inherits from, general PickUp method and UseItem method for bows are included
class Bow : Weapon
{

    public Bow(string itemtype = "RightHand", string assetName = "", int sheetIndex = 0, string id = "") : base(itemtype, assetName, sheetIndex, id)
    {
    }

    //Picks up crystalarrows or woodenarrows with the bow, depending on if the player has the powerup
    public override void PickUp()
    {
        base.PickUp();
        if (GameData.GetPlayer.Inventory.HasCrystalArrows)
        {
            CrystalArrow crarrow = new CrystalArrow();
            if (crarrow.Position.X + 50 < 1600)
                crarrow.Position = this.Position + new Vector2(50, 0);
            else crarrow.Position = this.Position + new Vector2(-50, 0);
            GameData.GetPlayer.Inventory.AddItem(crarrow);
        }
        else
        {
            WoodArrow warrow = new WoodArrow();
            if (warrow.Position.X + 50 < 1600)
                warrow.Position = this.GlobalPosition + new Vector2(50, 0);
            else warrow.Position = this.GlobalPosition + new Vector2(-50, 0);
            GameData.GetPlayer.Inventory.AddItem(warrow);
        }
    }
    //Uses the arrow item, AKA the 2nd inventory slot
    public override void UseItem()
    {
        if (GameData.GetPlayer.Inventory.GetItem(1) is Arrow)
        {
            base.UseItem();
            GameData.GetPlayer.Inventory.GetItem(1).UseItem();
        }
    }
}