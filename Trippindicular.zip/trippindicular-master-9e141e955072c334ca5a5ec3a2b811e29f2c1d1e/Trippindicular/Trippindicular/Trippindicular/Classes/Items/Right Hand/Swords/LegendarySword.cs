﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Class for the Legendary Sword of Xuscua weapon, is dropped by the end game boss, if picked up the game switches to the finish GameState
class LegendarySword : Sword
{

    public LegendarySword(string id = "legendarysword", int layer = 0, string itemtype = "RightHand") : base(itemtype, "xuscua", 0, id)
    {
        this.Cooldown = 0.7;
        this.Damage = 30;
        this.weaponSprite = new LaginatorSpr();
        ItemDescription = "You did it";
        itemName = "Legendary Sword";
    }

    //Can only be used when off cooldown, plays swing sound
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            base.UseItem();
            GameWorld.AssetLoader.PlaySound("startingSwordSwing");
        }
    }
    public override void PickUp()
    {
        base.PickUp();
        GameWorld.GameStateManager.SwitchTo("finish");
    }
    //Damages enemies, knocks them back a small bit, plays hit sound.
    protected override void ItemEffect(GeneralEnemy enemy)
    {
        GameWorld.AssetLoader.PlaySound("startingSwordHit");
        enemy.EnemyHealth -= this.Damage * GameData.GetPlayer.Damage;
        enemy.KnockBackTimer = 0.4f;
        enemy.KnockBacked = true;
    }
}


