﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for the Laginator sword, which creates a list for enemies hit, corresponding timers, and amount of poisonticks on that enemy
//deals damage overtime for amountOfTicks times, removes these objects from the lists afterwards
class Laginator : Sword
{
    protected const float timeBetweenTicks=0.8f;
    protected const int amountOfTicks = 5;
    List<GeneralEnemy> hitEnemies;
    List<Timer> timerList;
    List<int> tickTracker;

    public Laginator(string id = "laginator", int layer = 0, string itemtype = "RightHand") : base(itemtype, "laginator", 0, id)
    {
        this.Cooldown = 0.7;
        this.Damage = 1;
        hitEnemies = new List<GeneralEnemy>();
        tickTracker = new List<int>();
        timerList = new List<Timer>();
        this.weaponSprite = new LaginatorSpr();
        ItemDescription = "Don't touch the blade";
        itemName = "Poisonous Sword";
    }
    //Updates the lists to track enemies timers and poisonticks
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        UpdateLists(gameTime);
    }
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            base.UseItem();
        }
    }
 
    //After a timer in the list of timers has ended, deals the dmg to the corresponding enemy and if the enemy has been hit 'amountOfticks' times, removes the enemy
    //with corresponding timer and ticktracker from the list.
    protected void UpdateLists(GameTime gameTime)
    {
        for (int i = 0; i < timerList.Count; i++)
        {
            if (timerList[i] != null)
            {
                timerList[i].Update(gameTime);
                if (timerList[i].Ended)
                {
                    if (tickTracker[i] < amountOfTicks)
                    {
                        hitEnemies[i].EnemyHealth -= Damage * GameData.GetPlayer.Damage;
                        tickTracker[i] += 1;
                        timerList[i].Reset();
                    }
                    else
                    {
                        hitEnemies.Remove(hitEnemies[i]);
                        timerList.Remove(timerList[i]);
                        tickTracker.Remove(tickTracker[i]);
                    }
                }
            }
        }
    }
    
    //Adds enemies to hitEnemies list, sets a timer for that enemy, and an int starting at 0 to track how many times it has been damaged by poison.
    protected override void ItemEffect(GeneralEnemy enemy)
    {
        hitEnemies.Add(enemy);
        Timer timer = new Timer(timeBetweenTicks);
        timerList.Add(timer);
        tickTracker.Add(0);
    }
}


