﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//General class all weapons inherit from, properties for weapons are introduced and the weapon sprites for in Soren's hand updated and drawn.
class Weapon : Items
{
    protected double range;
    protected float damage;
    protected bool usedWeapon;
    protected WeaponsInHand weaponSprite;

    public double Range
    {
        get { return range; }
        set { range = value; }
    }
    public float Damage
    {
        get { return damage; }
        set { damage = value; }
    }
    public bool UsedWeapon
    {
        get { return usedWeapon; }
        set { usedWeapon = value; }
    }
    public Weapon(string itemtype = "RightHand", string assetName = "", int sheetIndex = 0, string id = "") : base(itemtype, assetName, sheetIndex, id)
    {
    }

    //Sets UsedWeapon to true so that the weaponSprite knows to play the attackanimation
    public override void UseItem()
    {
        base.UseItem();
        this.UsedWeapon = true;
    }

    //Updates the weaponSprite for in Soren's hand
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        if (this.Equipped)
            this.weaponSprite?.Update(gameTime);
    }

    //Draws the weaponSprite for in Soren's hand
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        if (this.Equipped)
            this.weaponSprite?.Draw(gameTime, spriteBatch);
    }
}