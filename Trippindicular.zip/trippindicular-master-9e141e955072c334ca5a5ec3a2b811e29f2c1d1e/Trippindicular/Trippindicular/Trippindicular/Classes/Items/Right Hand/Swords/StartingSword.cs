﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//Class for the StartingSword weapon, has a usedSword bool which is set to true during the animation of the StartingSwordSpr.cs SpriteGameObject.
class StartingSword : Sword
{
    Timer kek;
    public StartingSword(string id = "startingsword", int layer = 0, string itemtype = "RightHand") : base(itemtype, "startingsword", 0, id)
    {
        this.Cooldown = 0.7;
        this.Damage = 3;
        this.weaponSprite = new StartingSwordSpr();
        ItemDescription2 = "Use the attack button to attack infront of you";
        ItemDescription = "For experienced players";
        itemName = "Wooden Sword:";
        kek = new Timer(0.1f);
    }
  
   //Can only be used when off cooldown, plays swing sound
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            base.UseItem();
            GameWorld.AssetLoader.PlaySound("startingSwordSwing");        
        }
    }
    //Damages enemies, knocks them back a small bit, plays hit sound.
    protected override void ItemEffect(GeneralEnemy enemy)
    {
        GameWorld.AssetLoader.PlaySound("startingSwordHit");
        enemy.EnemyHealth -= this.Damage*GameData.GetPlayer.Damage;
        enemy.KnockBackTimer = 0.4f;
        enemy.KnockBacked = true;
    }
}


