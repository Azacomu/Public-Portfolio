﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

//Class for TheDoubleTeam bow, changes the property HasDoubleTeamer in inventory
class TheDoubleTeam : Bow
{
    public TheDoubleTeam(string id = "thedoubleteam", int layer = 0, string itemtype = "RightHand") : base(itemtype, "doubleteam", 0, id)
    {
        this.Range = 500;
        this.Damage = 1;
        this.Cooldown = 0.7;
        this.weaponSprite = new TheDoubleTeamSpr();
        this.ItemDescription = "For when one just isn't enough";
        itemName = "Double teamer";
    }
    //Has a cooldown
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            GameWorld.AssetLoader.PlaySound("bowShot");
            base.UseItem();
        }
    }
    //Sets property in inventory to true
    public override void PickUp()
    {
        base.PickUp();
        GameData.GetPlayer.Inventory.HasDoubleTeamer = true;
    }
}


