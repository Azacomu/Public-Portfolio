﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
//Class for the WoodenBow bow, changes the property HasDoubleTeamer in inventory
class WoodenBow : Bow
{
    public WoodenBow(string id = "woodenbow", int layer = 0, string itemtype = "RightHand") : base(itemtype, "bow", 0, id)
    {
        this.Range = 400;
        this.Damage = 1;
        this.Cooldown = 0.7;
        this.weaponSprite = new StartingBowSpr();
        ItemDescription = "Use the attack button to shoot an arrow";
        itemName = "Wooden Bow:";
    }
    //Has a cooldown
    public override void UseItem()
    {
        if (IsOffCooldown)
        {
            GameWorld.AssetLoader.PlaySound("bowShot");
            base.UseItem();
        }
    }
    //Sets HasDoubleTeamer in inventory to false, since a player will never have both this and TheDoubleTeamer
    public override void PickUp()
    {
        base.PickUp();
        GameData.GetPlayer.Inventory.HasDoubleTeamer = false;
    }
}


