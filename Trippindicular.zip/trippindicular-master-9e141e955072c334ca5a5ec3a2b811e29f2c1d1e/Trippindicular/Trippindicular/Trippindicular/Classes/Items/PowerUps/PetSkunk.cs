﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Class for Azalea item, changed PickUp method, creates a DeadSisterSpr to add to the inventory
class PetSkunk : Items
{
    public PetSkunk() : base("PowerUp", "azalea")
    {
        this.ItemDescription = "You found Azalea!";
        itemName = "Azalea";
    }
    //Adds the SpriteGameObject for the PetSkunk to powerups
    public override void PickUp()
    {
        DeadSisterSpr deadSis = new DeadSisterSpr();
        deadSis.Position = GameData.GetPlayer.Position;
        GameData.GetPlayer.Inventory.AddItem(deadSis);
        base.PickUp();
    }
}