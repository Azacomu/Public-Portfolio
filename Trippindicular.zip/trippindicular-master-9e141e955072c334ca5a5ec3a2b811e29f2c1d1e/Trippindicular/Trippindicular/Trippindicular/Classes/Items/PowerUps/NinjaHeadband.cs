﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

//Class for the NinjaHeadband item, has a CheckForDoubleTap method which detects if the enemy double tapped the movement key in a certain direction. 
//Also has a UseItem method that is used when this happens, which makes the player dash in that direction.
class NinjaHeadband : Items
{
    protected float timeBetweenTaps;
    protected float buttonCooler;
    protected int buttonCountW;
    protected int buttonCountA;
    protected int buttonCountS;
    protected int buttonCountD;
    protected bool isDashing;
    Vector2 dashVelocity;
    protected float dashTimer;
    HealthBar cooldownBar;


    public NinjaHeadband(string itemtype = "PowerUp") : base(itemtype, "headband", 0, "ninjaheadband")
    {
        this.Cooldown = 1.0;
        timeBetweenTaps = 0.25f;
        buttonCooler = timeBetweenTaps;
        buttonCountW = 0;
        dashTimer = 0;
        CooldownTimer = Cooldown;
        isDashing = false;
        cooldownBar = new HealthBar(new Vector2(800, 500));
        this.ItemDescription = "Double tap in a direction to dash";
        itemName = "Ninja Headband";
    }
    //checks for double tap and increases the doubletapTimer
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        if (isDashing)
        {
            dashTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
            GameData.GetPlayer.Velocity = dashVelocity;
            if (dashTimer > 0.25)
            {
                isDashing = false;
                dashTimer = 0;
            }
        }
        UpdateButtonTap(gameTime);
        UpdateCooldownBar();   
    }
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        if(Equipped)
        cooldownBar.Draw(gameTime, spriteBatch);
    }
    protected void UpdateCooldownBar()
    {
        cooldownBar.Update(new Vector2(GameData.GetPlayer.BoundingBox.Center.X, GameData.GetPlayer.BoundingBox.Top));
        if ((this.CooldownTimer / this.Cooldown) > 1)
        {
            cooldownBar.ChangeHealth(1);
            cooldownBar.Visible = false;
        }
        else
        {
            cooldownBar.ChangeHealth((float)this.CooldownTimer / (float)this.Cooldown);
            cooldownBar.Visible = true;
        }
    }
    public override void UseItem()
    {// TODO: Dash method for player.
        if (IsOffCooldown)
        {
            base.UseItem();
            if (GameData.GetPlayer.Direction == "up")
            {
                dashVelocity = new Vector2(0, -GameData.GetPlayer.MovementSpeed-700);
            }
            else if (GameData.GetPlayer.Direction == "down")
            {
                dashVelocity = new Vector2(0, GameData.GetPlayer.MovementSpeed + 700);
            }
            else if (GameData.GetPlayer.Direction == "left")
            {
                dashVelocity = new Vector2(-GameData.GetPlayer.MovementSpeed - 700,0);
            }
            else if (GameData.GetPlayer.Direction == "right")
            {
                dashVelocity = new Vector2(GameData.GetPlayer.MovementSpeed + 700,0);
            }
            isDashing = true;
        }
    }
    //If the player presses a move button twice in rapid succession, UseItem (aka dash in that direction)
    public override void HandleInput(InputHelper ih)
    {
        if (ih.KeyPressed(Keys.W))
        {

            if (buttonCooler > 0 && buttonCountW == 1/*Number of Taps you want Minus One*/)
            {
                //Has double tapped
                GameData.GetPlayer.Direction = "up";
                UseItem();
            }
            else
            {
                buttonCooler = timeBetweenTaps;
                buttonCountW += 1;
            }
        }
        if (ih.KeyPressed(Keys.A))
        {

            if (buttonCooler > 0 && buttonCountA == 1/*Number of Taps you want Minus One*/)
            {
                //Has double tapped
                GameData.GetPlayer.Direction = "left";
                UseItem();
            }
            else
            {
                buttonCooler = timeBetweenTaps;
                buttonCountA += 1;
            }
        }
        if (ih.KeyPressed(Keys.S))
        {

            if (buttonCooler > 0 && buttonCountS == 1/*Number of Taps you want Minus One*/)
            {
                //Has double tapped
                GameData.GetPlayer.Direction = "down";
                UseItem();
            }
            else
            {
                buttonCooler = timeBetweenTaps;
                buttonCountS += 1;
            }
        }
        if (ih.KeyPressed(Keys.D))
        {

            if (buttonCooler > 0 && buttonCountD == 1/*Number of Taps you want Minus One*/)
            {
                //Has double tapped
                GameData.GetPlayer.Direction = "right";
                UseItem();
            }
            else
            {
                buttonCooler = timeBetweenTaps;
                buttonCountD += 1;
            }
        }
    }
    //Updates the button tap, cools it down and resets the counts
    protected void UpdateButtonTap(GameTime gameTime)
    {
        if (buttonCooler > 0)
        {

            buttonCooler -= (float)gameTime.ElapsedGameTime.TotalSeconds;

        }
        else
        {
            buttonCountW = 0;
            buttonCountA = 0;
            buttonCountS = 0;
            buttonCountD = 0;
        }
    }
}
