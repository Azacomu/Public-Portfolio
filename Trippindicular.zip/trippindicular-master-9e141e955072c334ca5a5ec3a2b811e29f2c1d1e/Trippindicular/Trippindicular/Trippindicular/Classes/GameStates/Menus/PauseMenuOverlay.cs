﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class creates an overlay for when the game is paused
/// </summary>

class PauseMenuOverlay : GameObjectList
{
    IGameLoopObject hud;

    protected SpriteGameObject background;

    protected Button exitMenu, exitGame, options, back, achievements;    

    public PauseMenuOverlay()
    {
        //Initialize hud
        hud = GameWorld.GameStateManager.GetGameState("hud");

        //Starting values

        //Background
        background = new SpriteGameObject("blackDrop");
        this.Add(background);

        //Buttons
        back = new Button("button", "buttonFont", "font", 0, "Continue game", 5);
        back.Position = new Vector2(300, 280);
        this.Add(back);

        options = new Button("button", "buttonFont", "font", 0, "Options", 5);
        options.Position = new Vector2(300, 410);
        this.Add(options);

        achievements = new Button("button", "buttonFont", "font", 0, "Achievements", 5);
        achievements.Position = new Vector2(300, 540);
        this.Add(achievements);

        exitMenu = new Button("button", "buttonFont", "font", 0, "Exit to menu", 5);
        exitMenu.Position = new Vector2(300, 670);
        this.Add(exitMenu);

        exitGame = new Button("button", "buttonFont", "font", 0, "Exit game", 5);
        exitGame.Position = new Vector2(300, 800);
        this.Add(exitGame);
    }

    //Handle button input
    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);

        if (back.Pressed || inputHelper.KeyPressed(Keys.Escape))
        {
            GameWorld.GameStateManager.SwitchTo("hud");
        }

        if (options.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("settingsMenuPause").Reset();
            GameWorld.GameStateManager.SwitchTo("settingsMenuPause");
        }

        if (achievements.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("achievementsPause").Reset();
            GameWorld.GameStateManager.SwitchTo("achievementsPause");
        }

        if (exitMenu.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("titleMenu").Reset();
            GameWorld.GameStateManager.SwitchTo("titleMenu");
        }

        if (exitGame.Pressed)
        {
            GameWorld.Exited = true;
        }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
    }

    public override void Reset()
    {
        hud.Reset();
        base.Reset();
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        hud.Draw(gameTime, spriteBatch);
        base.Draw(gameTime, spriteBatch);
    }
}


