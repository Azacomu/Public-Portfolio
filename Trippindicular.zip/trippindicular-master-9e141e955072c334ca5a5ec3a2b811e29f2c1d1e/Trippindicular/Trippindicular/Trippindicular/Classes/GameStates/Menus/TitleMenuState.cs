﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

/// <summary>
/// This class creates the title menu
/// </summary>
class TitleMenuState : GameObjectList
{
    protected Button newGame, loadGame, options, achievements, highscores, credits, exitGame;
    protected SpriteGameObject background;
    protected PlayingState playingState;
    protected string saved;
    protected bool saveExists;

    public TitleMenuState()
    {
        //Plays menu backgroundmusic.
        GameWorld.AssetLoader.PlayMusic("menumusic");

        //Initialize playingState
        playingState = GameWorld.GameStateManager.GetGameState("playing") as PlayingState;

        //Starting values

        //Background
        background = new SpriteGameObject("menuBackground");
        this.Add(background);

        //Make buttons
                //New Game
                newGame = new Button("button", "buttonFont", "font", 0, "New Game", 0);
                newGame.Position = new Vector2(300, 150);
                this.Add(newGame);

                //Load Game
                saveExists = PlayingState.SaveGame.CheckSaveFile();
                if (saveExists)
                    saved = "button";
                else
                    saved = "disabledButton";

                loadGame = new Button(saved, "buttonFont", "font", 0, "Load Game", 0);
                loadGame.Position = new Vector2(300, 280);
                this.Add(loadGame);

                //Options
                options = new Button("button", "buttonFont", "font", 0, "Options", 0);
                options.Position = new Vector2(300, 410);
                this.Add(options);

                //Achievements
                achievements = new Button("button", "buttonFont", "font", 0, "Achievements", 0);
                achievements.Position = new Vector2(300, 540);
                this.Add(achievements);

                //Highscores
                highscores = new Button("button", "buttonFont", "font", 0, "Highscores", 0);
                highscores.Position = new Vector2(300, 670);
                this.Add(highscores);

                //Credits
                credits = new Button("button", "buttonFont", "font", 0, "Credits", 0);
                credits.Position = new Vector2(300, 800);
                this.Add(credits);

                //Exit Game
                exitGame = new Button("button", "buttonFont", "font", 0, "Exit Game", 0);
                exitGame.Position = new Vector2(300, 930);
                this.Add(exitGame);
    }

    //Reset load button state
    public override void Reset()
    {
        //Base
        base.Reset();
        this.Remove(loadGame);
        saveExists = PlayingState.SaveGame.CheckSaveFile();
        if (saveExists)
            saved = "button";
        else
            saved = "disabledButton";
        loadGame = new Button(saved, "buttonFont", "font", 0, "Load Game", 0);
        loadGame.Position = new Vector2(300, 280);
        this.Add(loadGame);
        
    }

    //Handle button input
    public override void HandleInput(InputHelper inputHelper)
    {
        //base
        base.HandleInput(inputHelper);

        //Buttons
        if (newGame.Pressed)
        {
            playingState.Initialize(true);
            GameWorld.GameStateManager.SwitchTo("hud");
        }
        else if (loadGame.Pressed && saveExists)
        {
            playingState.Initialize(false);
            GameWorld.GameStateManager.SwitchTo("hud");
        }
        else if (options.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("settingsMenuTitle").Reset();
            GameWorld.GameStateManager.SwitchTo("settingsMenuTitle");
        }
        else if (achievements.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("achievementsTitle").Reset();
            GameWorld.GameStateManager.SwitchTo("achievementsTitle");
        }
        else if (highscores.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("highscoresTitle").Reset();
            GameWorld.GameStateManager.SwitchTo("highscoresTitle");
        }
        else if (credits.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("credits").Reset();
            GameWorld.GameStateManager.SwitchTo("credits");
            MainGame.AchievementController.FinishAchievement("Thank You");
        }
        else if (exitGame.Pressed)
            GameWorld.Exited = true;
    }
}
