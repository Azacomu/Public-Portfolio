﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

/// <summary>
/// This class creates an overlay to show credits to the project.
/// </summary>
class CreditsOverlay : GameObjectList
{
    protected IGameLoopObject titleMenuState;
    protected GameObjectList credits;

    protected DropDown scroll;

    protected TextGameObject title;
    protected TextGameObject[] roles;


    public CreditsOverlay()
    {
        //Initialize title menu state
        titleMenuState = GameWorld.GameStateManager.GetGameState("titleMenu");

        //Create gameObjectList
        credits = new GameObjectList();

        //Starting values

        //Scroll
        scroll = new DropDown("scroll", new Vector2(600, -1000));
        scroll.Speed = 600;
        scroll.Drop = true;

        //Menu title
        title = new TextGameObject("buttonFont", 1);
        title.Position = scroll.Position + new Vector2(150, 50);
        title.Text = "Credits";
        credits.Add(title);

        //Roles
        roles = new TextGameObject[7];

        for (int i = 0; i < roles.GetLength(0); i++)
        {
            roles[i] = new TextGameObject("font", 1);
        }

        roles[0].Text = "Martin Boers - Lead Programmer, Engine Programmer and Project Manager";
        roles[1].Text = "Diego Consen - Creative director, UI-Designer, Lead Artist and Animator";
        roles[2].Text = "Timo van Milligen - Item Programmer";
        roles[3].Text = "Matthijs Rademaker - AI Programmer and Blogger";
        roles[4].Text = "Bram Smit - Audio Engineer and Item Programmer";
        roles[5].Text = "Thomas Uitdewilligen - AI Programmer";
        roles[6].Text = "Mees van Winkoop - Level Editor, Public Relations Officer";

        for (int i = 0; i < roles.GetLength(0); i++)
        {
            roles[i].Position = scroll.Position + new Vector2(175, 150 + ((i * (roles[i].Size.Y + 50))));
            credits.Add(roles[i]);
        }

        credits.Add(scroll);
        this.Add(credits);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        titleMenuState.HandleInput(inputHelper);
        credits.HandleInput(inputHelper);
    }

    //Update positions
    public override void Update(GameTime gameTime)
    {
        titleMenuState.Update(gameTime);

        title.Position = scroll.Position + new Vector2(150, 50);

        for (int i = 0; i < roles.GetLength(0); i++)
        {
            roles[i].Position = scroll.Position + new Vector2(175, 150 + ((i * (roles[i].Size.Y + 50))));
        }

        credits.Update(gameTime);
    }

    public override void Reset()
    {
        titleMenuState.Reset();
        credits.Reset();
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        titleMenuState.Draw(gameTime, spriteBatch);
        credits.Draw(gameTime, spriteBatch);
    }
}
