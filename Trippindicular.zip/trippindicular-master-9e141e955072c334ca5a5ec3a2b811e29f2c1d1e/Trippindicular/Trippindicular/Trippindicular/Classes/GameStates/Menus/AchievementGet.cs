﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

/// <summary>
/// This class creates an achievement dropdown
/// </summary>

public class AchievementGet : DropDown
{
    protected int getAchievement;
    protected AchievementBlock achievementBlock;

    protected List<Achievement> allAchievements;
    protected float timer;

    public AchievementGet(string assetName, Vector2 startPosition, int achievement) : base (assetName, startPosition)
    {
        //Initialize achievement list
        allAchievements = MainGame.AchievementController.GetAchievementList();

        //Starting values

        achievementBlock = new AchievementBlock("achievements", achievement + allAchievements.Count, "title", "description");
        achievementBlock.Position = this.Position + new Vector2(10, 10);
        achievementBlock.Title.Text = allAchievements[achievement].Name;
        achievementBlock.Description.Text = allAchievements[achievement].Info;
        drop = true;
        timer = 0;
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
    }

    //Update positions
    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        timer += (float)gameTime.ElapsedGameTime.TotalSeconds;

        achievementBlock.Position = this.Position + new Vector2(50, 32);
        achievementBlock.Update(gameTime);
        if (timer > 6)
        {
            drop = false;
        }
    }

    public override void Reset()
    {
        base.Reset();
        achievementBlock.Reset();
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        achievementBlock.Draw(gameTime, spriteBatch);
    }
}
