﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

/// <summary>
/// This class creates an overlay to show player achievements
/// </summary>
public class AchievementOverlay : GameObjectList
{
    protected IGameLoopObject currentState;
    protected GameObjectList achievements;

    protected TextGameObject title;

    protected DropDown scroll;
    protected List<Achievement> allAchievements;
    protected Table achievementTable;

    //Read and write variables
    public DropDown Scroll
    {
        get { return scroll; }
        set { scroll = value; }
    }

    public IGameLoopObject CurrentState
    {
        get { return currentState; }
        set { currentState = value; }
    }

    public AchievementOverlay(IGameLoopObject state)
    {
        currentState = state;

        achievements = new GameObjectList();

        //Starting values

        //Scroll
        scroll = new DropDown("scroll", new Vector2(600, -1000));
        scroll.Speed = 600;
        scroll.Drop = true;

        //Title
        title = new TextGameObject("buttonFont", 1);
        title.Text = "Achievements";
        title.Position = scroll.Position + new Vector2(150, 50);
        achievements.Add(title);

        //Achievement table
        achievementTable = new Table(2, 8);
        achievementTable.Position = scroll.Position + new Vector2(160, 110);
        achievementTable.Layer = 10;
        achievementTable.CellHeight = 90;

        achievementTable.ColumnPos[0] = 0;
        achievementTable.ColumnPos[1] = 475;

        LoadAchievements();

        achievements.Add(achievementTable);


        achievements.Add(scroll);
        this.Add(achievements);
    }

    //Load achievements
    public void LoadAchievements()
    {
        allAchievements = MainGame.AchievementController.GetAchievementList();

        AchievementBlock temp;

        for (int i = 0; i < (allAchievements.Count / 2); i++)
        {
            if (!allAchievements[i].Finished)
            {
                temp = new AchievementBlock("achievements", i, "title", "description");
                temp.Title.Text = allAchievements[i].Name;
                temp.Description.Text = allAchievements[i].Info;
                achievementTable.Add(temp, 0, i);
            }
            else if (allAchievements[i].Finished)
            {
                temp = new AchievementBlock("achievements", i + allAchievements.Count, "title", "description");
                temp.Title.Text = allAchievements[i].Name;
                temp.Description.Text = allAchievements[i].Info;
                achievementTable.Add(temp, 0, i);
            }

            if (!allAchievements[i + (allAchievements.Count / 2)].Finished)
            {
                temp = new AchievementBlock("achievements", (i + (allAchievements.Count / 2)), "title", "description");
                temp.Title.Text = allAchievements[i + (allAchievements.Count / 2)].Name;
                temp.Description.Text = allAchievements[i + (allAchievements.Count / 2)].Info;
                achievementTable.Add(temp, 1, i);
            }
            else if (allAchievements[i + (allAchievements.Count / 2)].Finished)
            {
                temp = new AchievementBlock("achievements", (i + (allAchievements.Count / 2) + allAchievements.Count), "title", "description");
                temp.Title.Text = allAchievements[i + (allAchievements.Count / 2)].Name;
                temp.Description.Text = allAchievements[i + (allAchievements.Count / 2)].Info;
                achievementTable.Add(temp, 1, i);
            }
        }
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        currentState?.HandleInput(inputHelper);

        achievements.HandleInput(inputHelper);
    }

    //Reset positions and reload achievements
    public override void Reset()
    {
        currentState?.Reset();

        title.Position = new Vector2(-1000, -1000);
        achievementTable.Position = new Vector2(-1000, -1000);

        LoadAchievements();

        achievements.Reset();
    }

    public override void Update(GameTime gameTime)
    {
        currentState?.Update(gameTime);

        title.Position = scroll.Position + new Vector2(150, 50);

        achievementTable.Position = scroll.Position + new Vector2(160, 110);

        achievements.Update(gameTime);
    }



    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        currentState?.Draw(gameTime, spriteBatch);

        achievements?.Draw(gameTime, spriteBatch);
    }
}
