﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

/// <summary>
/// This class creates an overlay to show online highscores
/// </summary>

class HighscoresOverlay : GameObjectList
{
    protected IGameLoopObject titleMenuState;

    protected GameObjectList highscores;

    protected TextGameObject title, sortMode;

    protected Table scores;

    protected Button sortTime, sortCoins, sortEnemies;

    protected DropDown scroll;

    public HighscoresOverlay(IGameLoopObject state)
    {
        titleMenuState = state;
        highscores = new GameObjectList();

        //Scroll
        scroll = new DropDown("scroll", new Vector2(600, -1000));
        scroll.Speed = 600;
        scroll.Drop = true;
        highscores.Add(scroll);

        //Menu title
        title = new TextGameObject("buttonFont", 1);
        title.Position = scroll.Position + new Vector2(150, 50);
        title.Text = "Highscores";
        highscores.Add(title);

        //Highscores table
        scores = new Table(Highscores.colNum, Highscores.entries + 1);
        scores.Position = scroll.Position + new Vector2(200, 125);
        scores.Layer = 10;
        scores.CellHeight = 35;

        scores.ColumnPos[0] = 0;
        scores.ColumnPos[1] = 60;
        scores.ColumnPos[2] = 260;
        scores.ColumnPos[3] = 360;
        scores.ColumnPos[4] = 460;

        LoadHighscores();
        
        highscores.Add(scores);

        //Sort buttons
        sortTime = new Button("mediumButton", "font", "smallFont", 0, "Time");
        sortCoins = new Button("mediumButton", "font", "smallFont", 0, "Coins");
        sortEnemies = new Button("mediumButton", "font", "smallFont", 0, "Enemies");

        sortMode = new TextGameObject("font");
        sortMode.Text = "Sort Mode:";
        sortMode.Position = scroll.Position + new Vector2(175, 600 - (sortTime.Origin.Y) + (sortMode.Size.Y / 2));
        highscores.Add(sortMode);

        highscores.Add(sortTime);
        highscores.Add(sortCoins);
        highscores.Add(sortEnemies);

        this.Add(highscores);
    }

    //Load highscores and put them into a table.
    public void LoadHighscores(string type = "time")
    {
        HighscoreData data = Highscores.GetHighscores(type);

        TextGameObject temp;

        for (int i = 0; i < data.Count; i++)
        {
            temp = new TextGameObject("title");
            temp.Text = "Rank";
            scores.Add(temp, 0, 0);

            temp = new TextGameObject("title");
            temp.Text = "Nickname";
            scores.Add(temp, 1, 0);

            temp = new TextGameObject("title");
            temp.Text = "Time";
            scores.Add(temp, 2, 0);

            temp = new TextGameObject("title");
            temp.Text = "Coins";
            scores.Add(temp, 3, 0);

            temp = new TextGameObject("title");
            temp.Text = "Enemies killed";
            scores.Add(temp, 4, 0);

            temp = new TextGameObject("smallFont");
            temp.Text = data.Ranks[i].ToString();
            scores.Add(temp, 0, i + 1);

            temp = new TextGameObject("smallFont");
            temp.Text = data.Players[i];
            scores.Add(temp, 1, i + 1);

            temp = new TextGameObject("smallFont");
            temp.Text = data.TimeString[i];
            scores.Add(temp, 2, i + 1);

            temp = new TextGameObject("smallFont");
            temp.Text = data.CoinsCollected[i].ToString();
            scores.Add(temp, 3, i + 1);

            temp = new TextGameObject("smallFont");
            temp.Text = data.EnemiesKilled[i].ToString();
            scores.Add(temp, 4, i + 1);
        }
    }

    //Handle button input
    public override void HandleInput(InputHelper inputHelper)
    {
        titleMenuState.HandleInput(inputHelper);

        if (sortTime.Pressed)
        {
            LoadHighscores("time");
        }

        if (sortCoins.Pressed)
        {
            LoadHighscores("coins");
        }

        if (sortEnemies.Pressed)
        {
            LoadHighscores("enemies");
        }

        highscores.HandleInput(inputHelper);
    }

    //Update positions
    public override void Update(GameTime gameTime)
    {
        titleMenuState.Update(gameTime);

        title.Position = scroll.Position + new Vector2(150, 50);

        scores.Position = scroll.Position + new Vector2(200, 200);

        sortMode.Position = scroll.Position + new Vector2(175, 675 - (sortTime.Origin.Y) + (sortMode.Size.Y / 2));
        sortTime.Position = scroll.Position + new Vector2(425, 675);
        sortCoins.Position = scroll.Position + new Vector2(650, 675);
        sortEnemies.Position = scroll.Position + new Vector2(875, 675);

        highscores.Update(gameTime);
    }

    //Reset positions and reload highscores
    public override void Reset()
    {
        titleMenuState.Reset();

        title.Position = new Vector2(-1000, -1000);

        scores.Position = new Vector2(-1000, -1000);

        sortMode.Position = new Vector2(-1000, -1000);
        sortTime.Position = new Vector2(-1000, -1000);
        sortCoins.Position = new Vector2(-1000, -1000);
        sortEnemies.Position = new Vector2(-1000, -1000);

        LoadHighscores();

        highscores.Reset();
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        titleMenuState.Draw(gameTime, spriteBatch);
        highscores.Draw(gameTime, spriteBatch);
    }
}
