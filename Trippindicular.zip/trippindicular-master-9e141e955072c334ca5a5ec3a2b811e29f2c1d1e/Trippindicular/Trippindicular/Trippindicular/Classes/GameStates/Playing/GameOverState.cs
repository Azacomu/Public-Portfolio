﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This class creates an overlay for when the player dies
/// </summary>
public class GameOverState : GameObjectList
{
    IGameLoopObject hud;

    PlayingState playingState;

    SpriteGameObject background, gameOver;

    Button newGame, exitMenu, exitGame;

    public GameOverState()
    {
        //Initialize playingState
        playingState = GameWorld.GameStateManager.GetGameState("playing") as PlayingState;

        hud = GameWorld.GameStateManager.GetGameState("hud");

        //Starting values
        background = new SpriteGameObject("blackDrop");

        gameOver = new SpriteGameObject("gameOver");
        gameOver.Position = new Vector2((GameSettings.GameWidth / 2) - (gameOver.Width / 2), (GameSettings.GameHeight / 2) - (gameOver.Height / 2));

        newGame = new Button("button", "buttonFont", "font", 0, "New game");
        newGame.Position = new Vector2((GameSettings.GameWidth / 2) - (newGame.Width * 1.2f), GameSettings.GameHeight - (newGame.Height * 3.0f));

        exitMenu = new Button("button", "buttonFont", "font", 0, "Exit to menu");
        exitMenu.Position = new Vector2((GameSettings.GameWidth / 2), GameSettings.GameHeight - (exitMenu.Height * 3.0f));

        exitGame = new Button("button", "buttonFont", "font", 0, "Exit game");
        exitGame.Position = new Vector2((GameSettings.GameWidth / 2) + (exitGame.Width * 1.2f), GameSettings.GameHeight - (exitGame.Height * 3.0f));

        this.Add(background);
        this.Add(gameOver);

        this.Add(newGame);
        this.Add(exitMenu);
        this.Add(exitGame);
    }

    //Handle button input
    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);

        if (newGame.Pressed)
        {
            playingState.Initialize(true);
            GameWorld.GameStateManager.SwitchTo("hud");
        }

        if (exitMenu.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("titleMenu").Reset(); ;
            GameWorld.GameStateManager.SwitchTo("titleMenu");
        }

        if (exitGame.Pressed)
        {
            GameWorld.Exited = true;
        }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
    }

    public override void Reset()
    {
        base.Reset();
        hud.Reset();
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        hud.Draw(gameTime, spriteBatch);
        base.Draw(gameTime, spriteBatch);
    }
}
