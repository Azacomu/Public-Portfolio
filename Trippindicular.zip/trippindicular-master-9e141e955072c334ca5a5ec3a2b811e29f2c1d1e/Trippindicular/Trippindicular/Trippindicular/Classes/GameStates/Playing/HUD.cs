﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

/// <summary>
/// This class draws the game with a heads-up-display over it. On this display the player will find any information he or she needs.
/// </summary>
public class HUD : IGameLoopObject
{
    protected IGameLoopObject playingState;

    //HUD
    public GameObjectList hud;
    protected SpriteGameObject overlay;

    //Item bar
    protected GameObjectList items;
    protected DropDown itemBar;
    protected bool down;
    protected SpriteGameObject[] itemSprites;
    protected string[] itemNames, prevItem;
    protected int indexConsumable;

    //Item counts
    protected GameObjectList itemCounts;
    protected SpriteGameObject keys, bombs, coins;
    protected TextGameObject keyCount, bombCount, coinCount;
    protected int numKeys, numBombs, numCoins;

    //Lives
    protected GameObjectList lives;
    protected List<SpriteGameObject> hearts;
    protected TextGameObject heartText;
    protected int maxLives, numHearts;

    //Timer
    protected TextGameObject time;
    protected TextTimer timer;

    //Mini-map
    protected GameObjectList miniMap;
    protected SpriteGameObject map;

    //Potions
    protected SpriteGameObject potionTex;
    protected TextGameObject potionCount;
    protected int numPotions;

    //Read and write variables
    public int MaxLives
    {
        get { return maxLives; }
        set { maxLives = value; }
    }

    public int NumHearts
    {
        get { return numHearts; }
        set { numHearts = value; }
    }

    public SpriteGameObject[] ItemSprites
    {
        get { return itemSprites; }
        set { itemSprites = value; }
    }

    public bool Down
    {
        get { return down; }
        set { down = value; }
    }

    public HUD()
    {
        //Initialize playing state
        playingState = GameWorld.GameStateManager.GetGameState("playing");

        //HUD
        hud = new GameObjectList(0, "HUD");
        overlay = new SpriteGameObject("overlay");
        hud.Add(overlay);

        //Item bar
        items = new GameObjectList();
        itemBar = new DropDown("itemBar", new Vector2(480, -150));
        itemBar.Drop = down;
        items.Add(itemBar);

        itemNames = new string[3];
        prevItem = new string[3];
        itemSprites = new SpriteGameObject[3];

        for (int i = 0; i < itemNames.GetLength(0); i++)
        {
            ItemSprites[i] = new SpriteGameObject("placeholder");
            ItemSprites[i].Visible = false;
        }

        hud.Add(items);

        //Item counts
        itemCounts = new GameObjectList();

        //Items
            //Keys
            keys = new SpriteGameObject("key");
            keys.Position = new Vector2(1440, 940);
            keys.Scale = 0.5f;
            itemCounts.Add(keys);

            //Bombs
            bombs = new SpriteGameObject("bomb");
            bombs.Position = new Vector2(1440, 980);
            bombs.Scale = 0.5f;
            itemCounts.Add(bombs);

            //Coins
            coins = new SpriteGameObject("coin");
            coins.Position = new Vector2(1440, 1020);
            coins.Scale = 0.5f;
            itemCounts.Add(coins);

        //Counts
            //Keys
            keyCount = new TextGameObject("font");
            keyCount.Position = new Vector2(1480, 940);
            keyCount.Text = "";
            itemCounts.Add(keyCount);

            //Bombs
            bombCount = new TextGameObject("font");
            bombCount.Position = new Vector2(1480, 980);
            bombCount.Text = "";
            itemCounts.Add(bombCount);

            //Coins
            coinCount = new TextGameObject("font");
            coinCount.Position = new Vector2(1480, 1020);
            coinCount.Text = "";
            itemCounts.Add(coinCount);

        hud.Add(itemCounts);

        //Lives
        lives = new GameObjectList();

        //Text
        heartText = new TextGameObject("font");
        heartText.Position = new Vector2(100, 940);
        heartText.Text = "Health:";
        lives.Add(heartText);

        //Hearts
        hearts = new List<SpriteGameObject>();
        maxLives = 20;

        if (maxLives != 0)
        {
            for (int i = 0; i < maxLives; i++)
            {
                int index = 0;

                if (i % 2 == 0)
                {
                    index = 0;
                }
                else
                {
                    index = 1;
                }

                hearts.Add(new SpriteGameObject("heart", index));
                hearts[i].Position = new Vector2((100 + (i * 32)), 980);

                lives.Add(hearts[i]);
            }
        }

        hud.Add(lives);

        //Timer
        time = new TextGameObject("font");
        time.Position = new Vector2(1600, 0);

        hud.Add(time);

        //Mini map
        miniMap = new GameObjectList();

        //Map
        map = new SpriteGameObject("map");
        map.Position = new Vector2(8, 8);
        miniMap.Add(map);

        hud.Add(miniMap);

        //Health potion
        potionTex = new SpriteGameObject("potions", 0);
        potionTex.Position = new Vector2(1630, 980);
        potionTex.Scale = 0.5f;
        hud.Add(potionTex);
       
        potionCount = new TextGameObject("font");

        potionCount.Position = new Vector2(1665, 980);
        potionCount.Text = "";
        hud.Add(potionCount);
    }

    public void HandleInput(InputHelper inputHelper)
    {
        playingState.HandleInput(inputHelper);
        hud.HandleInput(inputHelper);
    }

    //Update all HUD items, this includes item sprites and item counts
    public void Update(GameTime gameTime)
    {
        playingState.Update(gameTime);

        //Item bar
        Inventory inventory = GameData.GetPlayer.Inventory;

        for (int i = 0; i < 3; i++)
        {
            itemNames[i] = inventory.GetItem(i)?.AssetName;

            if (inventory.GetItem(i) != null && itemNames[i] != prevItem[i])
            {
                items.Remove(itemSprites[i]);

                itemSprites[i] = new SpriteGameObject(itemNames[i], inventory.GetItem(i).Sprite.SheetIndex);
                itemSprites[i].Position = itemBar.Position + new Vector2(234 + (i * 180), 22);
                itemSprites[i].Scale = 2.0f;

                items.Add(itemSprites[i]);
            }

            else if (inventory.GetItem(i) == null && itemNames[i] != prevItem[i])
            {
                items.Remove(itemSprites[i]);

                itemSprites[i] = new SpriteGameObject("placeholder", 0);
                itemSprites[i].Visible = false;

                items.Add(itemSprites[i]);
            }

            itemSprites[i].Position = itemBar.Position + new Vector2(234 + (i * 180), 22);

            prevItem[i] = inventory.GetItem(i)?.AssetName;
        }
            
        //Counts
        numKeys = GameData.GetPlayer.Inventory.GetKeys;
        keyCount.Text = "Keys: " + numKeys;

        numBombs = GameData.GetPlayer.Inventory.GetBombs;
        bombCount.Text = "Bombs: " + numBombs;

        numCoins = GameData.GetPlayer.Inventory.GetCoins;
        coinCount.Text = "Coins: " + numCoins;

        numPotions = GameData.GetPlayer.Inventory.GetHealthPotions;
        potionCount.Text = "Potions: " + numPotions;

        //Lives
        numHearts = GameData.GetPlayer.CurHealth;

        for (int i = 0; i < maxLives; i++)
        {
            if (i <= (numHearts - 1))
            {
                hearts[i].Visible = true;
            }
            else
            {
                hearts[i].Visible = false;
            }
        }

        //Timer
        time.Text = "Time: " + GameData.PlayingTime.Text;

        //Update itembar drop
        itemBar.Drop = down;

        hud.Update(gameTime);

    }

    //Draw all hud items
    public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        playingState.Draw(gameTime, spriteBatch);
        hud.Draw(gameTime, spriteBatch);
    }

    public void Reset()
    {
        playingState.Reset();
        hud.Reset();
    }
}
