﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

/// <summary>
/// This creates an overlay for when the player wins the game
/// </summary>

public class FinishState : GameObjectList
{
    IGameLoopObject hud;

    PlayingState playingState;
    protected string type;

    protected SpriteGameObject background, congrats, nameBar;
    TextGameObject winText, enterName, dummy;
    protected Button submit, exitMenu, newGame;
    protected UserInput input;

    public FinishState()
    {
        //Initialize playingState
        playingState = GameWorld.GameStateManager.GetGameState("playing") as PlayingState;

        hud = GameWorld.GameStateManager.GetGameState("hud");

        //Starting values
        background = new SpriteGameObject("blackDrop");
        this.Add(background);

        congrats = new SpriteGameObject("congrats");
        congrats.Position = new Vector2((GameSettings.GameWidth / 2) - (congrats.Width / 2), (GameSettings.GameHeight / 4) - (congrats.Height / 2));
        this.Add(congrats);

        winText = new TextGameObject("font");
        winText.Color = Color.White;
        winText.Text = "You've completed Trippindicular!";
        winText.Position = new Vector2((GameSettings.GameWidth / 2) - (winText.Size.X / 2), (GameSettings.GameHeight / 3) - (winText.Size.Y / 2));
        this.Add(winText);

        enterName = new TextGameObject("font");
        enterName.Color = Color.White;
        enterName.Text = "Please enter your name:";
        enterName.Position = new Vector2((GameSettings.GameWidth / 2) - (enterName.Size.X / 2), (GameSettings.GameHeight / 2) - (enterName.Size.Y / 2));
        this.Add(enterName);

        dummy = new TextGameObject("font");
        dummy.Text = "AAAAAAAAAAAAAAAA";
        dummy.Visible = false;

        nameBar = new SpriteGameObject("nameBar");
        nameBar.Position = new Vector2((GameSettings.GameWidth / 2) - (nameBar.Width / 2), (GameSettings.GameHeight / 2) + (nameBar.Height / 2));
        this.Add(nameBar);

        input = new UserInput();
        input.Position = new Vector2((GameSettings.GameWidth / 2) - (dummy.Size.X / 2), (GameSettings.GameHeight / 2) + (nameBar.Height * 0.75f));
        this.Add(input);

        if (!GameData.Cheated)
            type = "button";
        else
            type = "disabledButton";

        submit = new Button(type, "buttonFont", "font", 0, "Submit score");
        submit.Position = new Vector2((GameSettings.GameWidth / 2) - (submit.Width * 1.2f), GameSettings.GameHeight - (submit.Height * 3.0f));
        this.Add(submit);

        exitMenu = new Button("button", "buttonFont", "font", 0, "Exit to menu");
        exitMenu.Position = new Vector2((GameSettings.GameWidth / 2), GameSettings.GameHeight - (exitMenu.Height * 3.0f));
        this.Add(exitMenu);

        newGame = new Button("button", "buttonFont", "font", 0, "New game");
        newGame.Position = new Vector2((GameSettings.GameWidth / 2) + (newGame.Width * 1.2f), GameSettings.GameHeight - (newGame.Height * 3.0f));
        this.Add(newGame);
    }

    //Handle button input
    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);

        if (submit.Pressed && input != null && !GameData.Cheated)
        {
            Highscores.AddScore(input.Text, GameData.PlayingTime.Seconds + GameData.PlayingTime.Minutes * 60, GameData.EnemiesKilled, GameData.CoinsCollected);

            GameWorld.GameStateManager.GetGameState("highscoresTitle").Reset();
            GameWorld.GameStateManager.SwitchTo("highscoresTitle");
            Reset();
        }

        if (exitMenu.Pressed)
        {
            GameWorld.GameStateManager.GetGameState("titleMenu").Reset();
            GameWorld.GameStateManager.SwitchTo("titleMenu");
        }

        if (newGame.Pressed)
        {
            playingState.Initialize(true);
            GameWorld.GameStateManager.SwitchTo("hud");
        }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
    }

    //Reset submit button state
    public override void Reset()
    {
        hud.Reset();
        base.Reset();

        this.Remove(submit);
        if (!GameData.Cheated)
            type = "button";
        else
            type = "disabledButton";
        submit = new Button(type, "buttonFont", "font", 0, "Submit score");
        submit.Position = new Vector2((GameSettings.GameWidth / 2) - (submit.Width * 1.2f), GameSettings.GameHeight - (submit.Height * 3.0f));
        this.Add(submit);
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        hud.Draw(gameTime, spriteBatch);
        base.Draw(gameTime, spriteBatch);
    }
}
