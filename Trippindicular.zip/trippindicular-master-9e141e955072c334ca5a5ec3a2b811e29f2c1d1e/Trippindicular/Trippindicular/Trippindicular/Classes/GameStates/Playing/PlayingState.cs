﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

//Class used to update and draw everything that is needed when the player is playing the game.
class PlayingState : IGameLoopObject
{
    public static LevelController LevelController;
    public static SaveGame SaveGame;

    protected KonamiCodes cheatCodes;

    public PlayingState()
    {
        cheatCodes = new KonamiCodes();
        SaveGame = new SaveGame();
    }

    //Initialize a game, either load it or make a new one based on the bool given.
    public void Initialize(bool newGame)
    {
        GameData.Initialize();
        GameData.LevelObjects.Add(new Player());
        GameData.AfterInitialize();
        if (!newGame)
        {
            try
            {
                SaveGame.InitializeLoad();
            }
            catch (Exception e)
            {
                Log.Write(LogType.ERROR, "Error loading game: " + e.Message + ", Starting new game!");
                newGame = true;
            }     
        }
        LevelController = new LevelController(newGame);
        MainGame.AchievementController.FinishAchievement("It Begins");
    }

    public void Update(GameTime gameTime)
    {
        GameData.Update(gameTime);
        LevelController.Update(gameTime);
        cheatCodes.Update(gameTime);
    }

    //Check several keypresses and handle accordingly.
    public void HandleInput(InputHelper ih)
    {
        GameData.LevelObjects.HandleInput(ih);
        cheatCodes.HandleInput(ih);

        //Go to the menu when pressing ESC.  
        if (ih.KeyPressed(Keys.Escape))
            MainGame.GameStateManager.SwitchTo("pauseMenu");            
    }

    public void Reset()
    {

    }

    public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        GameData.DrawGame(gameTime, spriteBatch);
        cheatCodes.Draw(gameTime, spriteBatch);
    }
}

