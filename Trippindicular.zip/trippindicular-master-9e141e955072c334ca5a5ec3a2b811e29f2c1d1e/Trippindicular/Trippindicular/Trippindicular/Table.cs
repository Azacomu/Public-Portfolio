﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

/// <summary>
/// This class creates a grid of gameObjects
/// </summary>

public class Table : GameObject
{
    protected GameObject[,] grid;
    protected int cellWidth, cellHeight, tableWidth;

    protected int[] columnPos;

    //Readonly variables
    public GameObject[,] Grid => grid;
    public int Columns => grid.GetLength(0);
    public int Rows => grid.GetLength(1);
    public int TableWidth => tableWidth;
    public int TableHeight => ((Rows * CellHeight) / 2);

    //Read and write variables
    public int CellHeight
    {
        get { return cellHeight; }
        set { cellHeight = value; }
    }

    public int[] ColumnPos
    {
        get { return columnPos; }
        set { columnPos = value; }
    }

    //Table
    public Table(int columns, int rows, int layer = 0, string id = "") : base (id, layer)
    {
        //Set grid dimensions
        grid = new GameObject[columns, rows];

        //Initialize column width array
        columnPos = new int[columns];

        //Create grid
        for (int x = 0; x < columns; x++)
            for (int y = 0; y < rows; y++)
                grid[x,y] = null;
    }

    //Add an object to the grid
    public void Add(GameObject obj, int x, int y)
    {
        if (x < grid.GetLength(0) && x >= 0 && y < grid.GetLength(1) && y >= 0)
        {
            grid[x, y] = obj;
            grid[x, y].Position = new Vector2(this.GlobalPosition.X + (columnPos[x]), this.GlobalPosition.Y + (y * cellHeight));
        }
        else
            return;
    }

    //Clear one line in the grid
    public void Clear(int x, int y)
    {
        for (int r = y; r > 0; r--)
            grid[x, r] = grid[x, r - 1];

        //Set row value to null
        grid[x, 0] = null;
    }

    //Clear all cells
    public void ClearAll()
    {
        for (int x = 0; x < Columns; x++)
            for (int y = 0; y < Rows; y++)
                grid[x, y] = null;
    }

    //Handle input
    public override void HandleInput(InputHelper inputHelper)
    {
        foreach (GameObject obj in grid)
            if (obj != null)
                obj.HandleInput(inputHelper);
    }

    //Update the table
    public override void Update(GameTime gameTime)
    {
        for (int x = 0; x < Columns; x++)
            for (int y = 0; y < Rows; y++)
            {
                if (grid[x, y] != null)
                    grid[x, y].Position = this.GlobalPosition + new Vector2((columnPos[x]), (y * cellHeight));
            }

        foreach (GameObject obj in grid)
            if (obj != null)
                obj.Update(gameTime);
    }

    //Draw al objects
    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (!visible)
            return;

        foreach (GameObject obj in grid)
            if (obj != null)
                obj.Draw(gameTime, spriteBatch);
    }

    //Reset all objects
    public override void Reset()
    {
        foreach (GameObject obj in grid)
            if (obj != null)
                obj.Reset();
    }
}