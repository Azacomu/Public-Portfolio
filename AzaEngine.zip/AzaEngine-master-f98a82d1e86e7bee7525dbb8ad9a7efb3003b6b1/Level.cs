﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AzaEngine.Loading;
using Microsoft.Xna.Framework;

namespace AzaEngine
{
    /// <summary>
    /// This is all data that should be needed to make a level.
    /// </summary>
    public struct LevelData
    {
        public LoadableObject[] LevelObjects;
        public float Time;
        public string Name;
        public int Width;
        public int Height;
    }

    /// <summary>
    /// Struct with all data needed to load an object into the game.
    /// </summary>
    public struct LoadableObject
    {
        public string AssetName;
        public AssetType Type; //Most often will be: Texture, XMLTexture, Animation or Class.
        public Vector2 Position;
        public Vector2 Origin;
        public float Scale;
        public float Rotation;
        public int Layer;
        public string Name;
    }

    /// <summary>
    /// This is a class with all data from a level in it, all objects in it and some variables about the level.
    /// </summary>
    public class Level
    {
        public float Time;
        public string Name;
        public int Width;
        public int Height;
        public GameObjectList LevelObjects;

        public Level(LevelData data)
        {

        }
    }
}
