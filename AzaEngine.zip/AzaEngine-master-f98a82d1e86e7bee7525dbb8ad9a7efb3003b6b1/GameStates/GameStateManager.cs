﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;

namespace AzaEngine
{
    /// <summary>
    /// Keeps track of the current state of the game, including the GUI needed for that state.
    /// </summary>
    public class GameStateManager
    {
        Dictionary<string, GameState> gameStates;
        GameState currentGameState;

        public IGameLoopObject CurrentGameState => currentGameState;

        public GameStateManager()
        {
            gameStates = new Dictionary<string, GameState>();
            currentGameState = null;
        }
        //Add a new gamestate.
        public void AddGameState(string name, GameState state)
        {
            gameStates[name] = state;
        }
        //Return a gamestate with the given name (Or write an error if that is not possible).
        public IGameLoopObject GetGameState(string name)
        {
            try { return gameStates[name]; }
            catch (Exception) { Log.Write(LogType.ERROR, "GameState not found! name: " + name); return null; }
        }
        //Switches to another gamestate with the given name and resets the state as well.
        public void SwitchTo(string name)
        {
            if (gameStates.ContainsKey(name))
            {
                gameStates[name].Reset();
                currentGameState = gameStates[name];
            }
            else
                throw new KeyNotFoundException("Could not find game state: " + name);
        }
        //Handle input of the current gamestate.
        public void HandleInput(InputHelper inputHelper)
        {
            if (currentGameState != null)
                currentGameState.HandleInput(inputHelper);
        }
        //Update the current gamestate.
        public void Update(GameTime gameTime)
        {
            if (currentGameState != null)
                currentGameState.Update(gameTime);
        }
        //Draw the current gamestate.
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            if (currentGameState != null)
                currentGameState.Draw(gameTime, spriteBatch);
        }
        //Reset the current gamestate.
        public void Reset()
        {
            if (currentGameState != null)
                currentGameState.Reset();
        }

        /// <summary>
        /// Add a gameobject to the GUI of the current gamestate.
        /// </summary>
        /// <param name="obj">Gameobject added to GUI.</param>
        public void AddGUI(GameObject obj)
        {
            currentGameState.AddGUI(obj);
        }

        /// <summary>
        /// Remove a gameobject from the GUI of the current gamestate.
        /// </summary>
        /// <param name="obj">Gameobject removed from GUI.</param>
        public void RemoveGUI(GameObject obj)
        {
            currentGameState.RemoveGUI(obj);
        }

        /// <summary>
        /// Returns the Gameobject in the GUI of the current gamestate with the given name.
        /// </summary>
        /// <param name="name">Name of GUI element searched.</param>
        /// <returns>Gameobject with given name as id.</returns>
        public GameObject FindGUI(string name)
        {
            return currentGameState.FindGUI(name);
        }
    }
}

