﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AzaEngine
{
    /// <summary>
    /// Basic class for a gamestate, with a list of GUI elements that get drawn over the elements in the actual gamestate.
    /// </summary>
    public class GameState : GameObjectList
    {
        GameObjectList GUIElements;

        public GameState()
        {
            GUIElements = new GameObjectList();
        }

        //Always first draw/update the gamestate itself, then the GUIElements.
        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            base.Draw(gameTime, spriteBatch);
            GUIElements.Draw(gameTime, spriteBatch);
        }
        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);
            GUIElements.HandleInput(inputHelper);
        }
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            GUIElements.Update(gameTime);
        }
        public override void Reset()
        {
            base.Reset();
            GUIElements.Reset();
        }

        /// <summary>
        /// Add a gameobject to the GUI of the gamestate.
        /// </summary>
        /// <param name="gui">Gameobject added to GUI</param>
        public void AddGUI(GameObject gui)
        {
            GUIElements.Add(gui);
        }

        /// <summary>
        /// Remove a gameobject from the GUI of the gamestate.
        /// </summary>
        /// <param name="gui">Gameobject removed from GUI</param>
        public void RemoveGUI(GameObject gui)
        {
            GUIElements.Remove(gui);
        }

        /// <summary>
        /// Returns the Gameobject in the GUI with the given name.
        /// </summary>
        /// <param name="name">Name of GUI element searched</param>
        /// <returns>Gameobject with given name as id</returns>
        public GameObject FindGUI(string name)
        {
            return GUIElements.Find(name);
        }
    }
}
