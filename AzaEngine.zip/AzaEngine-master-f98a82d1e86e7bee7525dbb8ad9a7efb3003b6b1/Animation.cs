﻿using Microsoft.Xna.Framework.Graphics;
using AzaEngine.Loading;
using Microsoft.Xna.Framework;
using System.Collections.Generic;

namespace AzaEngine
{
    /// <summary>
    /// Class to keep track of multiple sprites that have to be displayed after eachother, giving an animation.
    /// </summary>
    public class Animation : SpriteSheet
    {
        protected int current;
        protected float timePast;
        protected FrameInfo[] frames;
        protected Dictionary<string, FrameInfo[]> animations;

        public bool Paused;

        public Animation(Texture2D texture, AnimationInfo info) : base(texture, info.Animations[info.StartAnimation][0].Source)
        {
            current = 0;
            animations = info.Animations;
            frames = animations[info.StartAnimation];
        }

        public void Update(GameTime gameTime)
        {
            if (!Paused)
            {
                timePast += (float)gameTime.ElapsedGameTime.TotalSeconds;

                if (timePast >= frames[current].Time)
                {
                    timePast = 0;
                    current++;
                    if (current >= frames.Length)
                        current = 0;
                    ChangeSprite(frames[current].Source);
                }
            }
        }

        public void ChangeAnimation(string name)
        {
            if (animations.ContainsKey(name))
            {
                current = 0;
                frames = animations[name];
            }
            else
                Log.Write(LogType.WARNING, "Requested animation does not exist: " + name);
        }
    }
}
