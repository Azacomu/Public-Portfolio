﻿using System;
using System.Collections.Generic;
using System.IO;

namespace AzaEngine.Loading
{
    /// <summary>
    /// This class loads txt files and returns the lines in a List text. (Except for lines that start with #, they are comments.)
    /// </summary>
    public class FileLoader
    {
        //TODO: Add ways of encryption to files, also add a way to save to a text file.
        //Method to load a file from anywhere.
        static public List<string> LoadFile(string path)
        {
            List<string> text = new List<string>();
            try
            {
                StreamReader file = new StreamReader(path);
                string line = file.ReadLine();

                while (line != null)
                {
                    //If the line starts with '#', don't add the line as it is a comment.
                    if (line[0] == '#')
                    {
                        line = file.ReadLine();
                        continue;
                    }
                    text.Add(line);
                    line = file.ReadLine();
                }
                file.Close();
            }
            catch (Exception e)
            {
                Log.Write(LogType.ERROR, "Error occured while loading an important file: " + e.Message);
            }
            return text;
        }
    }
}

