﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzaEngine.Loading
{
    /// <summary>
    /// Class to load settings.
    /// </summary>
    public class SettingsLoader
    {
        protected Dictionary<string, string> settings;

        public SettingsLoader(string path)
        {
            List<string> text = FileLoader.LoadFile(path);
            settings = new Dictionary<string, string>();

            for (int i = 0; i < text.Count; i++)
            {
                string[] temp = text[i].Split(':');
                settings.Add(temp[0], temp[1]);
            }
        }
        //Method to get a certain setting.
        public string GetSetting(string setting)
        {
            if (settings.ContainsKey(setting))
                return settings[setting];
            Log.Write(LogType.ERROR, "Error, setting not found! " + setting);
            return "";
        }
    }
}

