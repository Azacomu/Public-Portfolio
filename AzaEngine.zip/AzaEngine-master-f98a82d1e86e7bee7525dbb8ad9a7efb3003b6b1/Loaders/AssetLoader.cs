﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Xml.Linq;
using Microsoft.Xna.Framework;
using System.IO;

namespace AzaEngine.Loading
{
    /// <summary>
    /// All different types of assets that can be loaded.
    /// </summary>
    public enum AssetType
    {
        TEXTURE = 0,
        XMLTEXTURE = 1,
        ANIMATION = 2,
        SOUND = 3,
        MUSIC = 4,
        CLASS = 5
    }
    /// <summary>
    /// All info needed for assets in a nice struct.
    /// </summary>
    public struct AssetInfo
    {
        public string Path;
        public AssetType Type;
        public int Rows;
        public int Columns;
        public int SheetIndex;
        public int X;
        public int Y;
        public int Width;
        public int Height;

        public override string ToString()
        {
            if (Type == AssetType.TEXTURE)
                return Path + ", " + Type + ", " + Columns + "@" + Rows + " : " + SheetIndex;
            else
                return Path + ", " + Type + ", " + X + ", " + Y + " : " + Width + "@" + Height;
        }
    }
    /// <summary>
    /// Information needed for a frame of an Animation.
    /// </summary>
    public struct FrameInfo
    {
        public Rectangle Source;
        public float Time;
    }
    /// <summary>
    /// Struct to save subanimations together in one struct.
    /// </summary>
    public struct AnimationInfo
    {
        public Dictionary<string, FrameInfo[]> Animations;
        public string Path;
        public string StartAnimation;
    }
    /// <summary>
    /// Finds the assets with the given assetnames and returns them as objects that can be used by the game. (Like textures and sounds).
    /// </summary>
    public class AssetLoader
    {
        protected ContentManager content;
        protected Dictionary<string, AssetInfo> paths = new Dictionary<string, AssetInfo>();
        protected Dictionary<string, Texture2D> textureCache = new Dictionary<string, Texture2D>();
        protected Dictionary<string, AnimationInfo> animationCache = new Dictionary<string, AnimationInfo>();

        public AssetLoader(ContentManager content, string path = "paths.txt")
        {
            this.content = content;
            List<string> temp = FileLoader.LoadFile(content.RootDirectory + "/" + path);
            for (int i = 0; i < temp.Count; i++)
            {
                string[] t = temp[i].Split('-');
                string[] data = t[1].Split(':');
                AssetInfo info = new AssetInfo();
                info.Path = data[0];
                switch (data[1])
                {
                    case "tex":
                        info.Type = AssetType.TEXTURE;
                        break;
                    case "snd":
                        info.Type = AssetType.SOUND;
                        break;
                    case "music":
                        info.Type = AssetType.MUSIC;
                        break;
                    case "xml":
                        LoadXML(info.Path);
                        continue;
                    case "ani":
                        LoadAnimation(info.Path);
                        continue;

                }
                if (data.Length > 2)
                {
                    string[] ind = data[2].Split('@');
                    info.Columns = int.Parse(ind[0]);
                    if (ind.Length > 1)
                    {
                        info.Rows = int.Parse(ind[1]);
                    }
                    else
                    {
                        info.Rows = 1;
                    }
                    if (data.Length > 3)
                    {
                        info.SheetIndex = int.Parse(data[3]);
                    }
                }
                else
                {
                    info.Columns = 1;
                    info.Rows = 1;
                }
                paths.Add(t[0], info);
                Console.WriteLine(t[0] + " , " + info.ToString());
            }

            PrintAssetList();
        }

        /// <summary>
        /// Method to get a spritesheet with the texture and index of the given asset.
        /// </summary>
        /// <param name="assetname">Name of the asset that you want.</param>
        /// <returns>Spritesheet with the asset you wanted.</returns>
        public SpriteSheet GetTexture(string assetname)
        {
            SpriteSheet temp;
            if (paths.ContainsKey(assetname))
            {
                AssetInfo info = paths[assetname];
                if (!textureCache.ContainsKey(info.Path))
                {
                    textureCache.Add(info.Path, content.Load<Texture2D>(info.Path));
                }
                temp = new SpriteSheet(textureCache[info.Path], info);
            }
            else
            {
                temp = new SpriteSheet(textureCache[paths["placeholder"].Path]);
            }
            return temp;
        }
        /// <summary>
        /// Method to get a loaded animation (from XML) which has the name given.
        /// </summary>
        /// <param name="name">Name of the animation you want to get.</param>
        /// <returns>Animation with given name.</returns>
        public Animation GetAnimation(string name)
        {
            Animation temp;
            if (animationCache.ContainsKey(name))
            {
                AnimationInfo info = animationCache[name];
                if (!textureCache.ContainsKey(info.Path))
                {
                    textureCache.Add(info.Path, content.Load<Texture2D>(info.Path));
                }
                temp = new Animation(textureCache[info.Path], info);
            }
            else
            {
                //Return an animation with only the placeholder. TODO
                AssetInfo i = paths["placeholder"];
                FrameInfo[] info = new FrameInfo[1];
                info[0] = new FrameInfo();
                info[0].Source = new Rectangle(i.X, i.Y, i.Width, i.Height);
                info[0].Time = 1;
                AnimationInfo final = new AnimationInfo();
                final.StartAnimation = "placeholder";
                final.Animations = new Dictionary<string, FrameInfo[]>();
                final.Animations.Add("placeholder", info);
                temp = new Animation(textureCache[i.Path], final);
            }
            return temp;
        }

        //Method to (try to) load all sprites in a XML spritesheet.
        public void LoadXML(string path)
        {
            try
            {
                XElement doc = XElement.Load(content.RootDirectory + "/" + path);
                string spritePath = doc.Attribute("imagePath").Value;
                var textureInfo = doc.Elements("SubTexture");
                foreach (XElement x in textureInfo)
                {
                    AssetInfo temp = new AssetInfo();
                    temp.Type = AssetType.XMLTEXTURE;
                    temp.Path = spritePath;
                    temp.X = int.Parse(x.Attribute("x").Value);
                    temp.Y = int.Parse(x.Attribute("y").Value);
                    temp.Width = int.Parse(x.Attribute("width").Value);
                    temp.Height = int.Parse(x.Attribute("height").Value);
                    paths.Add(x.Attribute("name").Value, temp);
                }
                Log.Write(LogType.SUCCES, "Succesfully loaded: " + path);
            }
            catch (Exception e)
            {
                Log.Write(LogType.ERROR, "Failed to load file: " + path + ", Error: " + e.Message);
            }
        }

        public void LoadAnimation(string path)
        {
            try
            {
                AnimationInfo final = new AnimationInfo();
                Dictionary<string, FrameInfo[]> dict = new Dictionary<string, FrameInfo[]>();
                XElement doc = XElement.Load(content.RootDirectory + "/" + path);
                final.Path = doc.Attribute("image").Value;
                final.StartAnimation = doc.Attribute("start").Value;
                string name = doc.Attribute("name").Value;
                var subAnimations = doc.Elements("SubAnimation");
                foreach (XElement x in subAnimations)
                {
                    List<FrameInfo> temp = new List<FrameInfo>();
                    string subName = x.Attribute("name").Value;
                    var frames = x.Elements("Frame");
                    var e = frames.GetEnumerator();
                    while (e.MoveNext())
                    {
                        FrameInfo info = new FrameInfo();
                        info.Time = float.Parse(e.Current.Attribute("time").Value);
                        AssetInfo i = paths[e.Current.Attribute("name").Value];
                        info.Source = new Rectangle(i.X, i.Y, i.Width, i.Height);
                        temp.Add(info);
                    }
                    if (temp.Count == 0)
                        throw new Exception("Count of xml Animation Frame elements is 0, has to be at least 1!");
                    dict.Add(subName, temp.ToArray());
                }
                final.Animations = dict;
                animationCache.Add(name, final);
                Log.Write(LogType.SUCCES, "Succesfully loaded: " + path);
            }
            catch (Exception e)
            {
                Log.Write(LogType.ERROR, "Failed to load file: " + path + ", Error: " + e.Message);
            }
        }
        /// <summary>
        /// Method that prints all assets added that are NOT in the tileIndices file yet, to make it easy to add them all to that file.
        /// You can give a startnumber to print a list from that number to easily add it to the end of the tileIndices.
        /// </summary>
        /// <param name="startNumber">Number where the texture indices output will start.</param>
        public void PrintAssetList()
        {
            string fileName = "currentTextures.txt";
            List<string> output = new List<string>();
            List<string> temp = FileLoader.LoadFile(C.TilePath);
            int startNumber = int.Parse(temp[temp.Count - 1].Split(':')[0]) + 1;
            List<string> list = new List<string>();
            for (int i = 0; i < temp.Count; i++)
                list.Add(temp[i].Split(':')[1]);
            var e = paths.GetEnumerator();
            while(e.MoveNext())
            {
                if (!list.Contains(e.Current.Key))
                    output.Add(e.Current.Key);
            }
            StreamWriter file = new StreamWriter(new FileStream(fileName, FileMode.Create, FileAccess.Write));
            for (int i = startNumber; i < startNumber + output.Count; i++)
            {
                file.WriteLine(i + ":" + output[i - startNumber]);
            }
            file.Close();
        }
    }
}

