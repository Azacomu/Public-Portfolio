﻿using System;
using System.IO;

namespace AzaEngine
{
    /// <summary>
    /// Types of log messages.
    /// </summary>
    public enum LogType
    {
        ERROR = 0,
        WARNING = 1,
        INFO = 2,
        SUCCES = 3
    }
    /// <summary>
    /// This is a class that writes messages to a html file, with chosen priorities (Error, Warning or Info) in the colors red, orange, black.
    /// You can turn it off by changing locked to true. (Increases performance if a lot of log messages are written.)
    /// </summary>
    public class Log
    {
        static public string saveFile;
        static public bool locked = true;

        //Initialize settings.
        static public void Initialize()
        {
            //You can find the log in Debug/Log/log_day_hour_minute.html.
            Directory.CreateDirectory("Log");
            saveFile = "Log/LOG_" + DateTime.Now.DayOfYear + "_" + DateTime.Now.DayOfWeek + "_" + DateTime.Now.Hour + "." + DateTime.Now.Minute + ".html";
            StreamWriter output = new StreamWriter(new FileStream(saveFile, FileMode.Create, FileAccess.Write));
            output.WriteLine("<span style=\"font - family: &quot; Kootenay & quot; ; color: #000000;\">");
            output.WriteLine("Log started at " + DateTime.Now.ToLongTimeString() + "</span><hr/> ");
            output.Close();
            locked = false;
            Write(LogType.ERROR, "Testing if the error works!");
            Write(LogType.WARNING, "Testing if the warning works!");
            Write(LogType.INFO, "Testing if info works.");
            Write(LogType.SUCCES, "Testing if succes works!");
            
        }

        //Write a string of the given type to the log file.
        static public void Write(LogType type, string s)
        {
            if (locked)
                return;
            string text = "";
            switch (type)
            {
                case LogType.ERROR:
                    text = "<span style=\"color: #ff0000;\">"; break; //Red color.
                case LogType.WARNING:
                    text = "<span style=\"color: #ffa500;\">"; break; //Orange color.
                case LogType.INFO:
                    text = "<span style=\"color: #000000;\">"; break; //Black color.
                case LogType.SUCCES:
                    text = "<span style=\"color: #32CD32;\">"; break; //Green color.
            }
            text += DateTime.Now.ToLongTimeString() + " : " + s + "</span><br/>";

            //Try to write the string to the file, if it doesn't work, write an error to the Console.
            try
            {
                StreamWriter output = new StreamWriter(new FileStream(saveFile, FileMode.Append, FileAccess.Write));
                output.WriteLine(text);
                output.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error occured while writing to the log file : " + e.Message);
            }
        }
    }
}

