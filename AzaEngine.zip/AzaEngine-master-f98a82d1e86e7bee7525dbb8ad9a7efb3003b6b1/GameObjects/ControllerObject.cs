﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzaEngine
{
    public class ControllerObject : GameObject
    {
        public override bool IsController => true;
    }
}

