﻿using Microsoft.Xna.Framework;

namespace AzaEngine
{
    public class AnimatedGameObject : SpriteGameObject
    {
        protected Animation animation => sprite as Animation;

        public AnimatedGameObject(string assetName, string id = "", int layer = 0) : base("", id, layer)
        {
            if (assetName != "")
                sprite = GameWorld.AssetLoader.GetAnimation(assetName);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            animation.Update(gameTime);
        }
    }
}
