﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AzaEngine
{
    /// <summary>
    /// Class used as the base of every object in the game that uses a sprite.
    /// </summary>
    public class SpriteGameObject : GameObject
    {
        public Vector2 Origin;
        protected SpriteSheet sprite;

        //Readonly properties.
        public int Height => sprite.Height;
        public int Width => sprite.Width;
        public SpriteSheet Sprite => sprite;

        public bool Mirror
        {
            get { return sprite.Mirror; }
            set { sprite.Mirror = value; }
        }
        public float Scale
        {
            get { return sprite.Scale; }
            set { sprite.Scale = value; }
        }

        //Returns the boundingbox of the sprite.
        
        public override Rectangle BBox
        {
            get
            {
                int left = (int)(GlobalPosition.X - Origin.X);
                int top = (int)(GlobalPosition.Y - Origin.Y);
                return new Rectangle(left, top, Width, Height);
            }
        }

        //Constructor uses the assetname as the ID if no id was given.
        public SpriteGameObject(string assetName, string id = "", int layer = 0) : base(id, layer)
        {
            if (assetName != "")
                sprite = GameWorld.AssetLoader.GetTexture(assetName);
            else
                sprite = null;

            if (id == "" && assetName != "")
                this.id = assetName;

            IsVisible = true;
        }

        //Draws the sprite if the sprite is visible (and exists).
        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            if (!IsVisible || sprite == null)
            {
                if (sprite == null)
                    Log.Write(LogType.ERROR, "Error sprite from " + id + " is null!");
                return;
            }

            sprite.Draw(spriteBatch, Position, Origin);

        }

        //This method checks if this object collides with given object, this works by checking whether the pixels in the collision rectangle overlap or not.
        public bool CollidesWith(GameObject obj)
        {
            SpriteGameObject sprObj = obj as SpriteGameObject;
            if (sprObj == null || !sprObj.IsVisible)
                return false;

            Rectangle intersect = AzaHelper.Intersection(BBox, obj.BBox);

            for (int x = 0; x < intersect.Width; x++)
                for (int y = 0; y < intersect.Height; y++)
                {
                    int thisx = intersect.X - (int)(GlobalPosition.X - Origin.X) + x;
                    int thisy = intersect.Y - (int)(GlobalPosition.Y - Origin.Y) + y;
                    int objx = intersect.X - (int)(obj.GlobalPosition.X - sprObj.Origin.X) + x;
                    int objy = intersect.Y - (int)(obj.GlobalPosition.Y - sprObj.Origin.Y) + y;
                    if (sprite.GetPixelColor(thisx, thisy).A != 0
                        && sprObj.sprite.GetPixelColor(objx, objy).A != 0)
                        return true;
                }
            return false;
        }
    }
}

