﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AzaEngine
{
    /// <summary>
    /// This makes an object for in your game, used for all objects that (can) get drawn to the screen.
    /// </summary>
    public abstract class GameObject : IGameLoopObject
    {
        //Public vars (get/set).
        public GameObject Parent;
        public bool IsVisible;
        public bool IsSolid;
        public bool IsStatic; //Use to check whether object is static?
        public Vector2 Position;
        public Vector2 Velocity;

        //Protected vars.
        protected string id;
        protected int layer;

        //Get only properties.
        public virtual bool IsGUI => false;
        public virtual bool IsController => false;
        public string ID => id;
        public int Layer => layer; //? Maybe parent.layer + layer
        public virtual Rectangle BBox => new Rectangle(0, 0, 0, 0);
        public virtual Vector2 GlobalPosition
        {
            get
            {
                if (Parent != null) return Position + Parent.Position;
                else return Position;
            }
        }

        public GameObject(string id = "", int layer = 0)
        {
            this.id = id;
            this.layer = layer;
        }

        public virtual void Update(GameTime gameTime)
        {
            //If the object is not static, move it.
            if (!IsStatic)
                Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
        }

        public virtual void HandleInput(InputHelper ih)
        {
        }

        public virtual void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
        }

        public virtual void Reset()
        {
        }
    }
}

