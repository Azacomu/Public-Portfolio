﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzaEngine
{
    public class GUIObject : SpriteGameObject
    {
        public override bool IsGUI => true;

        public GUIObject(string assetName, string id = "", int layer = 10) : base(assetName, id, layer)
        {

        }
    }
}

