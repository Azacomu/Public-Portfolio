﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using AzaEngine.Loading;

namespace AzaEngine
{
    /// <summary>
    /// Used to load single sprites from larger spritesheets, also used for basic sprite manipulation, like mirror, scale and rotation.
    /// </summary>
    public class SpriteSheet
    {
        public float Scale;
        public float Rotation;
        public bool Mirror;
        public Color Color;

        protected int sheetIndex;
        protected int sheetColumns;
        protected int sheetRows;
        protected Texture2D sprite;

        //New vars used for xml spritesheets.
        protected Rectangle SrcRectangle;

        public int SheetIndex
        {
            get { return sheetIndex; }
            set
            {
                if (value < sheetColumns * sheetRows && value >= 0)
                    ChangeSprite(value);
            }
        }
        public int Width => SrcRectangle.Width;
        public int Height => SrcRectangle.Height;
        public int NumberSprites => sheetColumns * sheetRows;

        public SpriteSheet(Texture2D texture, int columns = 1, int rows = 1, int sheetIndex = 0)
        {
            Color = Color.White;
            sprite = texture;
            this.sheetIndex = sheetIndex;
            sheetColumns = columns;
            sheetRows = rows;
            Scale = 1.0f;
            Rotation = 0.0f;

            //Make the srcRectangle of the sprite indices given.
            int width = sprite.Width / columns;
            int height = sprite.Height / rows;

            int columnIndex = sheetIndex % columns;
            int rowIndex = sheetIndex / columns % rows;
            SrcRectangle = new Rectangle(columnIndex * width, rowIndex * height, width, height);
        }
        //New constuctors for XML spritesheets.
        public SpriteSheet(Texture2D texture, int x, int y, int width, int height)
        {
            Color = Color.White;
            sprite = texture;
            Scale = 1.0f;
            Rotation = 0.0f;
            SrcRectangle = new Rectangle(x, y, width, height);
        }
        public SpriteSheet(Texture2D texture, Rectangle srcRectangle)
        {
            Color = Color.White;
            sprite = texture;
            Scale = 1.0f;
            Rotation = 0.0f;
            SrcRectangle = srcRectangle;
        }
        //Easy to use constructor using AssetInfo
        public SpriteSheet(Texture2D texture, AssetInfo info)
        {
            Color = Color.White;
            sprite = texture;
            Scale = 1.0f;
            Rotation = 0.0f;

            if (info.Type == AssetType.TEXTURE)
            {
                this.sheetIndex = info.SheetIndex;
                sheetColumns = info.Columns;
                sheetRows = info.Rows;

                //Make the srcRectangle of the sprite indices given.
                int width = sprite.Width / info.Columns;
                int height = sprite.Height / info.Rows;

                int columnIndex = sheetIndex % info.Columns;
                int rowIndex = sheetIndex / info.Columns % info.Rows;
                SrcRectangle = new Rectangle(columnIndex * width, rowIndex * height, width, height);
            }
            else
            {
                SrcRectangle = new Rectangle(info.X, info.Y, info.Width, info.Height);
            }
        }

        //Draw the sprite that it should draw according to the sheetindex.
        public void Draw(SpriteBatch spriteBatch, Vector2 position, Vector2 origin)
        {
            SpriteEffects spriteEffects = SpriteEffects.None;
            if (Mirror)
                spriteEffects = SpriteEffects.FlipHorizontally;

            spriteBatch.Draw(sprite, position, SrcRectangle, Color, Rotation, origin, Scale, spriteEffects, 0);
        }

        //Get the color of a certain pixel at the right position in the spritesheet. (Used for pixel perfect collisions.)
        public Color GetPixelColor(int x, int y)
        {
            Rectangle sourceRectangle = new Rectangle(SrcRectangle.X + x, SrcRectangle.Y + y, 1, 1);
            Color[] retrievedColor = new Color[1];
            sprite.GetData<Color>(0, sourceRectangle, retrievedColor, 0, 1);
            return retrievedColor[0];
        }

        //Method to change the sprite to another area.
        protected void ChangeSprite(int sheetIndex)
        {
            int columnIndex = sheetIndex % sheetColumns;
            int rowIndex = sheetIndex / sheetColumns % sheetRows;
            SrcRectangle = new Rectangle(columnIndex * Width, rowIndex * Height, Width, Height);
        }
        public void ChangeSprite(Rectangle src)
        {
            SrcRectangle = src;
        }
    }
}

