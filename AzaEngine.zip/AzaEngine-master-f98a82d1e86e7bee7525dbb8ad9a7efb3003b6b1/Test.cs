﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzaEngine
{
    /// <summary>
    /// Class used to test methods, overrides and such.
    /// </summary>
    public class Test
    {
        
        
        public void TestMethod()
        {
            
        }
    }
}
