﻿using Microsoft.Xna.Framework;
using System;
using System.IO;
using System.Reflection;

namespace AzaEngine
{
    /// <summary>
    /// Class with several small static methods needed to help with calculations and such.
    /// </summary>
    public class AzaHelper
    {
        /// <summary>
        /// Method to calculate the intersection rectangle (the overlapping part) between the given rectangles.
        /// </summary>
        /// <param name="rect1">First Rectangle</param>
        /// <param name="rect2">Second Rectangle</param>
        /// <returns>Intersection Rectangle</returns>
        public static Rectangle Intersection(Rectangle rect1, Rectangle rect2)
        {
            int xmin = (int)MathHelper.Max(rect1.Left, rect2.Left);
            int xmax = (int)MathHelper.Min(rect1.Right, rect2.Right);
            int ymin = (int)MathHelper.Max(rect1.Top, rect2.Top);
            int ymax = (int)MathHelper.Min(rect1.Bottom, rect2.Bottom);
            return new Rectangle(xmin, ymin, xmax - xmin, ymax - ymin);
        }

        public const int AVMax = 10; //Number of seconds to calculate average FPS over.

        public static int curFPSCount;
        public static int AVCount;
        public static int AVFPS;
        public static float timePast;

        /// <summary>
        /// Property to get the Directory the build is in.
        /// </summary>
        public static string AssemblyDirectory
        {
            get
            {
                string codeBase = Assembly.GetExecutingAssembly().CodeBase;
                UriBuilder uri = new UriBuilder(codeBase);
                string path = Uri.UnescapeDataString(uri.Path);
                return Path.GetDirectoryName(path);
            }
        }

        /// <summary>
        /// Update used for updating the FPS counter.
        /// </summary>
        /// <param name="gameTime">Time in the game.</param>
        public static void UpdateFPS(GameTime gameTime)
        {
            curFPSCount++;
            timePast += (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (timePast >= 1.0f)
            {
                timePast = 0;
                AVFPS += curFPSCount;
                AVCount++;
                curFPSCount = 0;
                if (AVCount >= AVMax)
                {
                    int avg = AVFPS / AVMax;
                    Log.Write(LogType.INFO, "Average FPS: " + avg);
                    AVFPS = 0;
                    AVCount = 0;
                }
            }
        }
    }
}
