﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzaEngine
{
    /// <summary>
    /// Class with all needed constants for the game.
    /// Mostly used for default settings (and max settings), so that if there is no settings file this can be used.
    /// Recommended to make a derived class with game specific constants added.
    /// </summary>
    public class C
    {
        #region Constants
        /* CONSTANTS SECTION */

        #region Graphics
        //Graphics base and max settings.
        public const int ScreenWidth = 1280;
        public const int ScreenHeight = 720;
        public const bool Vsync = false;
        public const bool IsFullscreen = false;

        public const int MaxWidth = 1920;
        public const int MaxHeight = 1080;
        #endregion

        #region Sound
        //Sound base settings.
        public const float MasterVol = 0.5f;
        public const float MusicVol = 0.75f;
        public const float SoundVol = 1.0f;
        public const float AmbientVol = 0.9f;
        public const float VoiceVol = 1.0f;
        #endregion

        #region Game Specific
        public const int TileWidth = 32;
        public const int TileHeight = 32;
        public const int GameWidth = 1280;
        public const int GameHeight = 720;
        public const int EdgeOffset = 0;
        #endregion

        #region Paths
        //Paths needed through the game, like for settings.
        public const string SettingPath = "Content/settings.txt";
        public const string ContentPath = "Content";
        public const string AssetPath = "Content/paths.txt";
        public const string TilePath = "Content/tileIndices.txt";
        #endregion

        #region Level Designer
        public const int SpecialTilesNumber = 500;
        public const int LevelDesignIconWidth = 16;
        public const int LevelDesignIconHeight = 16;
        public const int LevelDesignGUIBarWidth = 150;
        public const int LevelDesignWidth = 1600;
        public const int LevelDesignHeight = 900;
        public const bool LevelDesignFullscreen = false;
        public const int LevelGridWidth = 32;
        public const int LevelGridHeight = 32;
        #endregion

        #region GUI

        #endregion

        #endregion
    }
}