//Initialize the tables in the database, if they were not initialized yet.
(function () {
    "use strict";

    module.exports.initDatabase = function (db) {
        //Create table to save all Products in.
        db.run("CREATE TABLE IF NOT EXISTS Products (" +
            "Product_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Productname TEXT," +
            "Manufacturer TEXT," +
            "Category INT," +
            "Price INTEGER," +
            "Amount INTEGER," +
            "Image TEXT," +
            "Seller_ID INTEGER)");

        //Create table to save all Users in.
        db.run("CREATE TABLE IF NOT EXISTS Users (" +
            "User_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Username TEXT UNIQUE," +
            "SaltedPassWordHash TEXT," +
            "FirstName TEXT," +
            "LastName TEXT," +
            "Email TEXT UNIQUE," +
            "IsSeller BOOLEAN," +
            "SessionVersion INTEGER" +
            ")");

        //Create table to save all History in.
        db.run("CREATE TABLE IF NOT EXISTS History (" +
            "History_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Productname TEXT," +
            "Price INTEGER," +
            "Amount INTEGER," +
            "Product_ID INTEGER," +
            "User_ID INTEGER," +
            "Seller_ID INTEGER," +
            "Date TEXT" +
            ")");

        //Create table to save all Ratings in.
        db.run("CREATE TABLE IF NOT EXISTS Ratings (" +
            "Rate_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "User_ID INTEGER," +
            "Product_ID INTEGER," +
            "Rating INTEGER," +
            "Comment TEXT," +
            "Username TEXT" +
            ")");

        //Create table to save all Categories in.
        db.run("CREATE TABLE IF NOT EXISTS Categories (" +
            "Category_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Categoryname TEXT UNIQUE," +
            "CategoryParentID INTEGER" + //Is NULL if it is a main category.
            ")");
    }
})();