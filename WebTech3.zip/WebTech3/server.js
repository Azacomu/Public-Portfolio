﻿//Main server logic, calls other modules as well
"use strict";

var express = require("express");
var morgan = require("morgan");
var session = require("express-session");
var sqliteStore = require("connect-sqlite3")(session);
var bodyParser = require("body-parser");
var sqlite3 = require("sqlite3");
var fs = require("fs");
var busboy = require("connect-busboy");

var webshopUser = require("./webshopUser");
var product = require("./product");
var dbinit = require("./dbinit");

//If the onFinalServer file exists, we're on the final server and need to add /group36 to paths.
var baseUrl = fs.existsSync("onFinalServer") ? "/group36" : "";

var app = express();

app.use(morgan(":method :url (:status) - :response-time ms"));

app.use(express.static("static"));

app.use(busboy()); //Used for file uploads

app.set("views", "./views");
app.set("view engine", "pug");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: "fsldfeoiwrfjulnsenfwerdsefioerldnsflnio",
    cookie: { maxAge: 365 * 24 * 60 * 60 * 1000 },
    resave: true,
    saveUninitialized: true,
    store: new sqliteStore(),
    table: "sessions"
}));

//Init database
var dbFile = "database.db";
var dbExists = fs.existsSync(dbFile);

//If the database doesn't exist, create a new file:
if (!dbExists) {
    fs.openSync(dbFile, "w");
}

//Then, open the database
var db = new sqlite3.Database(dbFile);

//And init it (if needed)
//if (!dbExists) {
    db.serialize(function () {
        dbinit.initDatabase(db);
    });
//}

//Load database extension file for math functions
//Extension file from https://www.sqlite.org/contrib
db.loadExtension("libsqlitefunctions.so", function(err) {
    if (err !== null) {
        db.loadExtension("/home/group36/libsqlitefunctions", function (err) {
            if (err !== null)
                console.log("Error loading extra sqlite functions like sqrt: " + err);
        });
    }
});

//Set global variables for PUG
app.use((req, res, next) => {
    var loggedIn = req.session.userID != undefined; //Check if user is undefined or null
    res.locals.loggedIn = loggedIn;
    res.locals.homeLink = baseUrl;// req.protocol + "://" + req.get("host");
    if (!loggedIn)
        next();
    else {
        //Get information we (almost) always need about the user from the database.
        //Storing this info in the session wouldn't be wise as it can be changed, while the user can also have multiple sessions.

        db.get("SELECT Username, IsSeller, SessionVersion FROM Users WHERE User_ID == ?",
            req.session.userID,
            function (err, userFromDatabase) {
                if (err != null || userFromDatabase == undefined || req.session.sessionVersion !== userFromDatabase["SessionVersion"]) {
                    //Invalidate session by logging off if we can't find the user or if the session version isn't correct.
                    //Session version is used to enable logging off everywhere.
                    webshopUser.logOff(req, res);
                } else {
                    res.locals.userName = userFromDatabase["Username"];
                    res.locals.isSeller = userFromDatabase["IsSeller"] ? true : false;
                    
                }

                next();
            });
    }
});

//Init user module and let it handle requests.
webshopUser.init(db, baseUrl);
product.init(db, baseUrl);

//Initialize all links and form actions to the correct functions to run.
app.get("/login", webshopUser.handleLogin);
app.post("/login", webshopUser.handleLoginDone);

app.get("/register", webshopUser.handleRegister);
app.post("/register", webshopUser.handleRegisterDone);

app.get("/settings/account", webshopUser.changeAccountSettings);
app.post("/settings/account", webshopUser.accountActionDone);

app.get("/settings/profile", webshopUser.changeProfile);
app.post("/settings/profile", webshopUser.changeProfileDone);

app.get("/logoff", webshopUser.handleLogOff);

app.get("/teapot", function (req, res) {
    res.sendStatus(418);
});

app.get("/addProduct", product.renderAddProduct);
app.post("/addProduct", product.addProduct);

app.post("/rateProduct", product.getRating);

app.get("/product", product.loadProduct);
app.get("/products", product.showProducts);

app.get("/buyConfirm", product.buyConfirm);
app.post("/buyProduct", product.buyProduct);

app.get("/settings/categories", product.changeCategories);
app.post("/settings/categories", product.changeCategoriesDone);

app.get("/history", product.showHistory);
app.get("/sellHistory", product.sellHistory);
app.get("/inventory", product.inventory);
app.post("/addToInventory", product.addToInventory);

app.post("/api/products", product.getProductsJSON);

//Get the home page
app.get("/", (req, res) => {
    //Get top products
    db.all(
        "SELECT Products.*, IFNULL(SUM(History.Amount), 0) TotalSold " +
        "FROM Products LEFT JOIN History ON Products.Product_ID == History.Product_ID " +
        "WHERE Products.Amount > 0 GROUP BY Products.Product_ID ORDER BY TotalSold DESC LIMIT 6",
        (
            err, topProducts) => {
            if (err) {
                throw err;
            }

            //If the user has not logged in, just render the page with top products (no recommendations)
            if (req.session.userID == undefined) {
                res.render("index", { topProducts: topProducts });
                return;
            }

            //Get recommended products query
            fs.readFile("recommended.sqlite",
                "utf-8",
                (error, recommendedQuery) => {
                    if (error) throw error;

                    //Get recommended products
                    db.all(recommendedQuery.replace(/\${thisUser}/g, req.session.userID),
                        (err, rows) => {
                            if (err !== null) {
                                console.log(err);
                                return;
                            }

                            res.render("index", { recommended: rows, topProducts: topProducts });
                        });
                });
        });
});

//Live site SQL statements for testing - only for accounts called admin (see readme for security info)
app.get("/admin/sql", (req, res, next) => {
    if (res.locals.userName === "admin") //Indirectly set from server-side session
        res.render("sqlAdmin");
    else next(); //404 for normal users.
});

//See previous - this is the POST.
app.post("/admin/sql", (req, res, next) => {
    if (res.locals.userName === "admin") {
        //Run SQL and whatever the result simply show the admin page again
        db.run(req.body["sqlStatement"]);
        res.render("sqlAdmin");
    }
    else next();
});

//Not found, show 404 error.
app.use((request, response) => {
    response.status(404).send("<p>We couldn't find that page :/</p>");
});

//Listen on port 8116.
app.listen(8116);

//Show that the server is running.
console.log("Server running at http://127.0.0.1:8116/");
