//User module for the webshop
(function () {
    "use strict";

    var bcrypt = require("bcrypt");
    var emailValidator = require("email-validator");
    var db, baseUrl; //Database and site base url
    const passwordHashRounds = 10; //Number of rounds to use for bCrypt. More: longer hashing time, so more security

    //Common queries
    var registerUser, loginUser;

    //Init the module by giving a database
    module.exports.init = function(database, appBaseUrl) {
        db = database;
        registerUser = db.prepare("INSERT INTO Users VALUES (NULL, ?, ?, ?, ?, ?, ?, 0)");
        loginUser = db.prepare("SELECT User_ID, SaltedPassWordHash, SessionVersion FROM Users WHERE Username == ?");
        baseUrl = appBaseUrl;
    }

    //Show login page
    module.exports.handleLogin = function (req, res) {
        res.render("login", { errorMessage: "" });
    }

    //Handle post request to login page
    module.exports.handleLoginDone = function (req, res) {
        logOff(req, res); //Log off the user if they hadn't already

        var userName = req.body["username"], password = req.body["password"];
        
        //Check if there aren't any empty fields (for if client-side checks fail)
        if (userName === "" || password === "" || userName === undefined || password === undefined) {
            //A simple error is enough, as most browsers will show a more user-friendly message automatically anyway
            res.render("login", { errorMessage: "Please enter an username and password!" });
            return;
        }

        //Get user from database
        loginUser.get(userName,
            function (err, userFromDatabase) {
                if (userFromDatabase == undefined) {
                    //Show that we couldn't find the username
                    //No, this is not unsecure. See https://kev.inburke.com/kevin/invalid-username-or-password-useless/
                    //Would normally rate limit this, but not really needed for a webtech assignment
                    res.render("login", { errorMessage: "We couldn't find that username!", userName: userName });
                    return;
                }

                //Check the password
                bcrypt.compare(password, userFromDatabase.SaltedPassWordHash).then(function (correct) {
                    if (correct) {
                        //Set vars & redirect
                        loginFinalize(req, res, userFromDatabase["User_ID"], userFromDatabase["SessionVersion"]);
                    } else {
                        //Password incorrect, don't allow log in
                        res.render("login", { errorMessage: "That password is incorrect!", userName: userName });
                    }
                });
            });
    }

    //Show registration page
    module.exports.handleRegister = function (req, res) {
        res.render("register", { errorMessage: "" });
    }

    //On POST request to registration page
    module.exports.handleRegisterDone = function(req, res) {
        logOff(req, res); //Log off any current user

        var userName = req.body["username"], password = req.body["password"],
            firstName = req.body["firstName"], lastName = req.body["lastName"],
            email = req.body["email"],
            wantsSeller = req.body["wantsSeller"];
        var hashedPassword = null;

        //If we don't have a password, use the password from the session
        if ((password === "" || password == undefined) && req.session.storedPasswordWithHash != undefined) {
            password = "(use existing)";
            hashedPassword = req.session.storedPasswordWithHash;
        }

        //Check if there aren't any empty fields (for if client-side checks fail)
        if (userName === "" || password === "" || firstName === "" || lastName === "" || email === "" ||
            userName == undefined || password == undefined || firstName == undefined ||
            lastName == undefined || email == undefined) {
            //A simple error is enough, as most browsers will show a more user-friendly message automatically anyway
            renderRegisterPageWithErrors(req, res, "You must enter an username, password, first name, last name and email adress!");
            return;
        }

        //Check if password was of correct length
        if (password.length < 8) {
            renderRegisterPageWithErrors(req, res, "Your password must be at least 8 characters!");
            return;
        }

        if (password.length > 50) {
            renderRegisterPageWithErrors(req, res, "Your password cannot be longer than 50 characters!");
            return;
        }
        
        //Function to call when we have the hash
        function onHasHash(err, hashWithSalt) {
            //Check if the email was correct
            if (!emailValidator.validate(email)) {
                //Show error but do already store hashed+salted password so the user doesn't have to type it again
                req.session.storedPasswordWithHash = hashWithSalt;
                renderRegisterPageWithErrors(req, res, "Please enter a valid email adress!", true);
                return;
            };

            //Check for uniqueness of username and email
            db.all("SELECT Username, Email FROM Users WHERE Username == ? OR Email == ?",
                userName,
                email,
                function (err2, rows) {
                    //If we find a row, the user cannot register as there is already an user with the same username/email.
                    if (rows.length === 0 && err2 == null) {
                        registerUser.run(userName, hashWithSalt, firstName, lastName, email, wantsSeller ? 1 : 0, function() {
                            //Get the new user ID and session version because we'll want to store it in the session
                            db.get("SELECT User_ID, SessionVersion FROM Users WHERE Username == ?",
                                userName,
                                function(err, userFromDatabase) {
                                    //Remove password from session
                                    req.session.storedPasswordWithHash = null;

                                    //Registered, redirect
                                    loginFinalize(req, res, userFromDatabase["User_ID"], userFromDatabase["SessionVersion"]);
                                });
                        });
                    } else {
                        //Not registered, try again
                        let errorMessage = "";
                        for (let row of rows) {
                            if (row["Email"] === email)
                                errorMessage += "There's already an user with that email adress! ";
                            if (row["Username"] === userName)
                                errorMessage += "There's already an user with that user name! ";
                        }

                        if (errorMessage === "") //Someone probably registered with the same username/email during the request
                            errorMessage = "An unexpected error happened. Please try again.";

                        //Show error but do already store hashed+salted password so the user doesn't have to type it again
                        req.session.storedPasswordWithHash = hashWithSalt;
                        renderRegisterPageWithErrors(req, res, errorMessage, true);
                    }
                });
        };

        //Use bcrypt to hash the password with salt
        if (hashedPassword === null)
            bcrypt.hash(password, passwordHashRounds, onHasHash);
        else
            //We already have a hashed password!
            onHasHash({}, hashedPassword);
    }

    //Render account settings page
    module.exports.changeAccountSettings = function(req, res) {
        if (redirectIfNotLoggedIn(req, res)) return;
        var doneText = "";

        //Render done text if we have it
        if (req.session.doneText) {
            doneText = req.session.doneText;
            req.session.doneText = null;
        }

        res.render("accountsettings", { doneText: doneText });
    }

    //Handle POST requests to the account settings page
    module.exports.accountActionDone = function(req, res) {
        if (redirectIfNotLoggedIn(req, res)) return;

        switch (req.body["accountChangeAction"]) {
            case "password":
                //Change the password
                changePasswordDone(req, res);
                break;
            case "becomeSeller":
                //Become a seller
                becomeSellerDone(req, res);
                break;
            case "changeUsername":
                //Change the username
                changeUsernameDone(req, res);
                break;
            case "changeEmail":
                //Change the email adress
                changeEmailDone(req, res);
                break;
            case "logOffEverywhere":
                //Log off on all other devices
                logOffEverywhere(req, res);
                break;
        }
    }

    //On a POST request to the password change part of the account settings
    function changePasswordDone(req, res) {
        var userID = req.session.userID;

        const oldPassword = req.body["oldPassword"], newPassword = req.body["newPassword"];
        
        //Check if there aren't any empty fields (for if client-side checks fail)
        if (oldPassword === "" || newPassword === "" || oldPassword === undefined || newPassword === undefined) {
            //A simple error is enough, as most browsers will show a more user-friendly message automatically anyway
            res.render("accountsettings", { errorMessagePassword: "Please enter your old and a new password!" });
            return;
        }

        //Check if old password is correct
        checkPasswordOfCurrentUser(userID, oldPassword).then(correct => {
            if (! correct) {
                res.render("accountsettings", { errorMessagePassword: "Your old password isn't correct!" });
                return;
            }

            //Old password was correct

            //Check if new password is of correct length
            if (newPassword.length < 8) {
                res.render("accountsettings",
                    { errorMessagePassword: "Your new password must be at least 8 characters!" });
                return;
            }

            if (newPassword.length > 50) {
                res.render("accountsettings",
                    { errorMessagePassword: "Your new password cannot be longer than 50 characters!" });
                return;
            }

            //The new password is ok, hash it and store it
            bcrypt.hash(newPassword, passwordHashRounds, function(err, hashWithSalt) {
                db.run("UPDATE Users SET SaltedPassWordHash = ? WHERE User_ID == ?", hashWithSalt, userID, function() {
                    //Done! Store done text and redirect to GET of same page to avoid resubmit if the user reloads
                    req.session.doneText = "Your password has been succesfully changed.";
                    res.redirect(baseUrl + "/settings/account");
                });
            });
        });
    }

    //On POST request to account settings page when the user wants to become a seller
    function becomeSellerDone(req, res) {
        var userID = req.session.userID;

        const password = req.body["password"];

        if (password === "" || password == undefined) {
            res.render("accountsettings", { errorMessageSeller: "Please enter your password to confirm!" });
            return;
        }

        //You need to enter your password to become a seller
        checkPasswordOfCurrentUser(userID, password).then(correct => {
            if (! correct) {
                res.render("accountsettings", { errorMessageSeller: "Your password isn't correct!" });
                return;
            }

            //So, the password is correct
            db.run("UPDATE Users SET IsSeller = 1 WHERE User_ID == ?",
                userID,
                function() {
                    //And the user is now a seller!
                    req.session.doneText = "You're now a seller!";
                    res.redirect(baseUrl + "/settings/account");
                });
        });
    }

    //On POST request to the account settings page when the user wants to change their username.
    function changeUsernameDone(req, res) {
        var userID = req.session.userID;

        const password = req.body["password"], newUserName = req.body["username"];

        //If any data is not provided, show an error
        if (password === "" || password == undefined || newUserName === "" || newUserName == undefined) {
            res.render("accountsettings", { errorMessageChangeUsername: "Please enter your desired new username and your password!" });
            return;
        }

        checkPasswordOfCurrentUser(userID, password).then(correct => {
            if (! correct) {
                res.render("accountsettings", { errorMessageChangeUsername: "Your password isn't correct!", newUserName: newUserName });
                return;
            }

            //So, the password is correct. Check if someone else already has the username
            db.get("SELECT Username FROM Users WHERE Username == ?",
                newUserName,
                function(err, result) {
                    if (result == undefined) {
                        //We can now change the username
                        db.run("UPDATE Users SET username = ? WHERE User_ID == ?",
                            newUserName, userID, function(err2) {
                                if (err2 !== null) { //Someone probably claimed the username between the first db.get and this one
                                    res.render("accountsettings", { errorMessageChangeUsername: "Someone else already has that username!",
                                        newUserName: newUserName });
                                    return;
                                }

                                //We changed the username
                                req.session.user = newUserName;
                                req.session.doneText = "Your username has now been changed!";
                                res.redirect(baseUrl + "/settings/account");
                            });
                    } else {
                        res.render("accountsettings", { errorMessageChangeUsername: "Someone else already has that username!",
                            newUserName: newUserName });
                    }
                });
        });
    }

    //On POST request to the account settings page when the user wants to change their email adress
    function changeEmailDone(req, res) {
        var userID = req.session.userID;

        const password = req.body["password"], newEmail = req.body["email"];
        
        if (password === "" || password == undefined || newEmail === "" || newEmail == undefined) {
            res.render("accountsettings", { errorMessageChangeEmail: "Please enter your new email adress and your password!" });
            return;
        }

        //Check if the email is ok
        if (!emailValidator.validate(newEmail)) {
            res.render("accountsettings", { errorMessageChangeEmail: "Please enter a valid email adress!", newEmail: newEmail });
            return;
        };

        checkPasswordOfCurrentUser(userID, password).then(correct => {
            if (! correct) {
                res.render("accountsettings", { errorMessageChangeEmail: "Your password isn't correct!", newEmail: newEmail });
                return;
            }

            //So, the password is correct. Check if someone else already has the email
            db.get("SELECT Email FROM Users WHERE Email == ?",
                newEmail,
                function(err, result) {
                    if (result == undefined) {
                        //We can now change the email adress
                        db.run("UPDATE Users SET Email = ? WHERE User_ID == ?",
                            newEmail, userID, function(err2) {
                                if (err2 !== null) { //Someone probably claimed the email adress between the first db.get and this one
                                    res.render("accountsettings", { errorMessageChangeEmail: "Someone else already has that email adress!",
                                        newEmail: newEmail });
                                    return;
                                }

                                //We changed the email adress
                                req.session.doneText = "Your email adress has now been changed!";
                                res.redirect(baseUrl + "/settings/account");
                            });
                    } else {
                        res.render("accountsettings", { errorMessageChangeEmail: "Someone else already has that email adress!",
                            newEmail: newEmail });
                    }
                });
        });
    }

    //Log off on all other devices/browsers (as a result from POST request to account settings)
    function logOffEverywhere(req, res) {
        //Update session version
        db.run("UPDATE Users SET SessionVersion = SessionVersion + 1 WHERE User_ID == ?",
            req.session.userID,
            function() {
                //If two people logged in with the same account would do this at the same time, both would be logged off, which is fine.
                req.session.sessionVersion += 1;

                req.session.doneText = "You've been logged off everywhere else!";
                res.redirect(baseUrl + "/settings/account");
            });
    }

    //Render the profile change page
    module.exports.changeProfile = function(req, res) {
        if (redirectIfNotLoggedIn(req, res)) return;
        const userID = req.session.userID;

        var doneText = "";

        //Render done text if we have it
        if (req.session.doneText) {
            doneText = req.session.doneText;
            req.session.doneText = null;
        }

        renderUpdateProfilePage(userID, res, doneText, false);
    }

    //Handle POST requests to the profile change page
    module.exports.changeProfileDone = function(req, res) {
        if (redirectIfNotLoggedIn(req, res)) return;
        const userID = req.session.userID;

        const firstName = req.body["firstName"], lastName = req.body["lastName"];

        //Check if there aren't any empty fields (for if client-side checks fail)
        if (firstName === "" || lastName === "" || firstName == undefined || lastName == undefined) {
            //A simple error is enough, as most browsers will show a more user-friendly message automatically anyway
            renderUpdateProfilePage(userID, res, "Your first and last name can't be empty!", true);
            return;
        }

        //Update the page in the database
        db.run("UPDATE Users SET FirstName = ?, LastName = ? WHERE User_ID == ?",
            firstName,
            lastName,
            userID,
            function () {
                //Then redirect back to the GET version of the page
                req.session.doneText = "Your profile has been updated!";
                res.redirect(baseUrl + "/settings/profile");
            });
    }

    //Sign off an user
    module.exports.handleLogOff = function(req, res) {
        logOff(req, res); //Log off (this does nothing if we're not logged in)
        res.redirect(baseUrl + "/"); //Then redirect to home
    }

    //We'd like to export the log off function so it can be used outside of the module
    module.exports.logOff = logOff;

    //Set session information and redirect user to login end page
    function loginFinalize(req, res, userID, sessionVersion) {
        req.session.userID = userID;
        req.session.sessionVersion = sessionVersion;
        res.redirect(baseUrl + "/");
    }

    //Log off the user
    function logOff(req, res) {
        //Reset user ID and set as not logged in
        res.locals.loggedIn = false;
        req.session.userID = null;
        req.session.sessionVersion = null;
    }

    //Redirect to the log in page if the user isn't signed in
    function redirectIfNotLoggedIn(req, res) {
        if (! isLoggedIn(req)) {
            res.redirect(baseUrl+ "/login");
            return true; //We redirected
        }
        return false;
    }

    //Check if the user is logged in
    function isLoggedIn(req) {
        return req.session.userID != null;
    }

    //Render the register page, possibly with one or more errors
    function renderRegisterPageWithErrors(req, res, errorMessage, hasStoredHashed = false) {
        res.render("register", { errorMessage: errorMessage, userName: req.body["username"],
            firstName: req.body["firstName"], lastName: req.body["lastName"],
            email: req.body["email"],
            wantsSeller: req.body["wantsSeller"], hasStoredHashed: hasStoredHashed
        });
    }

    //Check the password of the current user with an entered password.
    //Returns promise
    function checkPasswordOfCurrentUser(userID, enteredPassword) {
        return new Promise(onDone => {
            db.get("SELECT SaltedPassWordHash FROM Users WHERE User_ID == ?", userID,
                function(err, userFromDatabase) {
                    bcrypt.compare(enteredPassword, userFromDatabase.SaltedPassWordHash).then(onDone);
                });
        });
    }

    //Render the update profile page, possibly with an error
    function renderUpdateProfilePage(userID, res, statusMessage, statusIsError) {
        db.get("SELECT FirstName, LastName FROM Users WHERE User_ID == ?",
            userID,
            function(err, userFromDatabase) {
                res.render("profilesettings",
                    {
                        firstName: userFromDatabase["FirstName"],
                        lastName: userFromDatabase["LastName"],
                        statusMessage: statusMessage,
                        statusIsError: statusIsError
                    });
            });
    }
})();