//Node.js file for retrieving and showing products.
(function () {
    "use strict";

    //Initialize a few variables
    var db;
    var addProduct, getProduct, addHistory;
    var fs = require("fs");
    var baseUrl;

    //Vars needed for images.
    var imgdir = __dirname;
    imgdir += "/static/images/";

    //Function to init the database.
    module.exports.init = function (database, appBaseUrl) {
        db = database;
        baseUrl = appBaseUrl;
        addProduct = db.prepare("INSERT INTO Products VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)");
        getProduct = db.prepare("SELECT Productname, Manufacturer, Category, Price, Amount, Image, Seller_ID FROM Products WHERE Product_ID == ?");
        addHistory = db.prepare("INSERT INTO History VALUES (NULL, ?, ?, ?, ?, ?, ?, datetime('now'))");
    }

    //Function to add a product.
    module.exports.loadProduct = function (req, res) {
        //Get the id, then load the product from the database.
        var prodID = req.query["id"];
        const error = req.query["err"]; //Error code if needed.

        //If there is no prodID, render with an error.
        if (prodID == undefined)
        {
            res.redirect(baseUrl + "/products?err=pnf");
            return;
        }

        //Add a text about the error on the page if needed.
        var errorText = "";
        if (error)
        {
            switch (error)
            {
                //Error messages
                case "b0":
                    errorText = "Please select an amount higher than 0 to buy!";
                    break;
                case "bn":
                    errorText = "The selected amount is not in stock, please keep an eye on the stock amount!";
                    break;
                case "re":
                    errorText = "There was an error saving the rating, please try again later!";
                    break;
                case "r0":
                    errorText = "Please enter a rating higher than 0!";
                    break;
                case "rn":
                    errorText = "Please enter a rating between 1 and 5!";
                    break;
                case "unk":
                    errorText = "Something went wrong, please try again later!";
                    break;
            }
        }
        
        //Try to select the product from the database.
        getProduct.get(prodID, function (err, product) {
            if (product == undefined)
            {
                //Product was not found.
                res.redirect(baseUrl + "/products?err=pnf");
                return;
            }

            //Check whether the user bought this before.
            db.all("SELECT * FROM History WHERE User_ID == ? AND Product_ID == ?", req.session.userID, prodID, function (err, rows) {
                var bought = false;
                if (rows.length !== 0)
                    bought = true;
                //Then check whether the user has rated this product before.
                db.all("SELECT * FROM Ratings WHERE User_ID == ? AND Product_ID == ?", req.session.userID, prodID, function (err, rows) {
                    var rated = false;
                    if (rows.length !== 0)
                        rated = true;
                    //Then load all ratings for this product to show on the page.
                    db.all("SELECT Username, Rating, Comment FROM Ratings WHERE Product_ID == ?", prodID, function (err, ratings) {
                        if (ratings == undefined)
                            ratings = {};
                        //Finally load the average rating of the product and render the page with all the information gathered.
                        db.get("SELECT avg(Rating) FROM Ratings WHERE Product_ID == ?", prodID, function (err, avgRating) {
                            res.render('product', {
                                name: product["Productname"],
                                manu: product["Manufacturer"],
                                price: product["Price"],
                                amount: product["Amount"],
                                image: res.locals.homeLink + "/images/" + product["Image"],
                                prodID: prodID,
                                bought: bought,
                                rated: rated,
                                ratings: ratings,
                                avgRating: Math.round(avgRating["avg(Rating)"]),
                                error: errorText
                            });
                        });
                    });
                });
            });
        });
    }

    //Function to save the entered rating.
    module.exports.getRating = function (req, res) {
        const comment = req.body["comment"];
        const rating = req.body["rating"];
        var prodID = req.body["prodID"];

        //Give error if the rating is not in the right format (1 to 5)
        if (rating <= 0)
        {
            //Too low.
            res.redirect(`${baseUrl}/product?id=${prodID}&err=r0`);
            return;
        }
        else if (rating > 5)
        {
            //Too high.
            res.redirect(`${baseUrl}/product?id=${prodID}&err=rn`);
            return;
        }

        if (prodID != undefined) {
            db.run("INSERT INTO Ratings VALUES (NULL, ?, ?, ?, ?, ?)", req.session.userID, prodID, rating, comment, res.locals.userName, function () {
                res.redirect(`${baseUrl}/product?id=${prodID}`);
            });
        }
        else
        {
            //Something went wrong getting info for the rating, give error.
            res.redirect(`${baseUrl}/product?id=${prodID}&err=re`);
        }
    }

    //Function to show all products.
    module.exports.showProducts = function (req, res) {
        //Catch any errors if there were any.
        const error = req.query["err"];
        var errorText = "";
        if (error) {
            switch (error) {
            case "pnf":
                errorText = "Product was not found!";
                break;
            }
        }
        var manufacturers, sellers, categories;

        db.all("SELECT DISTINCT Manufacturer FROM products", hasManufacturers);

        //Function to check what manufacturers there are.
        function hasManufacturers(err, manufacturersFromDB) {
            if (err != null)
                throw err;

            manufacturers = manufacturersFromDB.map(man => man.Manufacturer);
            db.all("SELECT DISTINCT sellerName FROM products JOIN (SELECT Username sellerName, User_ID FROM Users) ON User_ID == Seller_ID", hasSellers);
        }

        //Function to check what sellers there are.
        function hasSellers(err, sellersFromDB) {
            if (err != null)
                throw err;

            sellers = sellersFromDB.map(sell => sell.sellerName);
            getFlattenedCategories(hasCategories);
        }

        //Function to check what categories there are.
        function hasCategories(categoriesFromDB) {
            categories = categoriesFromDB;
            finallyRender();
        }

        //Finally after all checks, render the page.
        function finallyRender() {
            res.render("products", {
                manufacturers: manufacturers,
                sellers: sellers,
                errorText: errorText,
                categories: categories
            });
        }
    }

    //Function to let a buyer confirm that they want to buy something or not.
    module.exports.buyConfirm = function (req, res) {
        var prodID = req.query["prodID"];
        var amount = req.query["amount"];

        db.get("SELECT Productname, Price FROM products WHERE Product_ID == ?", prodID, function (err, product) {
            if (err || product == undefined)
            {
                //Error, send back to product page.
                res.redirect(`${baseUrl}/product?id=${prodID}&err=unk`);
                return;
            }
            res.render("confirmBuy", {
                productname: product["Productname"],
                price: product["Price"],
                amount: amount,
                prodID: prodID
            });
        });
    }

    //Function to let a user buy a product.
    module.exports.buyProduct = function (req, res) {
        var prodID = req.body["prodID"];
        var amount = req.body["amount"];

        //Check if logged in
        if (!res.locals.loggedIn) {
            //let the user know
            res.redirect(baseUrl + "/login");
            return;
        }

        //Check whether the user came from a product, otherwise give an error
        if (prodID == undefined) {
            //Redirect to products page with error?
            res.status(200).send("<p>Please select a product to buy first!</p>");
            return;
        }

        //Check if the amount is not too low.
        if (amount <= 0)
        {
            //Redirect back to product with error code not enough to buy.
            res.redirect(`${baseUrl}/product?id=${prodID}&err=b0`);
            return;
        }

        //Otherwise see the "transaction" as complete and change the database, if the product does actually exist.
        db.get("SELECT Productname, Amount, Price, Seller_ID FROM Products WHERE Product_ID == ?", prodID, function (err, product) {
            if (product == undefined)
            {
                //Redirect to products page?
                res.status(404).send("<p>Product does not exist.</p>");
                return;
            }

            //Also check whether the amount is too high.
            if (amount > product["Amount"])
            {
                res.redirect(`${baseUrl}/product?id=${prodID}&err=bn`);
                return;
            }

            //Product has been bought, now update the table and add to the history of this user and the seller.
            addHistory.run(product["Productname"], product["Price"], amount, prodID, req.session.userID, product["Seller_ID"]);

            //Also update the amount left in stock for this product.
            db.run("UPDATE Products SET Amount = ? WHERE Product_ID == ?", product["Amount"] - amount, prodID);
            
            //Show the user that he succesfully bought the product.
            res.render("boughtProduct", {
                prodID: prodID,
                name: product["Productname"]
            });
        });
    }

    //Function to add a product to the database.
    module.exports.addProduct = function (req, res) {
        var user = req.session.userID;

        //First re-check whether the user is a seller, to make sure no fake entries can enter.
        if (!checkIfSeller(res))
            return;

        //Save the photo (need a check for filename)
        var fileStream;
        var values = {};
        req.pipe(req.busboy);
        if (req.busboy) {
            console.log("trying to save file...");
            req.busboy.on("field", function (fieldname, val) {
                values[fieldname] = val;
            });
            req.busboy.on("file", function (fieldname, file, filename) {
                //If there is no filename, no file was uploaded, so default to "noimage".
                if (filename === "" || filename == undefined) {
                    values["path"] = "noimage.png";
                    //But first check if the category exists
                    db.get("SELECT * FROM Categories WHERE Category_ID == ?", values.cat,
                        (err, row) => {
                            if (err || row == undefined) {
                                //If we don't find a category, this request was probably not even uploaded with a browser
                                //because you shouldn't be able to choose other categories
                                //So, just redirect away without special error.
                                res.redirect(baseUrl + "/");
                                return;
                            }

                            addProduct.run(values.name,
                                values.manu,
                                values.cat,
                                values.price,
                                values.amount,
                                values.path,
                                user,
                                function () {
                                    //Redirect to the newly added product.
                                    db.get("SELECT last_insert_rowid()",
                                        function (err, id) {
                                            const rowid = id["last_insert_rowid()"];
                                            res.redirect(`${baseUrl}/product?id=${rowid}`);
                                        });
                                });
                        });
                }
                else {
                    //Save the picture type, as we need it to make a correct file name
                    const temp = filename.split(".");
                    const type = "." + temp[temp.length - 1];
                    //Need a name that does not exist yet, so randomly change it untill it is a new one.
                    let finalName = (Math.random() + 1).toString(36).substring(7);
                    let filePath = imgdir + finalName + type;
                    while (fs.existsSync(filePath)) {
                        //This makes a random string to add to the name, dont make the string too long.
                        if (finalName.length > 50)
                            finalName = (Math.random() + 1).toString(36).substring(7);
                        else
                            finalName += (Math.random() + 1).toString(36).substring(7);
                        filePath = imgdir + finalName + type;
                    }
                    //Open filestream to save the file to, then pipe the data to the open file.
                    fileStream = fs.createWriteStream(filePath);
                    file.pipe(fileStream);
                    //Save the filename in the database to load it on product pages.
                    values["path"] = finalName + type;
                    fileStream.on("close", function () {
                        console.log("Upload done!");
                        //After uploading the photo, save the information to the database.
                        //But first check if the category exists
                        db.get("SELECT * FROM Categories WHERE Category_ID == ?", values.cat,
                            (err, row) => {
                                if (err || row == undefined) {
                                    //If we don't find a category, this request was probably not even uploaded with a browser
                                    //because you shouldn't be able to choose other categories
                                    //So, just redirect away without special error.
                                    res.redirect(baseUrl + "/");
                                    return;
                                }

                                addProduct.run(values.name,
                                    values.manu,
                                    values.cat,
                                    values.price,
                                    values.amount,
                                    values.path,
                                    user,
                                    function () {
                                        //Redirect to the newly added product.
                                        db.get("SELECT last_insert_rowid()",
                                            function (err, id) {
                                                const rowid = id["last_insert_rowid()"];
                                                res.redirect(`${baseUrl}/product?id=${rowid}`);
                                            });
                                    });
                            });
                    });
                }
            });
        }
        else
            console.log("Error using busboy");
    }

    //Function to make the addProduct page and check whether the user is a seller, redirect otherwise.
    module.exports.renderAddProduct = function (req, res) {
        //Check whether the user is logged in and registered as seller, else redirect.
        if (!checkIfSeller(res))
            return;

        //No errors found, continue to the actual form for submitting a product.

        //First, get the flattened categories because we need them for the form
        getFlattenedCategories((categoriesFlattened) => {
            res.render("addProduct", { categories: categoriesFlattened });
        });
    }

    //Get a flattened category list from the database
    function getFlattenedCategories(whenReady) {
        db.all("SELECT * FROM Categories",
            function (err, categoriesDB) {
                const categoriesFlattened = [];

                //Until we have no more categories from the db, create one more level of categories.
                var previousLength;
                do {
                    previousLength = categoriesDB.length;

                    for (let i = categoriesDB.length - 1; i >= 0; i--) {
                        const thisDBCat = categoriesDB[i];

                        if (thisDBCat.CategoryParentID == null) {
                            thisDBCat.level = 0;
                            categoriesFlattened.push(thisDBCat);
                            categoriesDB.splice(i, 1);
                        } else {
                            const parent =
                                categoriesFlattened.findIndex(fc => fc.Category_ID === thisDBCat.CategoryParentID);
                            if (parent !== -1) {
                                thisDBCat.level = categoriesFlattened[parent].level + 1;
                                categoriesFlattened.splice(parent + 1, 0, thisDBCat);
                                categoriesDB.splice(i, 1);
                            }
                        }
                    }
                }
                while (categoriesDB.length < previousLength)

                whenReady(categoriesFlattened);
            });
    }

    //Function to view the buy history of the user.
    module.exports.showHistory = function (req, res) {
        if (!res.locals.loggedIn)
        {
            res.redirect(baseUrl + "/login");
            return;
        }

        //If the user is logged in, read the table of history (if it exists).
        //Select the ratings for every product as well and add it to the values.
        db.all("SELECT * FROM History LEFT JOIN (SELECT Rating, Product_ID prodID, User_ID userID FROM Ratings) ON Product_ID == prodID AND User_ID == userID WHERE User_ID == ?", req.session.userID, function (err, rows) {
            //Finaly render this to the page.
            res.render("history", {
                buyer: true,
                history: rows
            });
        });
    }

    //Function to view the sell history of the user.
    module.exports.sellHistory = function (req, res) {
        //First checked if logged in and a seller.
        if (!checkIfSeller(res))
            return;

        //Get all the seller history.
        db.all("SELECT * FROM History WHERE Seller_ID == ?", req.session.userID, function (err, rows) {
            res.render("history",
                {
                    buyer: false,
                    history: rows
                });
        });
    }

    //Function to show the inventory of the seller (and let him add more to the stock)
    module.exports.inventory = function (req, res) {
        //First check whether the user is a seller.
        if (!checkIfSeller(res))
            return;

        //Check whether there has been an error
        const error = req.query["err"];
        var errorText = "";
        if (error) {
            switch (error) {
                case "ns":
                    errorText = "You are not allowed to add to this product, since you are not the seller of it.";
                    break;
                case "a0":
                    errorText = "Can not add less then 1 item!";
                    break;
                case "unk":
                    errorText = "Something went wrong adding items, please try again later!";
                    break;
            }
        }

        //Finally render all products this seller has for sale.
        db.all("SELECT * FROM Products WHERE Seller_ID == ?", req.session.userID, function (err, rows) {
            res.render("inventory", {
                inventory: rows,
                error: errorText
            });
        });
    }

    //Function to add more stock to an existing product.
    module.exports.addToInventory = function (req, res) {
        var amount = parseInt(req.body["amount"]);
        var prodID = req.body["prodID"];

        if (amount <= 0)
        {
            //Can not add less then 0 items, return with error.
            res.redirect(baseUrl + "/inventory?err=a0");
            return;
        }
        db.get("SELECT * FROM Products WHERE Product_ID == ?", prodID, function (err, product) {
            //Check whether specified product exists.
            if (err || product == undefined)
            {
                //Show error if not.
                res.redirect(baseUrl + "/inventory?err=unk");
                return;
            }
            //Check whether the request came from the seller.
            if (parseFloat(product["Seller_ID"]) !== req.session.userID)
            {
                //Show error if not.
                res.redirect(baseUrl + "inventory?err=ns");
                return;
            }
            //If there is no error, update the amount in stock.
            db.run("UPDATE Products SET Amount = ? WHERE Product_ID == ?", product["Amount"] + amount, prodID, function (err) {
                if (err)
                {
                    //Give unknown error if something went wrong with the query.
                    res.redirect(baseUrl + "/inventory?err=unk");
                    return;
                }
                //Redirect back to the inventory.
                res.redirect(baseUrl + "/inventory");
            });
        });
    }

    //Function to check whether the user is a seller.
    function checkIfSeller(res) {
        if (!res.locals.loggedIn)
        {
            //If the user is not logged in yet, redirect.
            res.redirect(baseUrl + "/login");
            return false;
        }
        if (!res.locals.isSeller)
        {
            //If the user is not a seller, tell them and redirect to change that.
            res.render("notASeller");
            return false;
        }
        return true;
    }

    //Get a number of products as JSON
    module.exports.getProductsJSON = function(req, res)  {
        function sendInputError() {
            res.status(400).send({ error: "Invalid Request" });
        }

        const start = req.body["start"]; //The first item
        const num = req.body["num"]; //The number of items on a page
        //The cursor if we already have it. This is the maximum product ID returned.
        //It's used to make sure pagination works even if new products are added
        //(instead of having duplicate products/ skipping over products in that case)
        var cursor = req.body["cursor"];

        //No null, undefined, or other emptyish values
        if (start == null || start.length === 0 || num == null || num.length === 0) {
            sendInputError();
            return;
        }

        //Start and end must be digits, and if there is a cursor it must be digits, too.
        const stringOnlyContainsDigits = /^\d+$/;
        if (!stringOnlyContainsDigits.test(start) || !stringOnlyContainsDigits.test(num) || (cursor != null && !stringOnlyContainsDigits.test(cursor))) {
            sendInputError();
            return;
        }

        //The maximum amount of products you can get at one time is 100
        if (num > 100 || num === 0) {
            sendInputError();
            return;
        }

        if (cursor == null) {
            //Get the highest product id and make it cursor
            db.get("SELECT max(Product_ID) cursor FROM Products",
                (err, result) => {
                    if (err != null) {
                        //If there's an error, send it
                        console.log(err);
                        res.status(500).send({ error: "Internal Server Error" });
                        return;
                    }

                    cursor = result.cursor;
                    onHasCursor();
                });
        } else {
            onHasCursor();
        }

        //Call when we have the cursor, either from the db or from the request
        function onHasCursor() {
            var moreFilteringSQL = ""; //SQL for fitering options
            var filteringArgs = []; //Arguments for SQL fitering

            //Filtering by name
            const filterByName = req.body["name"];
            if (filterByName != null) {
                moreFilteringSQL += " AND instr(lower(name), lower(?)) > 0";
                filteringArgs.push(filterByName);
            }

            //By price
            const minPrice = req.body["minPrice"];
            const maxPrice = req.body["maxPrice"];
            if (minPrice != null && minPrice.length > 0 && stringOnlyContainsDigits.test(minPrice)) {
                moreFilteringSQL += " AND price >= ?";
                filteringArgs.push(minPrice);
            }

            if (maxPrice != null && maxPrice.length > 0 && stringOnlyContainsDigits.test(maxPrice)) {
                moreFilteringSQL += " AND price <= ?";
                filteringArgs.push(maxPrice);
            }

            //By manufacturer
            filterByList("manufacturer == ?", req.body["manufacturers"]);
            filterByList("sellerName == ?", req.body["sellers"]);
            filterByList("category == ?", req.body["categories"]);

            //Filter giving any of the items from the list. Returns if any filtering has been done.
            function filterByList(queryPart, listBody, /*Optional. Whether we convert filtering args to numbers*/ convertToNum) {
                var hadAny = false;

                if (listBody != null) {
                    try {
                        const listToFilterBy = JSON.parse(listBody);
                        //If the body is an array and contains items that are strings
                        if (Array.isArray(listToFilterBy) &&
                            listToFilterBy.length > 0 &&
                            listToFilterBy.every(man => typeof (man) === "string")) {
                            //Add to the SQL and SQL argument array
                            moreFilteringSQL += " AND (" +
                                Array(listToFilterBy.length).fill(queryPart).join(" OR ") +
                                ")";
                            if (convertToNum)
                                filteringArgs = filteringArgs.concat(listToFilterBy);
                            else
                                filteringArgs = filteringArgs.concat(listToFilterBy);
                            hadAny = true;
                        }
                    } catch (e) {
                        //Just ignore it, user probably tried to give us stupid JSON
                    };
                }

                return hadAny;
            }

            //Order
            var orderSQL;
            switch (req.body["orderType"]) {
                case "price":
                    orderSQL = "ORDER BY price";
                    break;
                case "priceDesc":
                    orderSQL = "ORDER BY price DESC";
                    break;
                case "nameDesc":
                    orderSQL = "ORDER BY name COLLATE NOCASE DESC";
                    break;
                case "name":
                default:
                    orderSQL = "ORDER BY name COLLATE NOCASE";
                    break;
            }

            db.all("SELECT Product_ID id, Productname name, Manufacturer manufacturer, Price price, Image image, sellerName FROM Products " +
                "JOIN (SELECT Username sellerName, User_ID FROM Users) ON User_ID == Seller_ID " +
                `WHERE Amount > 0 AND Product_ID <= ${cursor}${moreFilteringSQL} ${orderSQL} LIMIT ${num} OFFSET ${start}`,
                ...filteringArgs, (err, result) => {
                    if (err !== null) {
                        //If there's an error, send it
                        console.log(err);
                        res.status(500).send({ error: "Internal Server Error" });
                        return;
                    }

                    //Make prices localized strings
                    for (let row of result) {
                        row.price = row.price.toLocaleString();
                    }

                    res.send({ error: "", products: result, cursor: cursor } );
                });
        }
    }

    module.exports.changeCategories = function(req, res) {
        if (!checkIfSeller(res))
            return;

        //No errors found, continue to the actual form for submitting a product.

        var doneText = req.session.doneText;;
        req.session.doneText = "";

        //First, get the flattened categories because we need them for the form
        getFlattenedCategories((categoriesFlattened) => {
            //Then render it
            res.render("categories", { categories: categoriesFlattened, doneText: doneText });
        });
    }

    module.exports.changeCategoriesDone = function(req, res) {
        if (!checkIfSeller(res))
            return;

        var parentID = req.body["parent"], name = req.body["categoryName"];
        const stringOnlyContainsDigits = /^\d+$/;
        if (parentID == null ||
            name == null ||
            name === "" ||
            parentID.length === 0 ||
            (!stringOnlyContainsDigits.test(parentID) && parentID !== "-1")) {
            //Not very correct! Show an error. As this cannot normally happen in a browser
            //(invalid input is not normally possible in this form)
            //, it's okay if the error is a bit vague (and rendered green)
            req.session.doneText = "There was a problem! Please check your input.";
            res.redirect(baseUrl + "/settings/categories");
            return;
        }

        if (parentID === "-1") {
            //Insert as top category
            db.run("INSERT INTO Categories VALUES (NULL, ?, NULL)", name, function (err) {
                if (err != null)
                    throw err;

                //We added it! Redirect to GET
                req.session.doneText = "Category added!";
                res.redirect(baseUrl + "/settings/categories");
            });

            return;
        }

        //Check if parent exists
        db.get("SELECT Category_ID FROM Categories WHERE Category_ID == ?",
            parentID,
            function (err, result) {
                if (err != null || result == null) {
                    //There was a problem.
                    req.session.doneText = "There was a problem! Please check your input.";
                    res.redirect(baseUrl + "/settings/categories");
                    return;
                }

                //Insert the category to the database
                db.run("INSERT INTO Categories VALUES (NULL, ?, ?)",
                    name, parentID,
                    function(err2) {
                        if (err2 != null)
                            throw err2;
                        //Redirect to GET path
                        req.session.doneText = "Category added!";
                        res.redirect(baseUrl + "/settings/categories");
                    });
            });
    }
})();