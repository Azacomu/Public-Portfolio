﻿Project of Group 36
Made By:
Florian van Strien	(5632757)
Martin Boers		(5676401)
Jasper			    (3979733)
Rik			        (5501784)

(Link to the server: http://webtech.science.uu.nl/group36/) Not online anymore, sadly :(

WebTech3.sln is a solution file for visual studio 2017, it has the complete project nicely onrganized.

--Explanation of the site:--
-Layout of the website
Homepage: This is the page which you get when you get to the link of the server, it has a small intro picture and beneath this there is an area with top selling products and an area with recommended products for you (part of adaptive web, see extra features).

Products page: This is the page where you can go to look through the products of the webshop, this is all loaded with AJAX, it loads as many items as you can see and only when you scroll down it will load more products.
So products are loaded in groups, this should just be quite seamless for the user (depending on their internet connection and server speed of course).
You can also search for products on this page, select products in a price range, select products only from a certain seller or manufacturer and look at products only from a certain category. Also, you can order products by name or by price.

Register page: You can go to this page to register a new account, you will have to fill in an username, password (which is saved salted and hashed with bcrypt in the Users database due to security), name, email and choose whether you want to be a seller.

Sign In page: Here you can login to your registered account, giving you more options on the website.

Product page: This is the page that shows up for every product, it has a photo, information about the product, a buy area (if logged in), where you can buy a product, this will send you to a confirmation page, which will in place send you to a succes page.
Aside from the buy area, there also is an average rating beneath it and also an rating area (where you can enter a rating if you bought the product) and area with ratings and comments other people have added about that product.

-Login based pages: If you have logged in, you can click on the "Hey Name" part in the upper right corner, which will give more options.
History: For buyers there is the purchase history, showing all products you bought in the past, including links to the product and the rating that you gave those products (and a link so you can rate the product if you have not yet).
         For sellers there also is the seller history, showing what you sold and how much you earned with that.
         
Profile Settings: Here you can change your profile (First and last name)

Account Settings: Here you can change your account, which is your password, username, email, you can switch to a seller account and you can log off on other devices (for security reasons).

Inventory: For sellers, there is the inventory, showing all products that you have placed on the site and a simple interface to add more products to the stock.

Add Product: For sellers, this is the interface with which you can add a product to the website, you have to enter a name, manufacturer, choose a category, price and amount.
You can also upload an image for the product here, this will get saved with a random string as name on the server, if no file gets uploaded, it defaults to "noimage.png".

Manage Categories: For sellers, this is a part where you are able to add more categories to the webshop, you have to choose a name and a parent category (if any).

Log off: Convenient button to log off to be able to login with another account.

-Files used
-Javascript:
client-side:
static/lib/jquery.js    : default file used to use jquery in our client side website, this is only the minimal, we load the rest from the online version.
static/lib/app.js       : this file makes sure that the dropdown menu when you click on your name works(for account options and so on after login) and that scrolling is smooth
static/lib/appProduct.js: this file contains the code to do AJAX queries to the api/products. This is used to show products on-site. Ordering and filtering options are also passed through to the server.
(Don't need a lot more client side, since we used pug to make the html, which is already dynamic with some (server-side) javascript in it, so we could just generate the HTML with all data server-side)

server-side:
dbinit.js       : This is the file to initialize the database of the server, create statements are also at the bottom of this readme.
server.js       : This is the actual server, it sets up some locals, creates a listener on port 8116, has a logger and redirects all links to the correct functions.
product.js      : This is the javascript file with all functions that have something to do with the productpages and forms, such as showing and adding products, history, categories, etc. (a lot).
webshopUser.js  : In this javascript file are all the functions with the users, sessions, things like logging in, hashing passwords, registering more users, etc. (a lot as well).

-Pug: 
We have used pug files to render the html files with dynamic data from the server, all pug files are named after the page which they are for, except for a few includes that we use on multiple pages.
(All pug files are in the folder /views/, the includes in /views/includes/)

-CSS:
We use 2 CSS files, one for pretty much everything (static/css/style.css) and another one for links to images and fonts on the webtech.science.uu.nl/ domain, as that uses a fixed /group36/ part (static/css/styleAltUrls.css)
We also used 2 special fonts, which can be found in static/fonts/orbitron.woff2 and static/fonts/overpass.woff2

-Database:
-We have a database from sqlite, the layout of this database can be found in the ER Diagram (erdiagram.png)
and the create table statements can be found at the bottom of the readme.
We use an sqlite extension by Liam Healy for the square root (and square) functions. The source is provided in sqlite-extension-functions.c, and it's also precompiled in libsqlitefunctions.so for Windows.
The Linux compilation can be found on the webtech server. Build instructions are in the file as well.

--Extra credit features we added:--
-We added Social web features and Adaptive web features.
-For the social web, you can rate and comment on the products that you have bought, there is a dedicated interface for this on the bottom of the product page after you bought the product. 
On the history page you can see an overview of the ratings that you gave to previous purchases, as well as products that you have not rated yet, with links to the product pages so you can rate and comment on the products.
On the product page, there is an overview as well of all ratings and comment that users gave that product, including the average rating of that product.

-For the adaptive web, we added recommendations to the webshop, based on the products that you bought and the ratings you gave them, compared to other buyers of the site that have the same interests.
This uses Pearson’s Correlation Coefficient to calculate similarity between users and then tries to predict the rating an user would give to products they did not yet buy. The top products are shown on the home page.
All calculations are done by one SQL query in recommended.sqlite.

--All accounts in the database:--
-admin      13*&^273218dhâjlwwjerweras
This is not a special account type, but only the account called admin can access /admin/sql and execute any SQL they want.
Normally, creating this account would be part of the installation process because of course the server is quite vulnerable if the account doesn't exist yet.

-Registered Sellers:
user:             pass:
Martin            HelloWorld 
flori9            whatever
BarackObama       lalalala
Petertje          lalalala
Carseller1        lalalala
Opgegetenboterham lalalala
jantje123         lalalala
BlijeJongen       lalalala
TheWhiteCowboy    lalalala
(You will notice that some of the password hashes are the same. This is because we forgot the passwords of these accounts and set the hash to that
of a known password in the SQL. Not very secure but so is sending these passwords over plaintext (and it's still just a webtech assignment).)

-Registered     Buyers:
user:           pass:
SportCarLover   HelloWorld
PartLover       HelloWorld
VladimirPutin   lalalala
Gearhead        GearWars
Gekkie	        lalalala
Willem          lalalala

The database create statements can be found in the "dbinit.js" file.
(for completeness they are in this readme file as well):

"CREATE TABLE IF NOT EXISTS Products (" +
            "Product_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Productname TEXT," +
            "Manufacturer TEXT," +
            "Category INT," +
            "Price INTEGER," +
            "Amount INTEGER," +
            "Image TEXT," +
            "Seller_ID INTEGER)"

"CREATE TABLE IF NOT EXISTS Users (" +
            "User_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Username TEXT UNIQUE," +
            "SaltedPassWordHash TEXT," +
            "FirstName TEXT," +
            "LastName TEXT," +
            "Email TEXT UNIQUE," +
            "IsSeller BOOLEAN," +
            "SessionVersion INTEGER" +
            ")"

"CREATE TABLE IF NOT EXISTS History (" +
            "History_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Productname TEXT," +
            "Price INTEGER," +
            "Amount INTEGER," +
            "Product_ID INTEGER," +
            "User_ID INTEGER," +
            "Seller_ID INTEGER," +
            "Date TEXT" +
            ")"

"CREATE TABLE IF NOT EXISTS Ratings (" +
            "Rate_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "User_ID INTEGER," +
            "Product_ID INTEGER," +
            "Rating INTEGER," +
            "Comment TEXT," +
            "Username TEXT" +
            ")"

"CREATE TABLE IF NOT EXISTS Categories (" +
            "Category_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE," +
            "Categoryname TEXT UNIQUE," +
            "CategoryParentID INTEGER" +
            ")"