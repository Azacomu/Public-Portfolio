﻿using OpenTK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace template
{
    class Camera
    {
        public Vector3 Position, Direction;

        public Camera()
        {
            Position = new Vector3();
            Direction = new Vector3(0, 0, 1);
        }
    }
}
