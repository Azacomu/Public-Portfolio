﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics;

namespace template
{
    class Raytracer
    {
        Scene scene;
        Camera camera;
        Surface screen;

        public Raytracer(Surface screen)
        {
            scene = new Scene();
            camera = new Camera();
            this.screen = screen;
        }

        public void Render()
        {
            screen.Clear(0);
            screen.Circle(200, 200, 100, 0xffffff);
        }
    }
}
