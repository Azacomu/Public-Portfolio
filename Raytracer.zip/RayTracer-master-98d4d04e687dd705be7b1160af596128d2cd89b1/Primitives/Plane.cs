﻿using OpenTK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace template
{
    class Plane : Primitive
    {
        public Vector3 Normal, Distance;

        public Plane(Vector3 normal, Vector3 distance)
        {
            Normal = normal;
            Distance = distance;
        }
    }
}
