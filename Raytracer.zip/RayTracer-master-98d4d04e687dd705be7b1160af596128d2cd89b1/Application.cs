﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace template
{
    class Application
    {
        Raytracer raytracer;

        public Application(Surface surface)
        {
            raytracer = new Raytracer(surface);
        }

        public void Update()
        {
            raytracer.Render();
        }
    }
}
