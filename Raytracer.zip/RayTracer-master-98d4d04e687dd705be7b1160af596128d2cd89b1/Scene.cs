﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace template
{
    class Scene
    {
        List<Primitive> Primitives;

        public Scene()
        {
            Primitives = new List<Primitive>();

            Primitives.Add(new Plane(new Vector3(0, 1, 0), new Vector3(0, -1, 0)));
            Primitives.Add(new Sphere(new Vector3(-4, 0, 4), 1));
            Primitives.Add(new Sphere(new Vector3(0, 0, 4), 1));
            Primitives.Add(new Sphere(new Vector3(4, 0, 4), 1));
        }

        public Vector3 Intersect()
        {
            throw new NotImplementedException();
        }
        
        public bool ShadowIntersect()
        {
            throw new NotImplementedException();
        }
    }
}